"""
Multi-Agent Production Framework
Capa de transporte directa a QwenCloud models via FastAPI
"""
import os
import json
import asyncio
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from enum import Enum

import httpx
from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

# ============================================
# Core Types
# ============================================
class AgentState(Enum):
    IDLE = "idle"
    ANALYZING = "analyzing"
    PLANNING = "planning"
    EXECUTING = "executing"
    VALIDATING = "validating"
    COMPLETED = "completed"
    FAILED = "failed"

@dataclass
class ToolResult:
    success: bool
    data: Any
    cost: float = 0.0
    metadata: Dict = field(default_factory=dict)

class AgentConfig:
    def __init__(self, model: str, max_tokens: int = 1000, temperature: float = 0.7,
                 cost_per_1k_tokens: float = 0.001):
        self.model = model
        self.max_tokens = max_tokens
        self.temperature = temperature
        self.cost_per_1k_tokens = cost_per_1k_tokens

# ============================================
# Tool System
# ============================================
class BaseTool:
    """Base class for tools available to agents"""
    name: str = "base"
    description: str = "Base tool"
    
    async def execute(self, input_data: Any) -> ToolResult:
        raise NotImplementedError

class WebSearchTool(BaseTool):
    name = "web_search"
    description = "Searches the web for current information"
    
    def __init__(self, api_key: str):
        self.api_key = api_key
    
    async def execute(self, query: str) -> ToolResult:
        try:
            async with httpx.AsyncClient() as client:
                resp = await client.post(
                    "https://dashscope-intl.aliyuncs.com/compatible-mode/v1/chat/completions",
                    headers={"Authorization": f"Bearer {self.api_key}"},
                    json={
                        "model": "deepseek-v4-flash",
                        "messages": [{"role": "user", "content": query}],
                        "tools": [{"type": "web_search", "function": {"name": "web_search"}}],
                        "max_tokens": 500
                    },
                    timeout=30.0
                )
                data = resp.json()
                msg = data.get('choices', [{}])[0].get('message', {})
                return ToolResult(
                    success=True,
                    data=msg.get('content', ''),
                    cost=0.001,
                    metadata={'tool': 'web_search'}
                )
        except Exception as e:
            return ToolResult(success=False, data=str(e), cost=0.0)

class CodeExecutionTool(BaseTool):
    name = "code_exec"
    description = "Executes Python code snippets safely"
    
    async def execute(self, code: str) -> ToolResult:
        try:
            # Execute in sandboxed environment
            result = await asyncio.to_thread(
                self._safe_exec, code
            )
            return ToolResult(
                success=True,
                data=result,
                cost=0.0,
                metadata={'tool': 'code_exec'}
            )
        except Exception as e:
            return ToolResult(success=False, data=str(e), cost=0.0)
    
    def _safe_exec(self, code: str) -> str:
        # Simple code execution with restricted globals
        import io
        import sys
        from contextlib import redirect_stdout
        
        stdout = io.StringIO()
        with redirect_stdout(stdout):
            try:
                exec(code, {"__builtins__": __builtins__})
                result = stdout.getvalue()
                return result or "Executed successfully"
            except Exception as e:
                return f"Error: {str(e)}"

# ============================================
# Base Agent Class
# ============================================
class BaseAgent:
    """Base class for all agents in the framework"""
    
    def __init__(self, name: str, config: AgentConfig, tools: List[BaseTool] = None):
        self.name = name
        self.config = config
        self.tools = {t.name: t for t in (tools or [])}
        self.state = AgentState.IDLE
        self.history: List[Dict] = []
        self.total_cost = 0.0
        
        # Setup QwenCloud client
        api_key = self._get_api_key()
        self.client = httpx.AsyncClient(
            base_url="https://dashscope-intl.aliyuncs.com/compatible-mode/v1",
            timeout=120.0,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json"
            }
        )
    
    def _get_api_key(self) -> str:
        """Get API key from env or 9Router DB"""
        api_key = os.getenv("DASHSCOPE_API_KEY", "")
        if not api_key and os.path.exists("/tmp/qwen_api_key"):
            with open("/tmp/qwen_api_key", "r") as f:
                api_key = f.read().strip()
        return api_key or "sk-[REDACTED]"
    
    async def think(self, messages: List[Dict], tools_enabled: bool = True) -> Dict:
        """Generate response using configured model"""
        self.state = AgentState.EXECUTING
        
        payload = {
            "model": self.config.model,
            "messages": messages,
            "max_tokens": self.config.max_tokens,
            "temperature": self.config.temperature
        }
        
        # Add tools if available
        if tools_enabled and self.tools:
            payload["tools"] = [
                {"type": "function", "function": {"name": t.name, "description": t.description}}
                for t in self.tools.values()
            ]
        
        try:
            resp = await self.client.post("/chat/completions", json=payload)
            data = resp.json()
            
            if 'choices' in data:
                msg = data['choices'][0]['message']
                usage = data.get('usage', {})
                tokens = usage.get('total_tokens', 0)
                self.total_cost += (tokens / 1000) * self.config.cost_per_1k_tokens
                
                return {
                    "success": True,
                    "message": msg,
                    "usage": usage,
                    "tool_calls": msg.get('tool_calls', [])
                }
            else:
                return {"success": False, "error": data.get('error', 'Unknown error')}
                
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def use_tool(self, tool_name: str, input_data: Any) -> ToolResult:
        """Execute a tool by name"""
        tool = self.tools.get(tool_name)
        if tool:
            return await tool.execute(input_data)
        return ToolResult(success=False, data=f"Tool '{tool_name}' not found")
    
    def add_to_history(self, role: str, content: str):
        """Add message to conversation history"""
        self.history.append({"role": role, "content": content})
    
    async def close(self):
        await self.client.aclose()

# ============================================
# Specialized Agents
# ============================================
class ResearchAgent(BaseAgent):
    """Agent specialized in web research and information gathering"""
    
    DEFAULT_CONFIG = AgentConfig(
        model="qwen3.8-max",
        max_tokens=2000,
        temperature=0.3,
        cost_per_1k_tokens=6.0  # $6/M tokens
    )
    
    def __init__(self, tools: List[BaseTool] = None):
        default_tools = [
            WebSearchTool(os.getenv("DASHSCOPE_API_KEY", "")),
            CodeExecutionTool()
        ]
        super().__init__("ResearchAgent", self.DEFAULT_CONFIG, tools or default_tools)

class CodeAgent(BaseAgent):
    """Agent specialized in coding and implementation"""
    
    DEFAULT_CONFIG = AgentConfig(
        model="qwen3-coder-plus",
        max_tokens=3000,
        temperature=0.1,
        cost_per_1k_tokens=3.0  # $3/M tokens
    )
    
    def __init__(self, tools: List[BaseTool] = None):
        default_tools = [
            CodeExecutionTool()
        ]
        super().__init__("CodeAgent", self.DEFAULT_CONFIG, tools or default_tools)

class ValidatorAgent(BaseAgent):
    """Agent specialized in validation and quality control"""
    
    DEFAULT_CONFIG = AgentConfig(
        model="qwen3.7-flash",
        max_tokens=1000,
        temperature=0.1,
        cost_per_1k_tokens=0.5  # $0.5/M tokens
    )
    
    def __init__(self, tools: List[BaseTool] = None):
        super().__init__("ValidatorAgent", self.DEFAULT_CONFIG, tools or [])

class OrchestratorAgent(BaseAgent):
    """Agent that coordinates other agents and manages workflow"""
    
    DEFAULT_CONFIG = AgentConfig(
        model="deepseek-v4-flash",
        max_tokens=2000,
        temperature=0.5,
        cost_per_1k_tokens=1.98  # $1.98/M tokens
    )
    
    def __init__(self, tools: List[BaseTool] = None):
        default_tools = [
            CodeExecutionTool()
        ]
        super().__init__("OrchestratorAgent", self.DEFAULT_CONFIG, tools or default_tools)

# ============================================
# State Machine Orchestrator
# ============================================
class Orchestrator:
    """FSM-based orchestrator for multi-agent workflows"""
    
    def __init__(self, agents: Dict[str, BaseAgent]):
        self.agents = agents
        self.current_state = AgentState.IDLE
        self.task_history: List[Dict] = []
        self.context: Dict = {}
    
    async def run_task(self, task: str, workflow_type: str = "research") -> Dict:
        """Execute a task through the multi-agent workflow"""
        task_id = f"task_{len(self.task_history):04d}"
        self.context["task_id"] = task_id
        self.context["task"] = task
        self.context["workflow_type"] = workflow_type
        
        print(f"\n🚀 Starting task: {task_id}")
        print(f"📋 Task: {task}")
        print(f"🔄 Workflow: {workflow_type}")
        print("=" * 60)
        
        # Define workflow based on type
        if workflow_type == "research":
            result = await self._run_research_workflow(task)
        elif workflow_type == "coding":
            result = await self._run_coding_workflow(task)
        elif workflow_type == "analysis":
            result = await self._run_analysis_workflow(task)
        else:
            result = await self._run_generic_workflow(task)
        
        self.task_history.append({
            "task_id": task_id,
            "task": task,
            "workflow": workflow_type,
            "result": result,
            "status": "completed"
        })
        
        return result
    
    async def _run_research_workflow(self, task: str) -> Dict:
        """Workflow: Analyze -> Research -> Validate -> Report"""
        research_agent = self.agents["research"]
        orchestrator = self.agents["orchestrator"]
        
        # State 1: Analyze
        self.current_state = AgentState.ANALYZING
        print("\n[1/4] ANALIZANDO tarea...")
        
        analyze_msg = [
            {"role": "system", "content": f"Eres un orquestador. Analiza esta tarea y determina si necesita investigación web: {task}"},
            {"role": "user", "content": task}
        ]
        analysis = await orchestrator.think(analyze_msg, tools_enabled=False)
        
        if not analysis["success"]:
            return {"status": "failed", "error": analysis.get("error")}
        
        print(f"   → Análisis completado")
        
        # State 2: Research
        self.current_state = AgentState.PREPARING
        print("\n[2/4] INVESTIGANDO...")
        
        research_msg = [
            {"role": "system", "content": "Eres un investigador experto. Usa web search para encontrar información actual sobre:"},
            {"role": "user", "content": task}
        ]
        
        research_result = await research_agent.think(research_msg)
        
        if research_result.get("tool_calls"):
            # Process tool calls
            for call in research_result["tool_calls"]:
                if call.get("function", {}).get("name") == "web_search":
                    args = json.loads(call["function"]["arguments"])
                    query = args.get("query", task)
                    print(f"   → Buscando: {query[:80]}...")
                    tool_result = await research_agent.use_tool("web_search", query)
                    research_msg.append({"role": "tool", "content": tool_result.data})
            
            # Continue with search results
            research_msg.append({"role": "assistant", "content": research_result["message"].get("content", "")})
            final_research = await research_agent.think(research_msg)
        else:
            final_research = research_result
        
        print("   → Investigación completada")
        
        # State 3: Validate
        self.current_state = AgentState.VALIDATING
        print("\n[3/4] VALIDANDO...")
        
        validator = self.agents["validator"]
        validation_msg = [
            {"role": "system", "content": "Valida la información anterior. Señala inconsistencias o puntos que necesiten verificación."},
            {"role": "user", "content": final_research["message"].get("content", "")}
        ]
        
        validation = await validator.think(validation_msg, tools_enabled=False)
        print("   → Validación completada")
        
        # State 4: Report
        self.current_state = AgentState.COMPLETED
        print("\n[4/4] GENERANDO REPORTE...")
        
        report_msg = [
            {"role": "system", "content": "Genera un reporte conciso con los hallazgos clave. Usa bullets, incluye fuentes verificables."},
            {"role": "user", "content": f"Tarea: {task}\n\nHallazgos: {final_research['message'].get('content', '')}\n\nValidación: {validation['message'].get('content', '')}"}
        ]
        
        report = await orchestrator.think(report_msg, tools_enabled=False)
        
        result = {
            "task": task,
            "status": "completed",
            "research_findings": final_research["message"].get("content", ""),
            "validation": validation["message"].get("content", ""),
            "final_report": report["message"].get("content", ""),
            "agents_used": ["Orchestrator", "ResearchAgent", "ValidatorAgent"],
            "total_cost": sum(a.total_cost for a in self.agents.values())
        }
        
        print(f"\n✅ Task completed! Cost: ${result['total_cost']:.4f}")
        return result
    
    def _run_coding_workflow(self, task: str) -> Dict:
        """Workflow for code tasks"""
        return {"status": "pending", "task": task, "workflow": "coding"}
    
    def _run_analysis_workflow(self, task: str) -> Dict:
        """Workflow for analysis tasks"""
        return {"status": "pending", "task": task, "workflow": "analysis"}
    
    async def _run_generic_workflow(self, task: str) -> Dict:
        """Generic workflow"""
        return {"status": "pending", "task": task, "workflow": "generic"}

# ============================================
# FastAPI Application
# ============================================
app = FastAPI(
    title="QwenCloud Agents Framework",
    description="Framework de agentes multi-agente para QwenCloud",
    version="1.0.0"
)

# Global instances
_orchestrator: Optional[Orchestrator] = None

@app.on_event("startup")
async def startup_event():
    """Initialize framework on startup"""
    global _orchestrator
    
    # Initialize tools
    api_key = os.getenv("DASHSCOPE_API_KEY", "")
    if not api_key and os.path.exists("/tmp/qwen_api_key"):
        with open("/tmp/qwen_api_key", "r") as f:
            api_key = f.read().strip()
    
    # Initialize agents
    agents = {
        "orchestrator": OrchestratorAgent([
            CodeExecutionTool()
        ]),
        "research": ResearchAgent([
            WebSearchTool(api_key),
            CodeExecutionTool()
        ]),
        "code": CodeAgent([
            CodeExecutionTool()
        ]),
        "validator": ValidatorAgent()
    }
    
    _orchestrator = Orchestrator(agents)

@app.post("/agents/run")
async def run_agent_task(task: str, workflow_type: str = "research", max_turns: int = 10):
    """Ejecuta una tarea multi-agente"""
    if not _orchestrator:
        raise HTTPException(status_code=500, detail="Orchestrator not initialized")
    
    result = await _orchestrator.run_task(task, workflow_type)
    return result

@app.post("/agents/conversation")
async def start_conversation(
    message: str,
    agent_a_model: str = "qwen3.8-flash",
    agent_b_model: str = "deepseek-v4-flash",
    turns: int = 6
):
    """Inicia una conversación multi-agente"""
    
    # Create agents for conversation
    agent_a = BaseAgent("Agent-A", AgentConfig(
        model=agent_a_model, max_tokens=500, temperature=0.7, cost_per_1k_tokens=0.47
    ))
    agent_b = BaseAgent("Agent-B", AgentConfig(
        model=agent_b_model, max_tokens=500, temperature=0.7, cost_per_1k_tokens=1.98
    ))
    
    transcript = []
    current_agent = agent_a
    other_agent = agent_b
    
    # Initialize
    messages = [{"role": "user", "content": message}]
    
    for i in range(turns):
        # Current agent responds
        result = await current_agent.think(messages, tools_enabled=False)
        
        if result["success"]:
            msg_content = result["message"].get("content", "")
            transcript.append({
                "turn": i + 1,
                "speaker": current_agent.name,
                "model": current_agent.config.model,
                "response": msg_content[:500]
            })
            
            # Update messages for next agent
            messages.append({"role": "assistant", "content": msg_content})
            messages.append({"role": "user", "content": f"Responde al punto anterior sobre: {message}"})
            
            # Switch agents
            current_agent, other_agent = other_agent, current_agent
            await asyncio.sleep(0.5)
        else:
            transcript.append({
                "turn": i + 1,
                "speaker": current_agent.name,
                "error": result.get("error", "Unknown error")
            })
            break
    
    # Cleanup
    await agent_a.close()
    await agent_b.close()
    
    return {
        "status": "completed",
        "transcript": transcript,
        "cost": {
            "agent_a": agent_a.total_cost,
            "agent_b": agent_b.total_cost,
            "total": agent_a.total_cost + agent_b.total_cost
        }
    }

@app.get("/agents/status")
async def get_status():
    """Estado del framework"""
    agent_statuses = {}
    if _orchestrator:
        for name, agent in _orchestrator.agents.items():
            agent_statuses[name] = {
                "model": agent.config.model,
                "state": agent.state.value if hasattr(agent.state, 'value') else str(agent.state),
                "cost": round(agent.total_cost, 4),
                "tools": list(agent.tools.keys())
            }
    
    return {
        "status": "healthy",
        "service": "qwencloud-agents",
        "agents": agent_statuses,
        "tasks_completed": len(_orchestrator.task_history) if _orchestrator else 0
    }

@app.get("/health")
async def health_check():
    """Health endpoint"""
    return {
        "status": "healthy",
        "service": "qwencloud-agents",
        "version": "1.0.0",
        "framework": "Multi-Agent Production Framework"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=9102)