import sys
sys.path.insert(0, '.')
import time

print("Iniciando test debug 2...", flush=True)

from pipeline.remi_pipeline import RemiPipeline
print("✓ Pipeline importado", flush=True)

pipeline = RemiPipeline(interactive=False, use_rewrite=False)
print("✓ Pipeline instanciado", flush=True)

query = "afiliados mercado libre"
print(f"Procesando query: '{query}'...", flush=True)

start = time.time()
trace = pipeline.process(query)
elapsed = time.time() - start

print(f"✓ Query procesada en {elapsed:.2f}s", flush=True)
print(f"Decisión: {trace.get('final', {}).get('decision')}", flush=True)
print(f"Nodo: {trace.get('final', {}).get('nodo')}", flush=True)
