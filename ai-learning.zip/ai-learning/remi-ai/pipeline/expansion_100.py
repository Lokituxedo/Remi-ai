"""Inyección masiva de conocimiento — Expansión 39 a 100+ nodos"""
from pathlib import Path
PROJECT_ROOT = Path(__file__).resolve().parents[1]
import sqlite3
from pathlib import Path

BASE = PROJECT_ROOT
DB = BASE / "memoria" / "core" / "core.db"
KNOWLEDGE = BASE / "knowledge"

def save_node(conn, nodo_id, tipo, label, content_md, disparadores, dominio):
    filename = nodo_id.replace(f"{nodo_id.split("_")[0]}_", "") + ".md"
    file_path = KNOWLEDGE / dominio / filename
    file_path.parent.mkdir(parents=True, exist_ok=True)
    file_path.write_text(content_md, encoding="utf-8")
    rel_path = f"knowledge/{dominio}/{filename}"
    conn.execute("""
        INSERT OR REPLACE INTO nodos 
        (id, tipo, label, descripcion, densidad, activo, creado_por, content_type, content_source) 
        VALUES (?,?,?,?,1.0,1,"expansion_masiva","file",?)
    """, (nodo_id, tipo, label, content_md[:200], rel_path))
    for disp in disparadores:
        conn.execute("""
            INSERT OR IGNORE INTO contexto_activacion 
            (nodo_id, disparador, contexto, prioridad) 
            VALUES (?,?,?,1)
        """, (nodo_id, disp.lower(), "expansion masiva"))

NODOS = []

NODOS.extend([
    ("edu_spaced", "tecnica", "Repetición Espaciada",
     "# Repetición Espaciada\n\nRepasar información en intervalos crecientes combate la curva del olvido (Ebbinghaus).\n\nIntervalos típicos: 1 día, 3 días, 7 días, 21 días, 60 días.\n\nHerramientas: Anki, SuperMemo. Base de todo sistema SRS.",
     ["repeticion espaciada", "spaced repetition", "anki", "curva del olvido", "srs"], "educacion"),

    ("edu_retrieval", "tecnica", "Práctica de Recuperación",
     "# Práctica de Recuperación (Testing Effect)\n\nRecordar activamente fortalece más la memoria que releer.\n\nEl test no solo mide: modifica la memoria.\n\nAplicar: autoexámenes, flashcards, escribir sin apuntes.",
     ["retrieval practice", "testing effect", "practica de recuperacion", "autoexamen"], "educacion"),

    ("edu_dual_coding", "tecnica", "Codificación Dual",
     "# Codificación Dual (Paivio)\n\nCombinar representación verbal + visual duplica las rutas de memoria.\n\nTexto + diagrama > solo texto.\n\nAplicar: mapas conceptuales, sketchnoting, infografías.",
     ["dual coding", "codificacion dual", "paivio", "aprendizaje visual"], "educacion"),

    ("edu_elaboracion", "tecnica", "Interrogación Elaborativa",
     "# Interrogación Elaborativa\n\nPreguntar '¿por qué es esto cierto?' fuerza conexiones con conocimiento previo.\n\nTransforma dato aislado en red semántica.\n\nComplementa repetición espaciada.",
     ["interrogacion elaborativa", "elaborative interrogation", "por que funciona", "elaboracion"], "educacion"),

    ("edu_autoexplicacion", "tecnica", "Autoexplicación",
     "# Autoexplicación\n\nExplicarse a uno mismo los pasos mientras se resuelve un problema.\n\nDetecta lagunas en tiempo real.\n\nTécnica base del método Feynman.",
     ["autoexplicacion", "self explanation", "explicarse a uno mismo", "feynman"], "educacion"),

    ("edu_analogias", "tecnica", "Pensamiento Analógico",
     "# Pensamiento Analógico\n\nTransferir estructura de un dominio conocido a uno nuevo.\n\n'La electricidad es como agua en tuberías'.\n\nLas analogías correctas aceleran comprensión; las falsas crean errores sistemáticos.",
     ["analogias", "pensamiento analogico", "transferencia", "metaforas aprendizaje"], "educacion"),

    ("edu_feedback_efectivo", "concepto", "Feedback Efectivo",
     "# Feedback Efectivo\n\nHattie: el feedback es de las variables con mayor impacto en aprendizaje.\n\n## Niveles\n1. Tarea (¿correcto?)\n2. Proceso (¿estrategia?)\n3. Autorregulación (¿cómo mejoro?)\n4. Yo (elogio vacío — el menos útil)\n\nFeedback inmediato y específico > genérico y tardío.",
     ["feedback efectivo", "feedback", "hattie", "retroalimentacion"], "educacion"),

    ("edu_motivacion_intrinseca", "teoria", "Motivación Intrínseca (SDT)",
     "# Teoría de la Autodeterminación (Deci y Ryan)\n\n## Tres necesidades básicas\n1. Autonomía: elegir\n2. Competencia: mejorar\n3. Relación: conectar\n\nCubiertas las tres, la motivación intrínseca emerge sola.\n\nPremios externos pueden erosionarla (efecto de sobrejustificación).",
     ["motivacion intrinseca", "autodeterminacion", "sdt", "deci ryan"], "educacion"),
])

NODOS.extend([
    ("tec_cicd", "practica", "CI/CD",
     "# CI/CD\n\nIntegración y Entrega/Despliegue Continuo.\n\n## CI: cada commit se build + test automático\n## CD: despliegue automático a producción\n\nHerramientas: GitHub Actions, GitLab CI, Jenkins.\n\nBeneficio: errores detectados en minutos, no semanas.",
     ["cicd", "ci cd", "integracion continua", "github actions", "despliegue continuo"], "tecnica"),

    ("tec_microservicios", "arquitectura", "Microservicios vs Monolito",
     "# Microservicios vs Monolito\n\n## Monolito: un deploy, una base de código\n+ Simple de iniciar, fácil debug\n- Escala todo junto\n\n## Microservicios: servicios independientes\n+ Escala por componente, equipos autónomos\n- Complejidad operativa alta\n\nRegla: empezar monolito, extraer servicios cuando duela.",
     ["microservicios", "monolito", "arquitectura distribuida", "servicios"], "tecnica"),

    ("tec_caching", "tecnica", "Caching",
     "# Caching\n\nGuardar resultados costosos para reuso rápido.\n\n## Niveles\n- Navegador, CDN, aplicación, base de datos\n\n## Estrategias\n- Cache-aside, write-through, TTL\n\n## Problemas clásicos\n- Invalidación y nombrar cosas (los 2 problemas difíciles)\n\nHerramientas: Redis, Memcached.",
     ["caching", "cache", "redis", "memcached", "ttl"], "tecnica"),

    ("tec_colas", "arquitectura", "Colas de Mensajes",
     "# Colas de Mensajes\n\nComunicación asíncrona entre componentes.\n\n## Patrones\n- Publisher/Subscriber\n- Work queues\n\n## Beneficios\n- Desacopla productores y consumidores\n- Absorbe picos de carga\n\nHerramientas: RabbitMQ, Kafka, SQS.",
     ["colas de mensajes", "message queue", "kafka", "rabbitmq", "pubsub"], "tecnica"),

    ("tec_websockets", "protocolo", "WebSockets",
     "# WebSockets\n\nConexión bidireccional persistente cliente-servidor.\n\n## vs HTTP\nHTTP: cliente pregunta, servidor responde\nWS: ambos pueden enviar cuando quieran\n\nUsos: chat, trading, juegos, notificaciones en vivo.\n\nCosto: conexión abierta por cliente.",
     ["websockets", "websocket", "tiempo real", "socket io"], "tecnica"),

    ("tec_auth", "practica", "Autenticación: OAuth y JWT",
     "# Autenticación\n\n## Sesiones: estado en servidor\n## JWT: token firmado, sin estado\n## OAuth 2.0: delegar acceso sin dar contraseña\n\nJWT estructura: header.payload.signature\n\nReglas: HTTPS siempre, expiración corta, refresh tokens rotativos.",
     ["oauth", "jwt", "autenticacion", "login", "tokens"], "tecnica"),

    ("tec_criptografia", "concepto", "Criptografía Aplicada",
     "# Criptografía Aplicada\n\n## Simétrica: misma clave (AES) — rápida\n## Asimétrica: par público/privado (RSA, ECC) — intercambio\n## Hash: irreversible (SHA-256) — integridad\n\nTLS combina las tres: asimétrica negocia, simétrica cifra, hash verifica.\n\nContraseñas: hash + salt lento (bcrypt, argon2).",
     ["criptografia", "cifrado", "aes", "rsa", "hash", "tls"], "tecnica"),

    ("tec_clean_arch", "arquitectura", "Clean Architecture",
     "# Clean Architecture (Robert Martin)\n\nCírculos concéntricos: entidades → casos de uso → adaptadores → frameworks.\n\n## Regla de dependencia\nApuntar siempre hacia adentro.\n\nEl negocio no conoce la base de datos ni el framework.\n\nResultado: testeable y reemplazable por capas.",
     ["clean architecture", "arquitectura limpia", "robert martin", "capas", "hexagonal"], "tecnica"),
])

NODOS.extend([
    ("com_retencion", "metrica", "Retención y Churn",
     "# Retención y Churn\n\nRetención: % que sigue usando el producto tras N días.\nChurn: % que abandona por período.\n\n## Curva de retención ideal\nCae y se estabiliza (no va a cero).\n\nRetener cuesta 5-25x menos que adquirir.\n\nCohortes por semana de signup para ver tendencias reales.",
     ["retencion", "churn", "cohortes", "retention", "abandono"], "comercio"),

    ("com_ab_testing", "metodo", "A/B Testing",
     "# A/B Testing\n\nComparar dos variantes midiendo una métrica.\n\n## Requisitos\n- Hipótesis clara\n- Una variable a la vez\n- Tamaño muestral suficiente\n- Duración completa (ciclos semanales)\n\n## Errores\nPeeking temprano, múltiples comparaciones, métricas vanidosas.",
     ["ab testing", "test ab", "experimentos", "variante control"], "comercio"),

    ("com_growth_loops", "estrategia", "Growth Loops",
     "# Growth Loops\n\nCiclos donde el uso genera más adquisición.\n\n## Ejemplos\n- Dropbox: invitar → espacio extra → más invitados\n- Slack: equipo invita → más valor → más equipos\n\n## vs Funnel\nEl funnel termina; el loop se compone y acelera.",
     ["growth loops", "loops de crecimiento", "viral loop", "crecimiento compuesto"], "comercio"),

    ("com_segmentacion", "estrategia", "Segmentación de Mercado",
     "# Segmentación de Mercado\n\nDividir el mercado en grupos con necesidades distintas.\n\n## Criterios\n- Demográfico, geográfico\n- Psicográfico, comportamental\n- Jobs-to-be-done (el más accionable)\n\nRegla: un segmento prioritario al inicio.\n'Para todos' = para nadie.",
     ["segmentacion", "mercado objetivo", "target", "jobs to be done", "buyer persona"], "comercio"),

    ("com_posicionamiento", "estrategia", "Posicionamiento",
     "# Posicionamiento (April Dunford)\n\nContexto que hace obvio tu valor.\n\n## Componentes\n1. Alternativas competitivas\n2. Características únicas\n3. Valor que entregan\n4. Cliente ideal\n5. Categoría de mercado\n\nSin posición clara, el cliente elige la categoría por ti (y te compara mal).",
     ["posicionamiento", "april dunford", "categoria mercado", "propuesta de valor"], "comercio"),

    ("com_kfactor", "metrica", "Viralidad y K-factor",
     "# K-factor (coeficiente viral)\n\nK = invitaciones por usuario × tasa de conversión.\n\nK > 1: crecimiento viral exponencial\nK < 1: crecimiento se apaga\n\n## Ciclo viral\nTiempo entre invitaciones acelera o frena el loop.\n\nCombinar con retención: viralidad sin retención = balde agujereado.",
     ["k factor", "viralidad", "coeficiente viral", "ciclo viral"], "comercio"),

    ("com_subscription", "modelo", "Economía de Suscripción",
     "# Economía de Suscripción\n\n## Métricas clave\n- MRR/ARR: ingreso recurrente\n- NRR: retención neta de ingreso (>100% = expansión)\n- LTV con churn: LTV = ARPU / churn\n\n## Ventajas\nIngreso predecible, relación continua.\n\n## Riesgos\nChurn compuesto mata el negocio silenciosamente.",
     ["suscripcion", "mrr", "arr", "nrr", "ingreso recurrente", "saas"], "comercio"),

    ("com_partnerships", "estrategia", "Alianzas Estratégicas",
     "# Alianzas Estratégicas\n\nCrecer mediante partners con audiencias complementarias.\n\n## Tipos\n- Integraciones técnicas\n- Co-marketing\n- Resellers / canal\n\n## Regla\nEl partner debe ganar tanto como tú.\nAlianza 1+1=3 o no es alianza.",
     ["alianzas", "partnerships", "partners", "co marketing", "canal"], "comercio"),
])

NODOS.extend([
    ("leg_freelance", "documento", "Contratos Freelance",
     "# Contratos Freelance\n\n## Cláusulas esenciales\n- Alcance y entregables específicos\n- Pagos: anticipo + hitos\n- Propiedad intelectual: ¿cuándo se transfiere?\n- Revisiones incluidas (límite)\n- Cancelación y kill fee\n\nSin contrato escrito: tu palabra vs la del cliente.",
     ["freelance", "contrato freelance", "honorarios contrato", "kill fee", "alcance"], "legal"),

    ("leg_facturacion", "regulacion", "Facturación y Documentos Tributarios",
     "# Facturación (Chile)\n\n## DTE principales\n- Factura electrónica (venta a empresa)\n- Boleta electrónica (venta a consumidor)\n- Nota de crédito (anula/corrige)\n\n## Plazos\nDeclaración F29 mensual.\n\n## Regla\nEmitir DTE al momento de la venta, no al cobro.",
     ["facturacion", "factura electronica", "boleta", "dte", "nota de credito"], "legal"),

    ("leg_consumidor", "derecho", "Protección al Consumidor",
     "# Protección al Consumidor (Ley 19.496 Chile)\n\n## Derechos básicos\n- Información veraz\n- Garantía legal (6 meses)\n- Retracto en compras electrónicas (10 días)\n- No discriminación arbitraria\n\n## SERNAC\nReclamos y mediación gratuita.\n\nLetrero 'no se admite cambio' no anula garantía legal.",
     ["consumidor", "sernac", "garantia legal", "ley 19496", "derecho retracto"], "legal"),

    ("leg_ecommerce", "regulacion", "Regulación E-commerce",
     "# E-commerce: obligaciones legales\n\n## Chile\n- Ley 21.455: despacho, retracto, información de precio final\n- Precio final visible (con IVA y envío)\n- Plazo de entrega explícito\n\n## Datos\n- Política de privacidad visible\n- Consentimiento para marketing\n\n## Medios de pago\n- Informar comisiones y cuotas reales.",
     ["ecommerce", "comercio electronico", "ley 21455", "tienda online", "venta internet"], "legal"),

    ("leg_cookies", "regulacion", "Cookies y Consentimiento",
     "# Cookies y Consentimiento\n\n## Tipos\n- Técnicas: no requieren consentimiento\n- Analíticas/marketing: requieren consentimiento explícito\n\n## GDPR\nOpt-in real: pre-marcado no vale.\nDebe ser tan fácil rechazar como aceptar.\n\n## Buen diseño\nBanner claro + centro de preferencias persistente.",
     ["cookies", "consentimiento", "banner cookies", "gdpr cookies", "privacidad web"], "legal"),

    ("leg_licencias_int", "derecho", "Licencias Internacionales",
     "# Licencias Internacionales de Software/Contenido\n\n## Decisiones clave\n- Territorio de la licencia\n- Ley aplicable y foro\n- Moneda y forma de pago\n- Restricciones de exportación\n\n## Open source internacional\nLa licencia viaja con el código: MIT/GPL aplican globalmente.\n\nVender SaaS cross-border: revisar IVA digital del país destino.",
     ["licencias internacionales", "territorio", "ley aplicable", "saas internacional", "iva digital"], "legal"),

    ("leg_arbitraje", "derecho", "Arbitraje y Resolución de Disputas",
     "# Arbitraje\n\nAlternativa privada a tribunales.\n\n## Ventajas\n- Más rápido y especializado\n- Confidencial\n- Laudo ejecutable (Nueva York 1958, cross-border)\n\n## Desventajas\n- Costo de árbitros\n- Apelación casi inexistente\n\n## Cláusula compromisoria\nDefinir: institución, sede, número de árbitros, idioma.",
     ["arbitraje", "clausula compromisoria", "laudo", "resolucion disputas", "mediacion"], "legal"),
])


# EJECUCION
conn = sqlite3.connect(DB)
stats = {"educacion": 0, "tecnica": 0, "comercio": 0, "legal": 0}

for nodo_id, tipo, label, content, disparadores, dominio in NODOS:
    save_node(conn, nodo_id, tipo, label, content, disparadores, dominio)
    stats[dominio] += 1

conn.commit()

total = conn.execute("SELECT COUNT(*) FROM nodos WHERE activo=1").fetchone()[0]
inline = conn.execute("SELECT COUNT(*) FROM nodos WHERE activo=1 AND (content_type='inline' OR content_type IS NULL)").fetchone()[0]
file_nodes = conn.execute("SELECT COUNT(*) FROM nodos WHERE activo=1 AND content_type='file'").fetchone()[0]
disparadores = conn.execute("SELECT COUNT(*) FROM contexto_activacion").fetchone()[0]

print("=" * 60)
print("  INYECCIÓN MASIVA COMPLETADA")
print("=" * 60)
print(f"\nNuevos nodos inyectados:")
print(f"  Educación: {stats['educacion']}")
print(f"  Técnica:   {stats['tecnica']}")
print(f"  Comercio:  {stats['comercio']}")
print(f"  Legal:     {stats['legal']}")
print(f"  Total nuevo: {sum(stats.values())}")

print(f"\nEstado total:")
print(f"  Nodos activos: {total}")
print(f"  Inline (fundacionales): {inline}")
print(f"  File (conocimiento): {file_nodes}")
print(f"  Disparadores totales: {disparadores}")

print(f"\nArchivos en /knowledge/:")
for dom in ["educacion", "tecnica", "comercio", "legal"]:
    files = list((KNOWLEDGE / dom).glob("*.md"))
    print(f"  {dom:10s}: {len(files)} archivos")

print(f"\nResultado: {'SUPERADO' if total >= 100 else 'En camino'} ({total} nodos)")
print("=" * 60)
conn.close()
