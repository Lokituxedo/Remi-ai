from pathlib import Path
PROJECT_ROOT = Path(__file__).resolve().parents[1]
import json, sys
sys.path.insert(0, str(PROJECT_ROOT))
from pipeline.remi_pipeline import RemiPipeline

pipeline = RemiPipeline(interactive=False)
results = {"tests": []}

tests = [
    ("genesis", "cuéntame sobre el origen del proyecto Remi-AI", "match"),
    ("gusteau", "quién es Gusteau", "match"),
    ("kernel", "explícame el modelo nodal kernel", "match"),
    ("hola", "hola", "fallback"),
    ("gracias", "gracias por tu ayuda", "fallback"),
    ("codigo", "escribe una función Python que calcule fibonacci", "model_new"),
    ("busqueda", "busca información sobre redes neuronales", "model_new"),
]

print("=" * 70)
print("  REMI-AI — PIPELINE END-TO-END TESTS")
print("=" * 70)

for name, stimulus, expected in tests:
    trace = pipeline.process(stimulus)
    actual = trace.get("final", {}).get("decision", "?")
    passed = (actual == expected)
    results["tests"].append({
        "test": name, "expected": expected, "actual": actual, "passed": passed,
        "phase": trace.get("phase"),
        "route": trace.get("final", {}).get("route"),
        "nodo": trace.get("final", {}).get("nodo"),
        "provider": trace.get("final", {}).get("provider"),
        "content_preview": (trace.get("final", {}).get("content") or "")[:60]
    })
    status = "✓" if passed else "✗"
    print(f"{status} {name:12s} | esperado={expected:10s} | actual={actual:10s} | phase={trace.get('phase')}")
    if trace.get("final", {}).get("nodo"):
        print(f"  └─ nodo: {trace['final']['nodo']}")
    if trace.get("final", {}).get("provider"):
        print(f"  └─ provider: {trace['final']['provider']}")

passed = sum(1 for t in results["tests"] if t["passed"])
total = len(results["tests"])
print("=" * 70)
print(f"  RESULTADO: {passed}/{total}")
print(f"  VEREDICTO: {'PIPELINE_REMI_OPERATIVO' if passed==total else 'PIPELINE_PARCIAL'}")
print("=" * 70)
print(f"\nFilosofía: Gusteau — 'Anyone can learn anything'")
print(f"Orquestador: Qwen3.8-max | Core: qwen2.5-coder:3b | Router: 9router")
