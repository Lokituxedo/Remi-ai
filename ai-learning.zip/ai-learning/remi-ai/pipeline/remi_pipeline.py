"""Remi-AI Pipeline Final v3 — Con persistencia de memoria"""
from pathlib import Path
PROJECT_ROOT = Path(__file__).resolve().parents[1]
import json, requests, re, sys, sqlite3
from pathlib import Path
from datetime import datetime

BASE = PROJECT_ROOT
CORE_DB = BASE / "memoria" / "core" / "core.db"
OLLAMA_HOST = "http://localhost:11434"
CORE_MODEL = "remi-ai-core"

sys.path.insert(0, str(BASE))
from router.nrouter_client import RemiRouterClient
from edge.matcher import NodalMatcher
from memoria.persistence import MemoryPersistence
from memoria.content_resolver import ContentResolver
from edge.embeddings import EmbeddingStore
from edge.rewriter import rewrite_query
from edge.confirm_gate import should_confirm, ask_confirmation, build_hypothesis


class RemiPipeline:
    def __init__(self, interactive=None, force_yes=False, confirm_always=False, use_rewrite=False):
        self.core_model = CORE_MODEL
        self.ollama_host = OLLAMA_HOST
        self.matcher = NodalMatcher(CORE_DB)
        self.router = RemiRouterClient()
        self.memory = MemoryPersistence()
        self.resolver = ContentResolver()
        # Fase A: configuración de interacción
        # Detectar TTY automáticamente si no se especifica
        if interactive is None:
            self.interactive = hasattr(sys.stdin, 'isatty') and sys.stdin.isatty()
        else:
            self.interactive = interactive
        self.force_yes = force_yes
        self.confirm_always = confirm_always
        self.use_rewrite = use_rewrite
        # Fase B: embeddings para búsqueda semántica
        try:
            self.embedding_store = EmbeddingStore(CORE_DB)
        except Exception:
            self.embedding_store = None
    
    def _call_core(self, stimulus: str) -> dict:
        try:
            r = requests.post(
                f"{self.ollama_host}/api/generate",
                json={"model": self.core_model, "prompt": stimulus, "stream": False, "format": "json",
                      "options": {"temperature": 0, "top_k": 1, "top_p": 1, "seed": 42}},
                timeout=30
            )
            if r.status_code != 200:
                return {"error": f"ollama_{r.status_code}"}
            raw = r.json().get("response", "")
            clean = re.compile(r'\x1b\[[0-9;]*[a-zA-Z]|\x1b\].*?\x07').sub('', raw).strip()
            if clean.startswith("```"):
                clean = clean.split("\n", 1)[1] if "\n" in clean else clean
                if clean.endswith("```"): clean = clean[:-3]
                clean = clean.strip()
            return {"parsed": json.loads(clean)}
        except Exception as e:
            return {"error": str(e)}
    
    def _select_provider(self, core_parsed: dict) -> str:
        intent = core_parsed.get("intent", "")
        if intent == "code": return "nemotron-free"
        if intent == "search": return "nemotron-free"
        return "all-free-tier"
    
    def _call_litellm(self, query: str, model: str = "remi-generator", max_tokens: int = 2000) -> dict:
        """Llama a LiteLLM localhost:4000 (modo i5 nativo)."""
        import requests as _req
        try:
            r = _req.post(
                "http://localhost:4000/v1/chat/completions",
                json={
                    "model": model,
                    "messages": [{"role": "user", "content": query}],
                    "max_tokens": max_tokens,
                    "temperature": 0.7,
                },
                timeout=30,
            )
            if r.status_code == 200:
                d = r.json()
                return {
                    "status": "ok",
                    "content": d["choices"][0]["message"]["content"],
                    "provider": f"litellm/{model}",
                    "usage": d.get("usage", {}),
                }
            return {"status": "error", "error": f"litellm_{r.status_code}", "text": r.text[:200]}
        except Exception as e:
            return {"status": "error", "error": f"litellm_exc: {e}", "text": str(e)}

    def _call_router(self, query: str, provider: str) -> dict:
        """Llama al router con fallback entre proveedores."""
        # i5 nativo: LiteLLM primero, 9router solo como respaldo externo
        local = self._call_litellm(query, model="remi-generator")
        if local["status"] == "ok":
            return local
        result = self.router.chat(prompt=query, provider=provider, max_tokens=2000)
        if result["status"] == "ok":
            return result
        # Fallback a otros proveedores
        for alt in ["all-free-tier", "nemotron-free", "nemotron-free"]:
            if alt != provider:
                alt_result = self.router.chat(prompt=query, provider=alt, max_tokens=2000)
                if alt_result["status"] == "ok":
                    return alt_result
        return result
    
    def process(self, stimulus: str) -> dict:
        trace = {"timestamp": datetime.now().isoformat(), "stimulus": stimulus, "phase": None}
        
        # Phase 1: Core clasifica
        trace["phase"] = "core"
        # ── PRE-CHECK: match defensivo de disparadores (antes del Core) ──
        # Solo queries de 2+ palabras; evita matchear saludos de 1 palabra
        # Solo disparadores de 7+ caracteres; evita falsos positivos con palabras cortas
        query_norm = self.matcher._normalize_text(stimulus)
        if len(query_norm.split()) >= 2:
            # Ordenar disparadores por longitud (más largos primero)
            # Solo considerar disparadores de 7+ caracteres
            sorted_disps = sorted(
                [(d, n) for d, n in self.matcher.disparadores.items() if len(d) >= 7],
                key=lambda x: len(x[0]), 
                reverse=True
            )
            
            for disp, nodo_id in sorted_disps:
                disp_norm = self.matcher._normalize_text(disp)
                
                # Substring match para disparadores largos (7+ chars)
                if disp_norm in query_norm:
                    resolved = self.resolver.resolve(nodo_id)
                    trace["final"] = {
                        "decision": "match", "route": "edge_exact_precheck",
                        "nodo": nodo_id, "score": 1.0,
                        "content": resolved["content"],
                        "content_type": resolved["content_type"]
                    }
                    trace["phase"] = "edge"
                    self._save(trace)
                    return trace
        
        # ── FASE A: REWRITE (si pre-check falló) ──
        # Genera variantes semánticas vía core local y prueba cada una
        if self.use_rewrite and len(query_norm.split()) >= 2:
            variants = rewrite_query(stimulus, n=3, timeout=20)
            for variant in variants:
                variant_norm = self.matcher._normalize_text(variant)
                if len(variant_norm.split()) < 2:
                    continue
                # Probar variante contra disparadores
                sorted_disps = sorted(
                    [(d, n) for d, n in self.matcher.disparadores.items() if len(d) >= 7],
                    key=lambda x: len(x[0]),
                    reverse=True
                )
                for disp, nodo_id in sorted_disps:
                    disp_norm = self.matcher._normalize_text(disp)
                    if disp_norm in variant_norm:
                        resolved = self.resolver.resolve(nodo_id)
                        trace["final"] = {
                            "decision": "match", "route": "edge_rewrite",
                            "nodo": nodo_id, "score": 1.0,
                            "content": resolved["content"],
                            "content_type": resolved["content_type"],
                            "rewrite_from": variant
                        }
                        trace["phase"] = "edge"
                        self._save(trace)
                        return trace

        # ── FASE B: BÚSQUEDA SEMÁNTICA (si pre-check falló) ──
        if self.embedding_store and len(query_norm.split()) >= 3:
            semantic_results = self.embedding_store.search(stimulus, top_k=3, threshold=0.70)
            if semantic_results:
                top_nodo_id, similarity = semantic_results[0]
                resolved = self.resolver.resolve(top_nodo_id)
                trace["final"] = {
                    "decision": "match", "route": "edge_semantic",
                    "nodo": top_nodo_id, "score": similarity,
                    "content": resolved["content"],
                    "content_type": resolved["content_type"]
                }
                trace["phase"] = "edge"
                self._save(trace)
                return trace

        core_result = self._call_core(stimulus)
        if "error" in core_result:
            trace["final"] = {"decision": "fallback", "reason": core_result["error"]}
            self._save(trace)
            return trace
        
        core_parsed = core_result["parsed"]
        trace["core"] = core_parsed
        core_route = core_parsed.get("route", "")
        core_conf = core_parsed.get("confidence", 0)
        
        # ── FASE A: GATE DE CONFIRMACIÓN (si confidence baja) ──
        if should_confirm(self.interactive, core_conf, 0.85, self.force_yes, self.confirm_always):
            hypothesis = build_hypothesis(core_parsed, stimulus)
            if ask_confirmation(hypothesis):
                # Usuario confirma → continuar con el flujo normal
                pass
            else:
                # Usuario rechaza → pedir nueva query
                print("  Por favor, reformula tu consulta.")
                trace["final"] = {"decision": "user_rejected", "reason": "hypothesis_rejected"}
                self._save(trace)
                return trace
        
        # Core dice fallback
        if core_route == "agent_fallback" or core_conf < 0.70:
            trace["final"] = {"decision": "fallback", "reason": "core_requested_fallback"}
            self._save(trace)
            return trace
        
        # Core dice model_new → Router directo
        if core_route == "model_new":
            trace["phase"] = "router"
            provider = self._select_provider(core_parsed)
            query = core_parsed.get("query") or stimulus
            router_result = self._call_router(query, provider)
            
            if router_result["status"] == "ok":
                trace["final"] = {
                    "decision": "model_new", "route": "model_new",
                    "provider": router_result.get("provider", provider),
                    "content": router_result["content"][:500],
                    "tokens": router_result.get("usage", {}).get("total_tokens")
                }
            else:
                trace["final"] = {
                    "decision": "fallback",
                    "reason": f"router_failed: {router_result.get('text', router_result.get('error', '?'))[:100]}"
                }
            self._save(trace)
            return trace
        
        # Core dice edge_match → Edge busca coincidencia
        trace["phase"] = "edge"
        query = core_parsed.get("query") or stimulus
        match = self.matcher.match(query)
        trace["edge_match"] = match
        
        if match.get("matched") and match.get("score", 0) >= 0.75:
            nodo_id = match["top_nodo"]
            resolved = self.resolver.resolve(nodo_id)
            trace["final"] = {
                "decision": "match", "route": "edge_match",
                "nodo": nodo_id, "score": match["score"],
                "content": resolved["content"],
                "content_type": resolved["content_type"]
            }
        else:
            # No hay match → Router
            trace["phase"] = "router"
            provider = self._select_provider(core_parsed)
            router_result = self._call_router(query, provider)
            if router_result["status"] == "ok":
                trace["final"] = {
                    "decision": "model_new", "route": "model_new",
                    "provider": router_result.get("provider", provider),
                    "content": router_result["content"][:500]
                }
            else:
                trace["final"] = {"decision": "fallback", "reason": f"router_failed: {router_result.get('text', '?')[:100]}"}
        
        self._save(trace)
        return trace
    
    def _save(self, trace: dict):
        """Guarda la decisión en memoria sin romper el pipeline."""
        try:
            self.memory.record_decision(trace)
        except Exception:
            pass
