"""Inyección masiva de conocimiento — Expansión 39 a 100+ nodos"""
from pathlib import Path
PROJECT_ROOT = Path(__file__).resolve().parents[1]
import sqlite3
from pathlib import Path

BASE = PROJECT_ROOT
DB = BASE / "memoria" / "core" / "core.db"
KNOWLEDGE = BASE / "knowledge"

def save_node(conn, nodo_id, tipo, label, content_md, disparadores, dominio):
    filename = nodo_id.replace(f"{nodo_id.split("_")[0]}_", "") + ".md"
    file_path = KNOWLEDGE / dominio / filename
    file_path.parent.mkdir(parents=True, exist_ok=True)
    file_path.write_text(content_md, encoding="utf-8")
    rel_path = f"knowledge/{dominio}/{filename}"
    conn.execute("""
        INSERT OR REPLACE INTO nodos 
        (id, tipo, label, descripcion, densidad, activo, creado_por, content_type, content_source) 
        VALUES (?,?,?,?,1.0,1,"expansion_masiva","file",?)
    """, (nodo_id, tipo, label, content_md[:200], rel_path))
    for disp in disparadores:
        conn.execute("""
            INSERT OR IGNORE INTO contexto_activacion 
            (nodo_id, disparador, contexto, prioridad) 
            VALUES (?,?,?,1)
        """, (nodo_id, disp.lower(), "expansion masiva"))

NODOS = []

# EDUCACION
NODOS.extend([
    ("edu_bloom", "concepto", "Taxonomía de Bloom",
     "# Taxonomía de Bloom\n\nJerarquía de niveles cognitivos (Bloom, 1956, revisada 2001).\n\n## Niveles\n1. Recordar\n2. Comprender\n3. Aplicar\n4. Analizar\n5. Evaluar\n6. Crear\n\nUn curso que solo exige recordar no desarrolla pensamiento crítico.",
     ["taxonomia bloom", "bloom", "niveles cognitivos", "aprendizaje jerarquico"], "educacion"),

    ("edu_socratico", "metodo", "Método Socrático",
     "# Método Socrático\n\nIndagación mediante preguntas que guían a descubrir la verdad.\n\n## Estructura\n1. Ironía — fingir ignorancia\n2. Mayéutica — parir ideas\n3. Refutación — exponer contradicciones\n4. Definición — concepto claro\n\nPregunta efectiva: revela supuestos ocultos.",
     ["socratico", "socrates", "mayeutica", "preguntas socraticas", "metodo socratico"], "educacion"),

    ("edu_deliberate", "concepto", "Práctica Deliberada",
     "# Práctica Deliberada\n\nAnders Ericsson: práctica estructurada con objetivo de mejora.\n\n## Características\n- Enfocada en aspectos específicos\n- Feedback inmediato\n- Fuera de zona de confort\n- Repetición con ajuste\n\n10,000 horas de práctica ingenua no producen expertos. 1,000 de deliberada sí.",
     ["practica deliberada", "ericsson", "10000 horas", "deliberate practice", "experticia"], "educacion"),

    ("edu_metacognicion", "concepto", "Metacognición",
     "# Metacognición\n\nPensar sobre el pensar.\n\n## Componentes\n- Conocimiento metacognitivo: saber cómo aprendes\n- Regulación metacognitiva: planificar, monitorear, evaluar\n\nEstudiantes con alta metacognición aprenden 2-3x más rápido.",
     ["metacognicion", "metacognición", "aprender a aprender", "pensar sobre pensar"], "educacion"),

    ("edu_zpd", "concepto", "Zona de Desarrollo Próximo",
     "# Zona de Desarrollo Próximo (ZDP)\n\nVygotsky: distancia entre lo que el aprendiz hace solo y lo que hace con ayuda.\n\n## Tres zonas\n1. Real — independiente\n2. Próxima — con andamiaje\n3. Potencial — fuera de alcance\n\nAprendizaje óptimo ocurre en la ZDP.",
     ["vygotsky", "zdp", "zona desarrollo proximo", "andamiaje", "scaffolding"], "educacion"),

    ("edu_espiral", "metodo", "Currículum en Espiral",
     "# Currículum en Espiral\n\nBruner: temas revisitados con creciente profundidad.\n\nCualquier tema puede enseñarse efectivamente en forma honesta a cualquier niño.\n\nVentajas: refuerza memoria a largo plazo, construye conexiones ricas.",
     ["curriculum espiral", "bruner", "espiral aprendizaje", "spiral curriculum"], "educacion"),

    ("edu_constructivismo", "teoria", "Constructivismo",
     "# Constructivismo\n\nEl conocimiento no se transmite, se construye activamente.\n\n## Pilares\n- Piaget: asimilación y acomodación\n- Vygotsky: dimensión social (ZDP)\n- Ausubel: aprendizaje significativo\n\nEl aprendiz no es vaso vacío.",
     ["constructivismo", "piaget", "aprendizaje activo", "construccion conocimiento"], "educacion"),

    ("edu_flow", "concepto", "Estado de Flow",
     "# Estado de Flow\n\nCsikszentmihalyi: absorción óptima donde se pierde noción del tiempo.\n\n## Condiciones\n1. Claridad de objetivos\n2. Feedback inmediato\n3. Balance desafío/habilidad altos\n4. Fusión acción-consciencia\n\nProductividad en flow: 5x más (McKinsey).",
     ["flow", "flujo", "csikszentmihalyi", "estado de flujo", "optimal experience"], "educacion"),

    ("edu_growth_mindset", "concepto", "Mentalidad de Crecimiento",
     "# Growth Mindset\n\nCarol Dweck: capacidades se pueden desarrollar.\n\n## Fixed mindset\nEvita desafíos, se rinde, esfuerzo inútil.\n\n## Growth mindset\nAbraza desafíos, persiste, esfuerzo como camino.\n\nNo existe 'no sirvo para matemáticas'. Solo 'aún no he practicado'.",
     ["growth mindset", "mentalidad crecimiento", "dweck", "fixed mindset", "neuroplasticidad"], "educacion"),

    ("edu_interleaving", "tecnica", "Interleaving",
     "# Interleaving — Práctica Intercalada\n\nAlternar tipos de problemas durante práctica.\n\n## vs Bloque\nBloque: AAAA BBBB CCCC\nIntercalado: ABC ABC ABC\n\nAprendizaje 25-50% superior aunque se sienta más difícil.",
     ["interleaving", "practica intercalada", "blocked practice", "aprendizaje espaciado"], "educacion"),
])

# TECNICA
NODOS.extend([
    ("tec_git", "herramienta", "Git",
     "# Git\n\nControl de versiones distribuido (Torvalds, 2005).\n\n## Conceptos\n- Commit: snapshot\n- Branch: línea independiente\n- Merge: unir branches\n- Rebase: reescribir historia\n\n## Comandos\ngit init, clone, add, commit, push, pull\ngit branch, checkout, merge, rebase\n\nFilosofía: historia limpia, commits atómicos.",
     ["git", "control versiones", "branch", "commit", "version control"], "tecnica"),

    ("tec_linux", "herramienta", "Linux",
     "# Linux\n\nKernel de Torvalds (1991). Base del 96% de servidores.\n\n## Filosofía Unix\n- Todo es un archivo\n- Una cosa bien\n- Programas que trabajen juntos\n\n## Estructura\n/ raíz, /home usuarios, /etc config, /var datos, /usr programas\n\nPoder: pipes `cat file | grep pattern | wc -l`.",
     ["linux", "unix", "terminal", "shell", "bash", "comandos linux"], "tecnica"),

    ("tec_docker", "herramienta", "Docker",
     "# Docker\n\nPlataforma de contenedores.\n\n## Conceptos\n- Image: plantilla inmutable\n- Container: instancia ejecutándose\n- Dockerfile: receta\n- Registry: repositorio\n\nVentajas:\n- Funciona en mi máquina = funciona en todas\n- Aislamiento de dependencias\n- Despliegue reproducible.",
     ["docker", "contenedores", "dockerfile", "containers", "docker compose"], "tecnica"),

    ("tec_api_rest", "concepto", "API REST",
     "# API REST\n\nRoy Fielding, 2000. Transferencia de estado representacional.\n\n## Principios\n1. Cliente-servidor\n2. Sin estado\n3. Cacheable\n4. Sistema en capas\n5. Interfaz uniforme\n\n## Verbos HTTP\nGET, POST, PUT, PATCH, DELETE\n\nRecursos como sustantivos, verbos HTTP para acciones.",
     ["api rest", "rest", "http", "endpoints", "restful", "rest api"], "tecnica"),

    ("tec_patrones_diseno", "concepto", "Patrones de Diseño",
     "# Patrones de Diseño (GoF, 1994)\n\n## Categorías\nCreacionales: Singleton, Factory, Builder\nEstructurales: Adapter, Decorator, Facade, Proxy\nComportamiento: Observer, Strategy, Command\n\nPrincipio: Programar hacia interfaz, no implementación.\n\nAnti-patrones: God Object, Spaghetti Code.",
     ["patrones diseño", "design patterns", "gof", "singleton", "factory", "observer", "patron diseño"], "tecnica"),

    ("tec_testing", "practica", "Testing de Software",
     "# Testing de Software\n\n## Pirámide\n- Unit 70%: rápidas\n- Integration 20%\n- E2E 10%: lentas\n\n## TDD\n1. Test falla (rojo)\n2. Código mínimo pasa (verde)\n3. Refactorizar\n\n100% coverage no garantiza 0 bugs. <70% garantiza problemas.",
     ["testing", "tests", "tdd", "unit test", "test driven", "pytest", "jest"], "tecnica"),

    ("tec_solid", "principios", "Principios SOLID",
     "# SOLID\n\nS: Single Responsibility\nO: Open/Closed\nL: Liskov Substitution\nI: Interface Segregation\nD: Dependency Inversion\n\nCódigo que se modifica sin romper el sistema.",
     ["solid", "principios solid", "single responsibility", "open closed", "liskov", "diseño oo"], "tecnica"),

    ("tec_http", "protocolo", "HTTP",
     "# HTTP\n\n## Request\nGET /api/users HTTP/1.1\nHost: example.com\n\n## Response\nHTTP/1.1 200 OK\nContent-Type: application/json\n\n## Códigos\n2xx éxito, 4xx error cliente, 5xx error servidor\n\nHTTPS = HTTP + TLS.",
     ["http", "https", "protocolo http", "request response", "headers http"], "tecnica"),

    ("tec_sql", "lenguaje", "SQL",
     "# SQL\n\n## CRUD\nCREATE, INSERT, SELECT, UPDATE, DELETE\n\n## JOINs\nINNER, LEFT, RIGHT, FULL\n\n## Agregaciones\nCOUNT, SUM, AVG, MIN, MAX\nGROUP BY, HAVING\n\nÍndices aceleran SELECT, ralentizan INSERT.",
     ["sql", "base de datos", "query", "join", "select", "relacional", "mysql", "postgres"], "tecnica"),

    ("tec_regex", "herramienta", "Expresiones Regulares",
     "# Regex\n\n## Básico\n. cualquier, \\d dígito, \\w alfanumérico, \\s espacio\n^ inicio, $ fin\n\n## Cuantificadores\n* 0+, + 1+, ? 0-1, {n,m}\n\n## Ejemplos\nEmail: ^[\\w.-]+@[\\w.-]+\\.\\w+$\n\nHerramienta poderosa, abuso peligroso.",
     ["regex", "expresiones regulares", "regular expressions", "patrones texto"], "tecnica"),
])

# TECNICA
NODOS.extend([
    ("tec_git", "herramienta", "Git",
     "# Git\n\nControl de versiones distribuido (Torvalds, 2005).\n\n## Conceptos\n- Commit: snapshot\n- Branch: línea independiente\n- Merge: unir branches\n- Rebase: reescribir historia\n\n## Comandos\ngit init, clone, add, commit, push, pull\ngit branch, checkout, merge, rebase\n\nFilosofía: historia limpia, commits atómicos.",
     ["git", "control versiones", "branch", "commit", "version control"], "tecnica"),

    ("tec_linux", "herramienta", "Linux",
     "# Linux\n\nKernel de Torvalds (1991). Base del 96% de servidores.\n\n## Filosofía Unix\n- Todo es un archivo\n- Una cosa bien\n- Programas que trabajen juntos\n\n## Estructura\n/ raíz, /home usuarios, /etc config, /var datos, /usr programas\n\nPoder: pipes `cat file | grep pattern | wc -l`.",
     ["linux", "unix", "terminal", "shell", "bash", "comandos linux"], "tecnica"),

    ("tec_docker", "herramienta", "Docker",
     "# Docker\n\nPlataforma de contenedores.\n\n## Conceptos\n- Image: plantilla inmutable\n- Container: instancia ejecutándose\n- Dockerfile: receta\n- Registry: repositorio\n\nVentajas:\n- Funciona en mi máquina = funciona en todas\n- Aislamiento de dependencias\n- Despliegue reproducible.",
     ["docker", "contenedores", "dockerfile", "containers", "docker compose"], "tecnica"),

    ("tec_api_rest", "concepto", "API REST",
     "# API REST\n\nRoy Fielding, 2000. Transferencia de estado representacional.\n\n## Principios\n1. Cliente-servidor\n2. Sin estado\n3. Cacheable\n4. Sistema en capas\n5. Interfaz uniforme\n\n## Verbos HTTP\nGET, POST, PUT, PATCH, DELETE\n\nRecursos como sustantivos, verbos HTTP para acciones.",
     ["api rest", "rest", "http", "endpoints", "restful", "rest api"], "tecnica"),

    ("tec_patrones_diseno", "concepto", "Patrones de Diseño",
     "# Patrones de Diseño (GoF, 1994)\n\n## Categorías\nCreacionales: Singleton, Factory, Builder\nEstructurales: Adapter, Decorator, Facade, Proxy\nComportamiento: Observer, Strategy, Command\n\nPrincipio: Programar hacia interfaz, no implementación.\n\nAnti-patrones: God Object, Spaghetti Code.",
     ["patrones diseño", "design patterns", "gof", "singleton", "factory", "observer", "patron diseño"], "tecnica"),

    ("tec_testing", "practica", "Testing de Software",
     "# Testing de Software\n\n## Pirámide\n- Unit 70%: rápidas\n- Integration 20%\n- E2E 10%: lentas\n\n## TDD\n1. Test falla (rojo)\n2. Código mínimo pasa (verde)\n3. Refactorizar\n\n100% coverage no garantiza 0 bugs. <70% garantiza problemas.",
     ["testing", "tests", "tdd", "unit test", "test driven", "pytest", "jest"], "tecnica"),

    ("tec_solid", "principios", "Principios SOLID",
     "# SOLID\n\nS: Single Responsibility\nO: Open/Closed\nL: Liskov Substitution\nI: Interface Segregation\nD: Dependency Inversion\n\nCódigo que se modifica sin romper el sistema.",
     ["solid", "principios solid", "single responsibility", "open closed", "liskov", "diseño oo"], "tecnica"),

    ("tec_http", "protocolo", "HTTP",
     "# HTTP\n\n## Request\nGET /api/users HTTP/1.1\nHost: example.com\n\n## Response\nHTTP/1.1 200 OK\nContent-Type: application/json\n\n## Códigos\n2xx éxito, 4xx error cliente, 5xx error servidor\n\nHTTPS = HTTP + TLS.",
     ["http", "https", "protocolo http", "request response", "headers http"], "tecnica"),

    ("tec_sql", "lenguaje", "SQL",
     "# SQL\n\n## CRUD\nCREATE, INSERT, SELECT, UPDATE, DELETE\n\n## JOINs\nINNER, LEFT, RIGHT, FULL\n\n## Agregaciones\nCOUNT, SUM, AVG, MIN, MAX\nGROUP BY, HAVING\n\nÍndices aceleran SELECT, ralentizan INSERT.",
     ["sql", "base de datos", "query", "join", "select", "relacional", "mysql", "postgres"], "tecnica"),

    ("tec_regex", "herramienta", "Expresiones Regulares",
     "# Regex\n\n## Básico\n. cualquier, \\d dígito, \\w alfanumérico, \\s espacio\n^ inicio, $ fin\n\n## Cuantificadores\n* 0+, + 1+, ? 0-1, {n,m}\n\n## Ejemplos\nEmail: ^[\\w.-]+@[\\w.-]+\\.\\w+$\n\nHerramienta poderosa, abuso peligroso.",
     ["regex", "expresiones regulares", "regular expressions", "patrones texto"], "tecnica"),
])

# COMERCIO
NODOS.extend([
    ("com_mvp", "concepto", "MVP",
     "# MVP — Producto Mínimo Viable\n\nEric Ries (Lean Startup): versión que valida hipótesis con mínimo esfuerzo.\n\n## Tipos\n- Concierge: servicio manual\n- Wizard of Oz: frontend real, backend humano\n- Landing page: validar interés\n- Pre-order: validar con dinero\n\nBuild-Measure-Learn.",
     ["mvp", "lean startup", "minimum viable product", "eric ries", "producto mínimo viable"], "comercio"),

    ("com_unit_economics", "metrica", "Unit Economics",
     "# Unit Economics\n\n## Métricas\nCAC: costo adquisición cliente\nLTV: lifetime value\n\n## Regla\nLTV / CAC > 3\n\nPayback <12 meses.\n\nEscalar unit economics negativas = acelerar quiebra.",
     ["unit economics", "cac", "ltv", "customer acquisition cost", "lifetime value", "payback"], "comercio"),

    ("com_seo_tecnico", "practica", "SEO Técnico",
     "# SEO Técnico\n\n## Velocidad\n- Comprimir imágenes\n- Minificar CSS/JS\n- CDN\n- Lazy loading\n\n## Core Web Vitals\n- LCP < 2.5s\n- FID < 100ms\n- CLS < 0.1",
     ["seo técnico", "core web vitals", "lcp", "velocidad web", "seo tecnico"], "comercio"),

    ("com_pricing", "estrategia", "Estrategias de Pricing",
     "# Estrategias de Pricing\n\n## Modelos\n- Cost-plus\n- Value-based\n- Competitive\n- Freemium\n\n## Psicología\n- $9.99 vs $10\n- Anclaje\n- Decoy pricing\n\nEl precio comunica valor.",
     ["pricing", "precios", "freemium", "value based pricing", "estrategia precios"], "comercio"),

    ("com_copywriting", "habilidad", "Copywriting",
     "# Copywriting\n\n## Fórmulas\nAIDA: Atención, Interés, Deseo, Acción\nPAS: Problema, Agitación, Solución\nFAB: Features, Advantages, Benefits\n\nHablar de TÚ, beneficios > características, verbos activos.",
     ["copywriting", "persuasion", "aida", "copy persuasivo", "escritura persuasiva"], "comercio"),

    ("com_customer_development", "metodo", "Customer Development",
     "# Customer Development\n\nSteve Blank: descubrir clientes antes de construir.\n\n## 4 pasos\n1. Discovery\n2. Validation\n3. Creation\n4. Building\n\nGet out of the building.\n\nMom test: preguntar pasado, no opiniones futuras.",
     ["customer development", "steve blank", "customer discovery", "mom test", "entrevistas clientes"], "comercio"),

    ("com_funnel", "metrica", "Funnel de Conversión",
     "# Funnel de Conversión\n\n## Etapas\n1. Awareness\n2. Interest\n3. Consideration\n4. Intent\n5. Purchase\n6. Loyalty\n\nOptimizar etapa con mayor caída. A/B testing.",
     ["funnel", "conversion funnel", "embudo conversión", "awareness", "customer journey"], "comercio"),

    ("com_network_effects", "concepto", "Efectos de Red",
     "# Network Effects\n\nProducto gana valor con cada usuario.\n\n## Tipos\n- Directos: WhatsApp\n- Indirectos: Uber\n- Datos: Google\n\nLey de Metcalfe: valor ∝ n²\n\nCold start problem.",
     ["network effects", "efectos de red", "metcalfe", "winner takes all", "flywheel"], "comercio"),

    ("com_okr", "framework", "OKRs",
     "# OKRs — Objectives and Key Results\n\nAndy Grove, popularizado por Google.\n\n## Estructura\nObjective: qué (cualitativo)\nKey Results: cómo medir (cuantitativo, 3-5)\n\n70% cumplimiento = éxito.\nTrimestrales. Ambiciosos.",
     ["okr", "objectives key results", "andy grove", "google okr", "metas trimestrales"], "comercio"),

    ("com_product_market_fit", "concepto", "Product-Market Fit",
     "# Product-Market Fit\n\nMarc Andreessen: producto satisface mercado fuerte.\n\n## Señales\n- Crecimiento orgánico\n- Retención alta\n- 40%+ muy decepcionado si desaparece (Sean Ellis)\n\nAntes: no escalar.\nDespués: escalar agresivamente.",
     ["product market fit", "pmf", "marc andreessen", "sean ellis test", "fit producto mercado"], "comercio"),
])

# LEGAL
NODOS.extend([
    ("leg_contrato_tipos", "documento", "Tipos de Contratos",
     "# Tipos de Contratos\n\n## Por objeto\n- Servicios\n- Compraventa\n- Arrendamiento\n- Licencia\n- NDA (confidencialidad)\n\n## Elementos\n- Partes, objeto, precio, plazo, terminación, jurisdicción\n\nLeer TODO antes de firmar.",
     ["contratos", "tipos contratos", "nda", "acuerdo confidencialidad", "servicios profesionales"], "legal"),

    ("leg_propiedad_intelectual", "derecho", "Propiedad Intelectual",
     "# Propiedad Intelectual\n\n## Tipos\n- Derechos de autor: automático, vida + 70\n- Patentes: registro, 20 años\n- Marcas: registro, renovables 10 años\n- Secretos comerciales: NDA\n\n## Open Source\nMIT: permisiva\nGPL: copyleft\nApache: permisiva + patentes.",
     ["propiedad intelectual", "derechos autor", "copyright", "patentes", "marcas", "open source", "licencias"], "legal"),

    ("leg_sociedades", "estructura", "Tipos de Sociedades",
     "# Tipos de Sociedades\n\n## Estructuras\n- EIRL: individual, responsabilidad limitada\n- SpA/Ltda: 2+ socios\n- S.A.: accionistas\n\n## Consideraciones\n- Tributación\n- Responsabilidad\n- Gobernanza\n- Escalabilidad\n\nErrores: no formalizar, mezclar finanzas.",
     ["sociedades", "empresa", "eirl", "spa", "sociedad anónima", "lt da", "estructura legal"], "legal"),

    ("leg_proteccion_datos", "regulacion", "Protección de Datos",
     "# Protección de Datos\n\n## Regulaciones\n- GDPR (Europa)\n- CCPA (California)\n- LGPD (Brasil)\n- Ley 19.628 (Chile)\n\n## Principios\nLicitud, finalidad, minimización, exactitud, limitación temporal, integridad\n\n## Derechos ARCO\nAcceso, Rectificación, Cancelación, Oposición\n\nMultas hasta 4% facturación (GDPR).",
     ["proteccion datos", "gdpr", "rgpd", "privacidad", "arco", "datos personales", "ccpa"], "legal"),

    ("leg_laboral", "derecho", "Derecho Laboral Básico",
     "# Derecho Laboral\n\n## Contratos\n- Indefinido\n- Plazo fijo\n- Por obra\n- Honorarios (NO laboral)\n\n## Elementos laboral\n1. Servicio personal\n2. Subordinación\n3. Remuneración\n\nFalsa honorariedad = problema legal.",
     ["derecho laboral", "contrato trabajo", "laboral", "despido", "honorarios", "jornada laboral"], "legal"),

    ("leg_fiscal", "regulacion", "Obligaciones Tributarias",
     "# Obligaciones Tributarias\n\n## Impuestos\n- IVA 19%\n- Renta\n- PPM\n- Contribuciones\n\n## Regímenes Chile\n- 14 A atribuida\n- 14 B semi-integrado\n- 14 C Pro Pyme\n- 14 D transparente\n\nPlanificar, no evadir.",
     ["impuestos", "tributario", "fiscal", "iva", "renta", "sii", "obligaciones tributarias"], "legal"),

    ("leg_terminos_servicio", "documento", "Términos de Servicio",
     "# Términos de Servicio (ToS)\n\n## Elementos\n1. Aceptación\n2. Uso permitido\n3. Restricciones\n4. Propiedad intelectual\n5. Limitación responsabilidad\n6. Terminación\n7. Ley aplicable\n8. Disputas\n\nClaro y legible. Revisión legal.",
     ["términos de servicio", "tos", "terms of service", "condiciones uso", "cláusulas"], "legal"),
])


# EJECUCION
conn = sqlite3.connect(DB)
stats = {"educacion": 0, "tecnica": 0, "comercio": 0, "legal": 0}

for nodo_id, tipo, label, content, disparadores, dominio in NODOS:
    save_node(conn, nodo_id, tipo, label, content, disparadores, dominio)
    stats[dominio] += 1

conn.commit()

total = conn.execute("SELECT COUNT(*) FROM nodos WHERE activo=1").fetchone()[0]
inline = conn.execute("SELECT COUNT(*) FROM nodos WHERE activo=1 AND (content_type='inline' OR content_type IS NULL)").fetchone()[0]
file_nodes = conn.execute("SELECT COUNT(*) FROM nodos WHERE activo=1 AND content_type='file'").fetchone()[0]
disparadores = conn.execute("SELECT COUNT(*) FROM contexto_activacion").fetchone()[0]

print("=" * 60)
print("  INYECCIÓN MASIVA COMPLETADA")
print("=" * 60)
print(f"\nNuevos nodos inyectados:")
print(f"  Educación: {stats['educacion']}")
print(f"  Técnica:   {stats['tecnica']}")
print(f"  Comercio:  {stats['comercio']}")
print(f"  Legal:     {stats['legal']}")
print(f"  Total nuevo: {sum(stats.values())}")

print(f"\nEstado total:")
print(f"  Nodos activos: {total}")
print(f"  Inline (fundacionales): {inline}")
print(f"  File (conocimiento): {file_nodes}")
print(f"  Disparadores totales: {disparadores}")

print(f"\nArchivos en /knowledge/:")
for dom in ["educacion", "tecnica", "comercio", "legal"]:
    files = list((KNOWLEDGE / dom).glob("*.md"))
    print(f"  {dom:10s}: {len(files)} archivos")

print(f"\nResultado: {'SUPERADO' if total >= 100 else 'En camino'} ({total} nodos)")
print("=" * 60)
conn.close()
