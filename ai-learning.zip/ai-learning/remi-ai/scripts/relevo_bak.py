#!/usr/bin/env python3
"""
relevo.py — Genera el bloque de contexto de inicio para una sesión nueva.

Uso:
    python3 scripts/relevo.py            # imprime a stdout
    python3 scripts/relevo.py --save     # guarda a 00-docs/RELEVO-<fecha>.md

Lee:
    - 00-docs/MEMORIA.md (documento vivo de relevo)
    - memoria/core/core.db (estado del grafo + nodo protocolo_apertura_sesion)
    - Servicios: Ollama :11434, LiteLLM :4000

Genera un bloque de texto listo para pegar al inicio de un hilo nuevo.
La memoria vive en el grafo y en MEMORIA.md, no en el historial de conversación.
"""

import sqlite3
import sys
from datetime import datetime
from pathlib import Path
from urllib.request import urlopen
from urllib.error import URLError

# ── Rutas (P1: memoria = rutas · P2: actualizar casa) ──
PROJECT_ROOT = Path(__file__).resolve().parents[1]
DB_PATH = PROJECT_ROOT / "memoria" / "core" / "core.db"
MEMORIA_PATH = PROJECT_ROOT / "00-docs" / "MEMORIA.md"
DOCS_DIR = PROJECT_ROOT / "00-docs"

SERVICES = {
    "Ollama :11434": "http://localhost:11434/api/tags",
    "LiteLLM :4000": "http://localhost:4000/health/liveliness",
}


def check_service(url, timeout=2):
    """Verifica si un servicio responde. Retorna True/False."""
    try:
        with urlopen(url, timeout=timeout) as r:
            return r.status == 200
    except (URLError, OSError):
        return False


def get_graph_state():
    """Consulta el estado real del grafo. Retorna dict o None."""
    if not DB_PATH.exists():
        return None
    c = sqlite3.connect(str(DB_PATH))
    state = {
        "nodos": c.execute("SELECT COUNT(*) FROM nodos WHERE activo=1").fetchone()[0],
        "aristas": c.execute("SELECT COUNT(*) FROM aristas").fetchone()[0],
        "huerfanos": c.execute("""
            SELECT COUNT(*) FROM nodos n
            LEFT JOIN aristas a1 ON a1.nodo_origen=n.id
            LEFT JOIN aristas a2 ON a2.nodo_destino=n.id
            WHERE n.activo=1 AND a1.id IS NULL AND a2.id IS NULL
        """).fetchone()[0],
        "integridad": c.execute("PRAGMA integrity_check").fetchone()[0],
    }
    c.close()
    return state


def get_protocolo():
    """Recupera el nodo protocolo_apertura_sesion del grafo."""
    if not DB_PATH.exists():
        return None
    c = sqlite3.connect(str(DB_PATH))
    row = c.execute(
        "SELECT descripcion FROM nodos WHERE id='protocolo_apertura_sesion'"
    ).fetchone()
    c.close()
    return row[0] if row else None


def get_principios():
    """Lista los principios operativos del grafo."""
    if not DB_PATH.exists():
        return []
    c = sqlite3.connect(str(DB_PATH))
    rows = c.execute(
        "SELECT id, label FROM nodos WHERE id LIKE 'principio_%' ORDER BY id"
    ).fetchall()
    c.close()
    return rows


def extract_section(text, header, stop_headers):
    """Extrae una sección del MEMORIA.md entre header y el siguiente header de stop."""
    lines = text.split("\n")
    capturing = False
    result = []
    for line in lines:
        if capturing:
            if line.strip().startswith("## ") and any(h.lower() in line.lower() for h in stop_headers):
                break
            result.append(line)
        elif line.strip().startswith("## ") and header.lower() in line.lower():
            capturing = True
    return "\n".join(result).strip()


def read_memoria():
    """Lee MEMORIA.md y extrae secciones clave."""
    if not MEMORIA_PATH.exists():
        return None
    text = MEMORIA_PATH.read_text(encoding="utf-8")
    return {
        "estado": extract_section(text, "ESTADO TÉCNICO VERIFICADO", ["LO QUE SE ARREGLÓ", "DEUDA"]),
        "deuda": extract_section(text, "DEUDA TÉCNICA ABIERTA", ["PRINCIPIOS"]),
        "siguiente": extract_section(text, "SIGUIENTE", []),
    }


def build_relevo():
    """Construye el bloque de relevo."""
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    out = []
    out.append("═══ RELEVO DE SESIÓN ═══")
    out.append(f"Fecha: {now}")

    # Estado de servicios
    services_status = {name: check_service(url) for name, url in SERVICES.items()}
    all_up = all(services_status.values())
    out.append(f"Estado general: {'i5 operativo' if all_up else 'i5 DEGRADADO (ver servicios)'}")
    for name, up in services_status.items():
        out.append(f"  {name}: {'✅ activo' if up else '❌ caído'}")

    # Estado del grafo
    state = get_graph_state()
    out.append("")
    if state:
        out.append(f"Nodos: {state['nodos']} | Aristas: {state['aristas']} | "
                   f"Huérfanos: {state['huerfanos']} | Integridad: {state['integridad']}")
    else:
        out.append("⚠️  core.db no accesible")

    # Protocolo vigente (desde el grafo, no hardcodeado)
    protocolo = get_protocolo()
    out.append("")
    out.append("═══ PROTOCOLO VIGENTE ═══")
    out.append(protocolo if protocolo else "⚠️  nodo protocolo_apertura_sesion no encontrado")

    # Principios operativos (desde el grafo)
    principios = get_principios()
    out.append("")
    out.append("═══ PRINCIPIOS OPERATIVOS ═══")
    if principios:
        for i, (pid, label) in enumerate(principios, 1):
            out.append(f"P{i} · {label}")
    else:
        out.append("⚠️  sin principios en el grafo")

    # Estado técnico + deuda + pendientes (desde MEMORIA.md)
    memoria = read_memoria()
    out.append("")
    out.append("═══ ESTADO TÉCNICO ═══")
    out.append(memoria["estado"] if memoria and memoria["estado"] else "⚠️  MEMORIA.md sin sección de estado")

    out.append("")
    out.append("═══ DEUDA TÉCNICA ═══")
    out.append(memoria["deuda"] if memoria and memoria["deuda"] else "⚠️  sin sección de deuda")

    out.append("")
    out.append("═══ PENDIENTES ═══")
    out.append(memoria["siguiente"] if memoria and memoria["siguiente"] else "⚠️  sin sección de pendientes")

    out.append("")
    out.append("═══ OBJETIVO ═══")
    out.append("[a confirmar por el usuario]")
    out.append("")
    out.append("─" * 50)
    out.append("Regla: hilo nuevo por sesión, este relevo pegado al inicio.")
    out.append("La memoria vive en el grafo y en MEMORIA.md, no en el historial.")

    return "\n".join(out)


def main():
    save = "--save" in sys.argv
    relevo = build_relevo()

    if save:
        DOCS_DIR.mkdir(parents=True, exist_ok=True)
        fecha = datetime.now().strftime("%Y-%m-%d")
        out_path = DOCS_DIR / f"RELEVO-{fecha}.md"
        out_path.write_text(relevo, encoding="utf-8")
        print(f"✅ Relevo guardado en {out_path}")
    else:
        print(relevo)


if __name__ == "__main__":
    main()
