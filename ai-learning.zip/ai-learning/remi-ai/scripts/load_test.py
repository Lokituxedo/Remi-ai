#!/usr/bin/env python3
import asyncio, aiohttp, time, statistics, argparse

URL = "http://localhost:8080/api/litellm/v1/chat/completions"
PROMPT = ("Escribe un resumen técnico detallado de ~300 palabras sobre topología de "
          "redes distribuidas con Tailscale. Párrafos, sin viñetas.")

async def fetch(s, model):
    t0 = time.perf_counter()
    try:
        async with s.post(URL, json={"model": model,
            "messages":[{"role":"user","content":PROMPT}], "stream":False}, timeout=40) as r:
            d = await r.json()
            src = d.get("model", model)
            return {"ok": r.status==200, "lat": time.perf_counter()-t0, "src": src}
    except Exception as e:
        return {"ok": False, "lat": time.perf_counter()-t0, "src": str(e)[:40]}

async def run(n, model):
    async with aiohttp.ClientSession() as s:
        res = await asyncio.gather(*[fetch(s, model) for _ in range(n)])
    ok = [r for r in res if r["ok"]]; err = [r for r in res if not r["ok"]]
    print(f"\n🚀 N={n} | model={model}")
    print(f"   ✅ {len(ok)} | ❌ {len(err)}")
    if ok:
        lat=[r["lat"] for r in ok]
        print(f"   ⏱ Media {statistics.mean(lat):.2f}s | Mín {min(lat):.2f}s | Máx {max(lat):.2f}s")
        print(f"   🔀 Fuentes: {set(r['src'] for r in ok)}")
    if err: print(f"   ⚠ {err[0]['src']}")

if __name__=="__main__":
    p=argparse.ArgumentParser(); p.add_argument("--n",type=int,default=5); p.add_argument("--model",default="remi-generator")
    a=p.parse_args(); asyncio.run(run(a.n,a.model))
