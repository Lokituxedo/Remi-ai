#!/usr/bin/env python3
"""
relevo.py — Genera el bloque de contexto de inicio para una sesión nueva.
Versión mejorada con detección robusta de rutas y extracción precisa de secciones.
"""
import sqlite3
import sys
import os
import json
import logging
from datetime import datetime
from pathlib import Path
from urllib.request import urlopen
from urllib.error import URLError, HTTPError

# ── Configuración de logging ──
logging.basicConfig(
    level=logging.INFO,
    format='%(levelname)s: %(message)s'
)
logger = logging.getLogger(__name__)

# ── Detección robusta de raíz del proyecto ──
def find_project_root() -> Path:
    """Busca directorio con 'memoria/core/core.db' subiendo desde __file__."""
    current = Path(__file__).resolve().parent
    for parent in [current] + list(current.parents):
        if (parent / "memoria" / "core" / "core.db").exists():
            return parent
    raise RuntimeError(
        "No se encontró raíz del proyecto (falta memoria/core/core.db). "
        "Verifica que el script esté dentro del árbol del proyecto."
    )

PROJECT_ROOT = find_project_root()
DB_PATH = PROJECT_ROOT / "memoria" / "core" / "core.db"
MEMORIA_PATH = PROJECT_ROOT / "00-docs" / "MEMORIA.md"
DOCS_DIR = PROJECT_ROOT / "00-docs"

# ── Configuración desde variables de entorno ──
OLLAMA_PORT = os.getenv("OLLAMA_PORT", "11434")
LITELLM_PORT = os.getenv("LITELLM_PORT", "4000")

SERVICES = {
    f"Ollama :{OLLAMA_PORT}": f"http://localhost:{OLLAMA_PORT}/api/tags",
    f"LiteLLM :{LITELLM_PORT}": f"http://localhost:{LITELLM_PORT}/health/liveliness",
}

def check_service(url: str, timeout: int = 2) -> bool:
    """Verifica si un servicio responde. Retorna True/False."""
    try:
        with urlopen(url, timeout=timeout) as r:
            return r.status == 200
    except (URLError, HTTPError, OSError, TimeoutError) as e:
        logger.debug(f"Servicio {url} no responde: {e}")
        return False
    except Exception as e:
        logger.warning(f"Error inesperado verificando {url}: {e}")
        return False

def get_graph_state(conn: sqlite3.Connection) -> dict:
    """Consulta el estado real del grafo con métricas enriquecidas."""
    try:
        state = {
            "nodos": conn.execute("SELECT COUNT(*) FROM nodos WHERE activo=1").fetchone()[0],
            "aristas": conn.execute("SELECT COUNT(*) FROM aristas").fetchone()[0],
            "huerfanos": conn.execute("""
                SELECT COUNT(*) FROM nodos n
                LEFT JOIN aristas a1 ON a1.nodo_origen=n.id
                LEFT JOIN aristas a2 ON a2.nodo_destino=n.id
                WHERE n.activo=1 AND a1.id IS NULL AND a2.id IS NULL
            """).fetchone()[0],
            "integridad": conn.execute("PRAGMA integrity_check").fetchone()[0],
            "top_activados": [
                dict(r) for r in conn.execute("""
                    SELECT n.id, n.label, m.activaciones
                    FROM metricas_nodo m
                    JOIN nodos n ON n.id=m.nodo_id
                    ORDER BY m.activaciones DESC LIMIT 5
                """).fetchall()
            ],
            "aristas_huerfanas": conn.execute("""
                SELECT COUNT(*) FROM aristas a
                LEFT JOIN nodos n1 ON n1.id=a.nodo_origen
                LEFT JOIN nodos n2 ON n2.id=a.nodo_destino
                WHERE n1.id IS NULL OR n2.id IS NULL
            """).fetchone()[0],
        }
        return state
    except sqlite3.Error as e:
        logger.error(f"Error consultando estado del grafo: {e}")
        return None

def get_protocolo(conn: sqlite3.Connection) -> str | None:
    """Recupera el nodo protocolo_apertura_sesion del grafo."""
    try:
        row = conn.execute(
            "SELECT descripcion FROM nodos WHERE id='protocolo_apertura_sesion'"
        ).fetchone()
        return row[0] if row else None
    except sqlite3.Error as e:
        logger.error(f"Error recuperando protocolo: {e}")
        return None

def get_principios(conn: sqlite3.Connection) -> list[tuple[str, str]]:
    """Lista los principios operativos del grafo con fallback a MEMORIA.md."""
    try:
        rows = conn.execute(
            "SELECT id, label FROM nodos WHERE id LIKE 'principio_%' ORDER BY id"
        ).fetchall()
        if rows:
            return [(r[0], r[1]) for r in rows]
    except sqlite3.Error as e:
        logger.warning(f"Error consultando principios en grafo: {e}")
    
    # Fallback: extraer de MEMORIA.md
    if MEMORIA_PATH.exists():
        try:
            text = MEMORIA_PATH.read_text(encoding="utf-8")
            section = extract_section(text, "PRINCIPIOS OPERATIVOS", ["SIGUIENTE"])
            if section:
                principios = []
                for line in section.split("\n"):
                    line = line.strip()
                    if line and line[0].isdigit() and '.' in line[:3]:
                        partes = line.split(".", 1)
                        if len(partes) == 2:
                            pid = f"principio_{partes[0].strip()}"
                            label = partes[1].strip()
                            if label:  # Solo agregar si no está vacío
                                principios.append((pid, label))
                return principios
        except Exception as e:
            logger.warning(f"Error leyendo principios de MEMORIA.md: {e}")
    
    return []

def extract_section(text: str, header: str, stop_headers: list[str]) -> str:
    """Extrae una sección del MEMORIA.md con match exacto del header."""
    lines = text.split("\n")
    capturing = False
    result = []
    target = f"## {header}"
    
    for line in lines:
        stripped = line.strip()
        if capturing:
            if stripped.startswith("## "):
                if any(stripped.startswith(f"## {h}") for h in stop_headers):
                    break
            result.append(line)
        elif stripped == target:
            capturing = True
    
    content = "\n".join(result).strip()
    return content if content else None

def read_memoria() -> dict | None:
    """Lee MEMORIA.md y extrae secciones clave."""
    if not MEMORIA_PATH.exists():
        logger.warning(f"MEMORIA.md no existe en {MEMORIA_PATH}")
        return None
    
    try:
        text = MEMORIA_PATH.read_text(encoding="utf-8")
        return {
            "estado": extract_section(text, "ESTADO TÉCNICO VERIFICADO", ["LO QUE SE ARREGLÓ", "DEUDA"]),
            "deuda": extract_section(text, "DEUDA TÉCNICA ABIERTA", ["PRINCIPIOS"]),
            "siguiente": extract_section(text, "SIGUIENTE", []),
        }
    except Exception as e:
        logger.error(f"Error leyendo MEMORIA.md: {e}")
        return None

def build_relevo(formato: str = "text") -> str | dict:
    """Construye el bloque de relevo en formato texto o JSON."""
    now = datetime.now().isoformat()
    
    # Abrir conexión única
    conn = None
    if DB_PATH.exists():
        try:
            conn = sqlite3.connect(str(DB_PATH))
            conn.row_factory = sqlite3.Row  # Para acceso por nombre de columna
        except sqlite3.Error as e:
            logger.error(f"Error conectando a core.db: {e}")
            conn = None
    
    try:
        # Estado de servicios
        services_status = {name: check_service(url) for name, url in SERVICES.items()}
        all_up = all(services_status.values())
        
        # Estado del grafo
        state = get_graph_state(conn) if conn else None
        
        # Protocolo vigente
        protocolo = get_protocolo(conn) if conn else None
        
        # Principios operativos
        principios = get_principios(conn) if conn else []
        
        # Estado técnico + deuda + pendientes
        memoria = read_memoria()
        
        if formato == "json":
            return {
                "timestamp": now,
                "servicios": services_status,
                "estado_general": "i5 operativo" if all_up else "i5 DEGRADADO",
                "grafo": state,
                "protocolo": protocolo,
                "principios": [{"id": p[0], "label": p[1]} for p in principios],
                "memoria": memoria,
            }
        
        # Formato texto
        out = []
        out.append("═══ RELEVO DE SESIÓN ═══")
        out.append(f"Fecha: {now}")
        out.append(f"Estado general: {'i5 operativo' if all_up else 'i5 DEGRADADO (ver servicios)'}")
        for name, up in services_status.items():
            out.append(f"  {name}: {'✅ activo' if up else '❌ caído'}")
        
        out.append("")
        if state:
            out.append(f"Nodos: {state['nodos']} | Aristas: {state['aristas']} | "
                      f"Huérfanos: {state['huerfanos']} | Integridad: {state['integridad']}")
            out.append(f"Aristas huérfanas: {state['aristas_huerfanas']}")
            if state['top_activados']:
                out.append("Top nodos activados:")
                for nodo in state['top_activados'][:3]:
                    out.append(f"  - {nodo['label']}: {nodo['activaciones']} activaciones")
        else:
            out.append("⚠️  core.db no accesible")
        
        out.append("")
        out.append("═══ PROTOCOLO VIGENTE ═══")
        out.append(protocolo if protocolo else "⚠️  nodo protocolo_apertura_sesion no encontrado")
        
        out.append("")
        out.append("═══ PRINCIPIOS OPERATIVOS ═══")
        if principios:
            for i, (pid, label) in enumerate(principios, 1):
                out.append(f"P{i} · {label}")
        else:
            out.append("⚠️  sin principios en el grafo")
        
        out.append("")
        out.append("═══ ESTADO TÉCNICO ═══")
        out.append(memoria["estado"] if memoria and memoria["estado"] else "⚠️  MEMORIA.md sin sección de estado")
        
        out.append("")
        out.append("═══ DEUDA TÉCNICA ═══")
        out.append(memoria["deuda"] if memoria and memoria["deuda"] else "⚠️  sin sección de deuda")
        
        out.append("")
        out.append("═══ PENDIENTES ═══")
        out.append(memoria["siguiente"] if memoria and memoria["siguiente"] else "⚠️  sin sección de pendientes")
        
        out.append("")
        out.append("═══ OBJETIVO ═══")
        out.append("[a confirmar por el usuario]")
        
        out.append("")
        out.append("─" * 50)
        out.append("Regla: hilo nuevo por sesión, este relevo pegado al inicio.")
        out.append("La memoria vive en el grafo y en MEMORIA.md, no en el historial.")
        
        return "\n".join(out)
    
    finally:
        if conn:
            try:
                conn.close()
            except Exception as e:
                logger.warning(f"Error cerrando conexión SQLite: {e}")

def main():
    save = "--save" in sys.argv
    json_output = "--json" in sys.argv
    
    formato = "json" if json_output else "text"
    
    try:
        relevo = build_relevo(formato)
        
        if save:
            DOCS_DIR.mkdir(parents=True, exist_ok=True)
            fecha = datetime.now().strftime("%Y-%m-%d")
            ext = "json" if json_output else "md"
            out_path = DOCS_DIR / f"RELEVO-{fecha}.{ext}"
            
            try:
                if json_output:
                    out_path.write_text(json.dumps(relevo, indent=2, ensure_ascii=False), encoding="utf-8")
                else:
                    out_path.write_text(relevo, encoding="utf-8")
                
                print(f"✅ Relevo guardado en {out_path}")
            except PermissionError:
                logger.error(f"Sin permisos para escribir en {out_path}")
                sys.exit(1)
            except Exception as e:
                logger.error(f"Error guardando relevo: {e}")
                sys.exit(1)
        else:
            if json_output:
                print(json.dumps(relevo, indent=2, ensure_ascii=False))
            else:
                print(relevo)
    
    except Exception as e:
        logger.error(f"Error inesperado en main(): {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
