#!/usr/bin/env python3
import asyncio, aiohttp, time, statistics

URL = "http://localhost:8080/api/litellm/v1/chat/completions"
# Payload pesado: fuerza la generación de ~300-400 tokens
HEAVY_PROMPT = "Escribe un resumen técnico detallado de 300 palabras sobre la topología de redes distribuidas, incluyendo ventajas, desventajas y un ejemplo de implementación con Tailscale. No uses viñetas, solo párrafos."

PAYLOAD = {
    "model": "remi-generator", 
    "messages": [{"role": "user", "content": HEAVY_PROMPT}], 
    "stream": False
}
CONCURRENCY = [1, 3, 5] # Reducimos N porque cada petición tomará ~10-15s

async def fetch(session, req_id):
    start = time.perf_counter()
    try:
        # Timeout de aiohttp en 35s para capturar el fallo de LiteLLM (30s)
        async with session.post(URL, json=PAYLOAD, timeout=35) as resp:
            latency = time.perf_counter() - start
            return {"id": req_id, "status": resp.status, "latency": latency, "error": None}
    except Exception as e:
        return {"id": req_id, "status": 0, "latency": time.perf_counter() - start, "error": str(e)}

async def run_test(n):
    print(f"\n🚀 Iniciando prueba PESADA con N={n} peticiones concurrentes...")
    async with aiohttp.ClientSession() as session:
        tasks = [fetch(session, i) for i in range(n)]
        results = await asyncio.gather(*tasks)
    
    latencies = [r["latency"] for r in results if r["error"] is None]
    errors = [r for r in results if r["error"] is not None or r["status"] >= 400]
    
    print(f"   ✅ Éxitos: {len(latencies)} | ❌ Errores/Timeouts: {len(errors)}")
    if latencies:
        print(f"   ⏱️  Latencia -> Media: {statistics.mean(latencies):.2f}s | Mín: {min(latencies):.2f}s | Máx: {max(latencies):.2f}s")
    if errors:
        print(f"   ⚠️  Errores detectados: {errors[0]['error'] or 'HTTP '+str(errors[0]['status'])}")

async def main():
    for n in CONCURRENCY:
        await run_test(n)
        print("   ⏳ Pausa de 5s para vaciar la cola de Ollama...\n")
        await asyncio.sleep(5)

if __name__ == "__main__":
    asyncio.run(main())
