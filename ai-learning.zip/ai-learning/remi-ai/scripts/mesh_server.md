#!/usr/bin/env python3
import http.server, socketserver, urllib.request, urllib.error, json, os

PORT = 8080
BIND = "0.0.0.0"
LITELLM_URL = "http://localhost:4000"
OLLAMA_URL = "http://localhost:11434"

DASHBOARD_HTML = r"""<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Remi-AI | Mesh Dashboard</title>
<script src="https://cdn.tailwindcss.com"></script>
<style>
.scrollbar-thin::-webkit-scrollbar{width:4px}.scrollbar-thin::-webkit-scrollbar-thumb{background:#4b5563;border-radius:4px}
.tab-active{border-bottom:2px solid #3b82f6;color:#3b82f6;font-weight:600}.tab-inactive{color:#9ca3af}.tab-inactive:hover{color:#d1d5db}
.msg{max-width:92%;padding:10px 14px;border-radius:12px;font-size:13px;line-height:1.5;word-wrap:break-word;white-space:pre-wrap}
.msg.user{align-self:flex-end;background:#3b82f6;color:#fff;border-bottom-right-radius:4px}
.msg.agent{align-self:flex-start;background:#1e293b;color:#e2e8f0;border-bottom-left-radius:4px;border:1px solid #334155}
.msg.error{align-self:flex-start;background:#451a1a;color:#fca5a5;border:1px solid #7f1d1d}
.msg.system{align-self:center;background:#1a1a2e;color:#94a3b8;font-size:11px;border:1px solid #334155}
.pulse{animation:pulse 1.5s infinite}@keyframes pulse{0%,100%{opacity:1}50%{opacity:.4}}
</style>
</head>
<body class="bg-gray-950 text-gray-100 font-sans min-h-screen flex flex-col">
<header class="bg-gray-900 border-b border-gray-800 p-3 sticky top-0 z-50">
<div class="max-w-4xl mx-auto flex justify-between items-center">
  <h1 class="text-base font-bold text-blue-400 flex items-center gap-2">
    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/></svg>
    Remi-AI Mesh
  </h1>
  <div class="flex items-center gap-2">
    <span id="status-dot" class="w-2 h-2 rounded-full bg-gray-600"></span>
    <span id="status-text" class="text-[10px] text-gray-500">idle</span>
    <input type="file" id="memoriaInput" accept=".md" class="hidden">
    <label for="memoriaInput" class="cursor-pointer bg-purple-700 hover:bg-purple-600 text-white px-2 py-1 rounded text-[10px] font-medium">MEMORIA</label>
  </div>
</div>
</header>
<div class="bg-gray-900 border-b border-gray-800 sticky top-12 z-40">
<div class="max-w-4xl mx-auto flex gap-4 px-3 overflow-x-auto scrollbar-thin">
  <button onclick="switchTab('command')" id="tab-command" class="tab-active py-2 px-1 text-xs whitespace-nowrap">Comando</button>
  <button onclick="switchTab('test')" id="tab-test" class="tab-inactive py-2 px-1 text-xs whitespace-nowrap">Pruebas</button>
  <button onclick="switchTab('memory')" id="tab-memory" class="tab-inactive py-2 px-1 text-xs whitespace-nowrap">Memoria</button>
</div>
</div>
<main class="flex-1 max-w-4xl mx-auto w-full p-3 space-y-3">
<div id="view-command" class="space-y-3">
  <div class="bg-gray-900 border border-gray-800 rounded-xl p-4">
    <h2 class="text-xs font-semibold text-white mb-3">Nodos de la Malla</h2>
    <div class="grid gap-2">
      <div class="bg-gray-950 p-3 rounded-lg border border-gray-800">
        <div class="text-[10px] text-green-400 uppercase tracking-wide mb-1">i5 — Servidor Principal</div>
        <div class="grid grid-cols-2 gap-1 text-[11px] font-mono text-gray-400"><span>LAN: 192.168.100.9</span><span>TS: 100.98.229.45</span></div>
      </div>
      <div class="bg-gray-950 p-3 rounded-lg border border-blue-900/40">
        <div class="text-[10px] text-blue-400 uppercase tracking-wide mb-1">i7 — mpe-server (Dev)</div>
        <div class="grid grid-cols-2 gap-1 text-[11px] font-mono text-gray-400"><span>LAN: 192.168.100.10</span><span>TS: 100.78.87.77</span></div>
      </div>
      <div class="bg-gray-950 p-3 rounded-lg border border-gray-800">
        <div class="text-[10px] text-gray-500 uppercase tracking-wide mb-1">Androids (x2)</div>
        <div class="text-[11px] font-mono text-gray-500">Acceso vía Tailscale 100.98.229.45:8080</div>
      </div>
    </div>
  </div>
  <div class="bg-gray-900 border border-gray-800 rounded-xl p-4">
    <h2 class="text-xs font-semibold text-white mb-2">Rutas del Proyecto</h2>
    <div class="space-y-1 text-[11px] font-mono text-gray-400">
      <div class="flex justify-between"><span>Local:</span><span class="text-green-400">/home/mpeadmin/karukren/remi-ai/</span></div>
      <div class="flex justify-between"><span>SFTP:</span><span class="text-blue-400">sftp://mpeadmin@remi-i5/home/mpeadmin/karukren/remi-ai/</span></div>
    </div>
  </div>
</div>
<div id="view-test" class="hidden flex flex-col" style="height:calc(100vh - 120px)">
  <div class="bg-gray-900 border border-gray-800 rounded-xl p-3 flex-1 flex flex-col">
    <div class="flex justify-between items-center mb-2 gap-2">
      <select id="provider-select" onchange="loadModels()" class="bg-gray-950 border border-gray-700 text-white text-[11px] rounded px-2 py-1.5 outline-none flex-shrink-0">
        <option value="litellm">LiteLLM :4000</option>
        <option value="ollama">Ollama :11434</option>
      </select>
      <select id="model-select" class="bg-gray-950 border border-gray-700 text-white text-[11px] rounded px-2 py-1.5 outline-none flex-shrink-0">
        <option value="">Cargando modelos...</option>
      </select>
      <button onclick="clearChat()" class="text-[10px] text-gray-500 hover:text-red-400 px-2 py-1">Limpiar</button>
    </div>
    <div id="chat-area" class="flex-1 overflow-y-auto scrollbar-thin space-y-2 mb-2 pr-1 flex flex-col"></div>
    <div class="flex gap-2">
      <input type="text" id="prompt-input" placeholder="Escribe tu comando..." class="flex-1 bg-gray-950 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-blue-500">
      <button onclick="sendMessage()" id="send-btn" class="bg-blue-600 hover:bg-blue-700 text-white px-4 rounded-lg text-sm font-medium">Enviar</button>
    </div>
  </div>
</div>
<div id="view-memory" class="hidden space-y-3">
  <div class="relative">
    <svg class="w-4 h-4 absolute left-3 top-2.5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
    <input type="text" id="searchInput" placeholder="Buscar en MEMORIA.md..." class="w-full bg-gray-900 border border-gray-800 rounded-lg pl-9 pr-4 py-2 text-xs focus:ring-1 focus:ring-blue-500 outline-none">
  </div>
  <div id="memoria-display" class="bg-gray-900 border border-gray-800 rounded-xl p-4 text-[11px] text-gray-300 font-mono whitespace-pre-wrap max-h-[60vh] overflow-y-auto scrollbar-thin">
    <span class="text-gray-600 italic">Carga MEMORIA.md con el botón superior.</span>
  </div>
</div>
</main>
<script>
let memoriaText="";
function switchTab(t){
  ['command','test','memory'].forEach(x=>{
    document.getElementById('view-'+x).classList.add('hidden');
    document.getElementById('tab-'+x).classList.remove('tab-active');
    document.getElementById('tab-'+x).classList.add('tab-inactive');
  });
  document.getElementById('view-'+t).classList.remove('hidden');
  document.getElementById('tab-'+t).classList.remove('tab-inactive');
  document.getElementById('tab-'+t).classList.add('tab-active');
}
function setStatus(s,c){
  document.getElementById('status-dot').className='w-2 h-2 rounded-full '+(c||'bg-gray-600');
  document.getElementById('status-text').textContent=s;
}
function appendMsg(role,text){
  const a=document.getElementById('chat-area');
  const d=document.createElement('div');
  d.className='msg '+role;
  d.textContent=text;
  a.appendChild(d);
  a.scrollTop=a.scrollHeight;
  return d;
}
function clearChat(){document.getElementById('chat-area').innerHTML='';}
async function loadModels(){
  const provider=document.getElementById('provider-select').value;
  const modelSelect=document.getElementById('model-select');
  modelSelect.innerHTML='<option value="">Cargando...</option>';
  try{
    let models=[];
    if(provider==='litellm'){
      const res=await fetch('/api/litellm/v1/models');
      const data=await res.json();
      models=data.data?.map(m=>m.id)||[];
    }else if(provider==='ollama'){
      const res=await fetch('/api/ollama/api/tags');
      const data=await res.json();
      models=data.models?.map(m=>m.name)||[];
    }
    if(models.length===0){modelSelect.innerHTML='<option value="">Sin modelos disponibles</option>';return;}
    if(provider==='litellm'){
      const combos=['remi-router','remi-generator'];
      combos.forEach(c=>{
        if(models.includes(c)){
          const opt=document.createElement('option');
          opt.value=c;opt.textContent=`🎯 ${c} (combo)`;opt.style.color='#3b82f6';
          modelSelect.appendChild(opt);
        }
      });
    }
    models.forEach(m=>{
      const opt=document.createElement('option');
      opt.value=m;opt.textContent=m;
      modelSelect.appendChild(opt);
    });
    modelSelect.value=models[0];
  }catch(err){modelSelect.innerHTML='<option value="">Error al cargar</option>';}
}
async function sendMessage(){
  const input=document.getElementById('prompt-input');
  const prompt=input.value.trim();
  if(!prompt)return;
  appendMsg('user',prompt);
  input.value='';
  const loading=appendMsg('agent','⏳ Procesando...');
  loading.classList.add('pulse');
  setStatus('enviando...','bg-yellow-500');
  const provider=document.getElementById('provider-select').value;
  const model=document.getElementById('model-select').value;
  const endpoint=provider==='ollama'?'/api/ollama/v1/chat/completions':'/api/litellm/v1/chat/completions';
  const payload={model:model,messages:[{role:'user',content:prompt}],stream:false};
  try{
    const t0=performance.now();
    const res=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
    const elapsed=((performance.now()-t0)/1000).toFixed(1);
    const data=await res.json();
    loading.remove();
    if(!res.ok)throw new Error(data.error?.message||JSON.stringify(data));
    const reply=data.choices?.[0]?.message?.content||JSON.stringify(data);
    appendMsg('agent',reply);
    appendMsg('system',provider+' | '+model+' | '+elapsed+'s');
    setStatus('idle','bg-green-500');
  }catch(err){
    loading.remove();
    appendMsg('error','Error: '+err.message);
    setStatus('error','bg-red-500');
  }
}
document.getElementById('prompt-input').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();sendMessage();}});
document.getElementById('memoriaInput').addEventListener('change',e=>{
  const f=e.target.files[0];if(!f)return;
  const r=new FileReader();
  r.onload=ev=>{memoriaText=ev.target.result;document.getElementById('memoria-display').textContent=memoriaText;};
  r.readAsText(f);
});
document.getElementById('searchInput').addEventListener('input',e=>{
  const q=e.target.value.toLowerCase();
  if(!q||!memoriaText){document.getElementById('memoria-display').textContent=memoriaText||'Carga MEMORIA.md...';return;}
  const lines=memoriaText.split('\n').filter(l=>l.toLowerCase().includes(q));
  document.getElementById('memoria-display').innerHTML=lines.length>0
    ?lines.map(l=>'<span class="text-yellow-300">'+l.replace(new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),'gi'),m=>'<mark class="bg-yellow-900 text-yellow-100 rounded px-0.5">'+m+'</mark>')+'</span>').join('\n')
    :'<span class="text-gray-600">Sin coincidencias.</span>';
});
setStatus('idle','bg-green-500');
loadModels();
</script>
</body>
</html>"""

class MeshHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, format, *args): print(f"[{self.log_date_time_string()}] {args[0]}")
    def do_OPTIONS(self):
        self.send_response(200); self._cors_headers(); self.end_headers()
    def do_GET(self):
        if self.path in ["/", "/dashboard"]:
            self.send_response(200); self.send_header("Content-Type", "text/html; charset=utf-8"); self._cors_headers(); self.end_headers()
            self.wfile.write(DASHBOARD_HTML.encode("utf-8"))
        elif self.path.startswith("/api/litellm"): self._proxy_get(LITELLM_URL + self.path.replace("/api/litellm", ""))
        elif self.path.startswith("/api/ollama"): self._proxy_get(OLLAMA_URL + self.path.replace("/api/ollama", ""))
        else: super().do_GET()
    def do_POST(self):
        if self.path.startswith("/api/litellm"): self._proxy(LITELLM_URL + self.path.replace("/api/litellm", ""))
        elif self.path.startswith("/api/ollama"): self._proxy(OLLAMA_URL + self.path.replace("/api/ollama", ""))
        else: self.send_error(404)
    def _cors_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*"); self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS"); self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
    def _proxy_get(self, target_url):
        try:
            req = urllib.request.Request(target_url, method="GET")
            if "Authorization" in self.headers: req.add_header("Authorization", self.headers["Authorization"])
            with urllib.request.urlopen(req, timeout=10) as resp:
                self.send_response(resp.status); self.send_header("Content-Type", resp.headers.get("Content-Type", "application/json")); self._cors_headers(); self.end_headers(); self.wfile.write(resp.read())
        except Exception as e:
            self.send_response(502); self.send_header("Content-Type", "application/json"); self._cors_headers(); self.end_headers(); self.wfile.write(json.dumps({"error": str(e)}).encode())
    def _proxy(self, target_url):
        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length) if content_length > 0 else b""
        req = urllib.request.Request(target_url, data=body, method="POST")
        req.add_header("Content-Type", "application/json")
        if "Authorization" in self.headers: req.add_header("Authorization", self.headers["Authorization"])
        try:
            with urllib.request.urlopen(req, timeout=120) as resp:
                self.send_response(resp.status); self.send_header("Content-Type", resp.headers.get("Content-Type", "application/json")); self._cors_headers(); self.end_headers(); self.wfile.write(resp.read())
        except urllib.error.HTTPError as e:
            self.send_response(e.code); self.send_header("Content-Type", "application/json"); self._cors_headers(); self.end_headers(); self.wfile.write(e.read())
        except Exception as e:
            self.send_response(502); self.send_header("Content-Type", "application/json"); self._cors_headers(); self.end_headers(); self.wfile.write(json.dumps({"error": str(e)}).encode())

def main():
    socketserver.TCPServer.allow_reuse_address = True
    os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    with socketserver.TCPServer((BIND, PORT), MeshHandler) as httpd:
        print(f"✅ Remi-AI Mesh Dashboard activo en http://{BIND}:{PORT}")
        print(f"   ├── Proxy LiteLLM: /api/litellm/* → {LITELLM_URL}")
        print(f"   └── Proxy Ollama:  /api/ollama/* → {OLLAMA_URL}")
        try: httpd.serve_forever()
        except KeyboardInterrupt: print("\n️ Servidor detenido.")

if __name__ == "__main__": main()
