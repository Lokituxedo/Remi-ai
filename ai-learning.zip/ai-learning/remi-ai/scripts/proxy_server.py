#!/usr/bin/env python3
import http.server
import socketserver
import urllib.request
import urllib.error

PORT = 8080
LITELLM_URL = "http://localhost:4000"
OLLAMA_URL = "http://localhost:11434"

class RemiProxyHandler(http.server.SimpleHTTPRequestHandler):
    # 1. Manejar pre-flight de CORS (aunque el proxy lo hace innecesario, es buena práctica)
    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.end_headers()

    # 2. Intercepta peticiones POST hacia /api/litellm o /api/ollama
    def do_POST(self):
        if self.path.startswith("/api/litellm"):
            target = LITELLM_URL + self.path.replace("/api/litellm", "")
            self._proxy(target, "POST")
        elif self.path.startswith("/api/ollama"):
            target = OLLAMA_URL + self.path.replace("/api/ollama", "")
            self._proxy(target, "POST")
        else:
            # Si no es API, sirve el archivo estático (mesh-dashboard.html)
            super().do_POST()

    def _proxy(self, target_url, method):
        content_length = int(self.headers.get('Content-Length', 0))
        post_data = self.rfile.read(content_length) if content_length > 0 else b''
        
        req = urllib.request.Request(target_url, data=post_data, method=method)
        req.add_header("Content-Type", "application/json")
        
        if "Authorization" in self.headers:
            req.add_header("Authorization", self.headers["Authorization"])

        try:
            with urllib.request.urlopen(req) as response:
                self.send_response(response.status)
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Content-Type", response.headers.get("Content-Type", "application/json"))
                self.end_headers()
                self.wfile.write(response.read())
        except urllib.error.HTTPError as e:
            self.send_response(e.code)
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(e.read())
        except Exception as e:
            self.send_error(502, f"Proxy Error: {str(e)}")

# Permitir reutilizar el puerto inmediatamente al reiniciar
socketserver.TCPServer.allow_reuse_address = True

with socketserver.TCPServer(("", PORT), RemiProxyHandler) as httpd:
    print(f"✅ Remi-AI Proxy Server activo en http://0.0.0.0:{PORT}")
    print("   ├── Estáticos: sirviendo desde directorio actual")
    print("   ├── Proxy LiteLLM: /api/litellm/* → localhost:4000")
    print("   └── Proxy Ollama:  /api/ollama/* → localhost:11434")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n⏹️ Servidor detenido.")