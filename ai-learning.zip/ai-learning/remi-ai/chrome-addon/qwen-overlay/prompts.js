const LIMIT = 7000;

export function clip(text, max = LIMIT) {
  const t = String(text || "")
    .replace(/\s+\n/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
  if (t.length <= max) return t;
  return `${t.slice(0, max).trim()}\n\n[…]`;
}

export function detectLang() {
  const lang = (navigator.language || "es").toLowerCase();
  return lang.startsWith("es") ? "es" : "en";
}

export function buildPrompt(action, ctx, question) {
  const body = clip(ctx.selection || ctx.content);
  const sel = clip(ctx.selection, 2500);
  const es = ctx.lang === "es";
  const header = es
    ? `Título: ${ctx.title}\nURL: ${ctx.url}`
    : `Title: ${ctx.title}\nURL: ${ctx.url}`;

  switch (action) {
    case "summarize":
      return es
        ? `Resume esta página con claridad. Incluye: idea principal, 4–6 puntos clave y una conclusión breve.\n\n${header}\n\nContenido:\n${clip(ctx.content)}`
        : `Summarize this page clearly. Include: main idea, 4–6 key points, and a short conclusion.\n\n${header}\n\nContent:\n${clip(ctx.content)}`;
    case "translate":
      return es
        ? `Traduce al español el siguiente contenido. Conserva el tono, los nombres propios y el formato.\n\n${header}\n\n${body}`
        : `Translate the following content into English. Keep tone, proper names, and formatting.\n\n${header}\n\n${body}`;
    case "explain":
      return es
        ? `Explica este fragmento de forma sencilla, como si se lo contaras a alguien inteligente que no es experto en el tema. Si hay jerga, defínela.\n\n${header}\n\nFragmento:\n${sel || body}`
        : `Explain this passage in plain language, as if to a smart non-expert. Define jargon.\n\n${header}\n\nPassage:\n${sel || body}`;
    case "rewrite":
      return es
        ? `Reescribe este texto para que sea más claro, conciso y profesional, sin cambiar el significado.\n\n${sel || body}`
        : `Rewrite this text so it is clearer, tighter, and more professional, without changing the meaning.\n\n${sel || body}`;
    case "keypoints":
      return es
        ? `Extrae los puntos clave de esta página como una lista priorizada. Marca hechos, opiniones y acciones sugeridas.\n\n${header}\n\n${clip(ctx.content)}`
        : `Extract the key points of this page as a prioritized list. Mark facts, opinions, and suggested actions.\n\n${header}\n\n${clip(ctx.content)}`;
    case "code":
      return es
        ? `Analiza este código o fragmento técnico. Explica qué hace, señala posibles errores y sugiere una versión mejorada si aplica.\n\n${header}\n\n${sel || body}`
        : `Analyze this code or technical snippet. Explain what it does, flag likely bugs, and suggest an improved version if useful.\n\n${header}\n\n${sel || body}`;
    case "ask":
    default:
      return es
        ? `Estoy leyendo «${ctx.title}» (${ctx.url}).\n\nPregunta: ${(question || "").trim() || "¿Cuál es la idea principal?"}\n\nContexto de la página:\n${clip(ctx.selection || ctx.content)}`
        : `I'm reading “${ctx.title}” (${ctx.url}).\n\nQuestion: ${(question || "").trim() || "What is the main idea?"}\n\nPage context:\n${clip(ctx.selection || ctx.content)}`;
  }
}

export function studioUrl(prompt) {
  const encoded = encodeURIComponent(prompt);
  if (encoded.length < 1800) {
    return { url: `https://chat.qwen.ai/?text=${encoded}`, mode: "url" };
  }
  return { url: "https://chat.qwen.ai/", mode: "storage" };
}

export function extractPage() {
  const title = document.title || "";
  const url = location.href;
  const selection = (window.getSelection && window.getSelection().toString().trim()) || "";
  const article =
    document.querySelector("article") ||
    document.querySelector("main") ||
    document.querySelector("[role='main']") ||
    document.body;
  const content = clip((article && article.innerText) || "", 9000);
  return { title, url, selection, content, lang: detectLang() };
}
