import { buildPrompt, studioUrl } from "./prompts.js";

chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false }).catch(() => undefined);

  chrome.contextMenus.removeAll(() => {
    const items = [
      { id: "open", title: "Abrir Qwen Overlay" },
      { id: "summarize", title: "Resumir página con Qwen" },
      { id: "explain", title: "Explicar selección con Qwen" },
      { id: "translate", title: "Traducir con Qwen" },
      { id: "rewrite", title: "Reescribir selección con Qwen" },
      { id: "ask", title: "Preguntar a Qwen sobre esto" },
    ];
    for (const item of items) {
      chrome.contextMenus.create({
        id: item.id,
        title: item.title,
        contexts: item.id === "open" || item.id === "summarize" ? ["page", "selection"] : ["selection", "page"],
      });
    }
  });
});

chrome.action.onClicked.addListener(async (tab) => {
  if (tab.id) await toggleOnTab(tab.id);
});

chrome.commands.onCommand.addListener(async (command, tab) => {
  if (command === "toggle-overlay" && tab?.id) await toggleOnTab(tab.id);
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (!tab?.id) return;
  if (info.menuItemId === "open") {
    await toggleOnTab(tab.id, true);
    return;
  }
  const action = String(info.menuItemId);
  const selection = info.selectionText || "";
  await chrome.tabs.sendMessage(tab.id, { type: "QWEN_ACTION", action, selection }).catch(async () => {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["content.js"],
    });
    await chrome.tabs.sendMessage(tab.id, { type: "QWEN_ACTION", action, selection });
  });
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "QWEN_SEND") {
    void sendToStudio(message.prompt).then(sendResponse);
    return true;
  }
  if (message?.type === "QWEN_OPEN_PANEL") {
    const tabId = _sender.tab?.id;
    if (tabId) {
      void chrome.sidePanel.open({ tabId }).then(() => sendResponse({ ok: true }));
      return true;
    }
  }
  return false;
});

async function toggleOnTab(tabId, forceOpen = false) {
  try {
    await chrome.tabs.sendMessage(tabId, { type: "QWEN_TOGGLE", forceOpen });
  } catch {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
    await chrome.tabs.sendMessage(tabId, { type: "QWEN_TOGGLE", forceOpen });
  }
}

async function sendToStudio(prompt) {
  const { url, mode } = studioUrl(prompt);
  await chrome.storage.local.set({
    pendingPrompt: mode === "storage" ? prompt : "",
    pendingAt: Date.now(),
  });
  const tab = await chrome.tabs.create({ url, active: true });
  return { ok: true, tabId: tab.id, mode };
}

export { buildPrompt };
