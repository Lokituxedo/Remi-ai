Qwen Overlay — cómo instalar
============================

1. Descomprime este ZIP. Quedará una carpeta con manifest.json dentro.
2. Abre Chrome y ve a: chrome://extensions
3. Activa «Modo de desarrollador» (arriba a la derecha).
4. Pulsa «Cargar descomprimida» y elige esa carpeta.
5. Fija el icono en la barra. En cualquier página: Alt+Q, o clic derecho
   sobre un texto → «Preguntar a Qwen».

El complemento abre Qwen Studio (chat.qwen.ai). Si el sitio pide sesión,
usa tu cuenta de Qwen. No hace falta API key.

Qwen Overlay no es un producto de Alibaba; solo abre el Studio oficial.
