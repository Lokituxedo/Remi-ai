(() => {
  if (window.__qwenOverlayInjected) return;
  window.__qwenOverlayInjected = true;
  if (/(^|\.)qwen\.ai$/i.test(location.hostname)) return;

  const LIMIT = 7000;
  const lang = (navigator.language || "es").toLowerCase().startsWith("es") ? "es" : "en";

  const t =
    lang === "es"
      ? {
          name: "Qwen Overlay",
          actions: "Acciones",
          studio: "Studio",
          selected: "Selección",
          none: "Nada seleccionado — se usará la página completa.",
          summarize: "Resumir",
          translate: "Traducir",
          explain: "Explicar",
          rewrite: "Reescribir",
          keypoints: "Puntos clave",
          code: "Analizar código",
          ask: "Pregunta sobre esta página",
          ph: "¿Cuál es la tesis? ¿Qué cambiarías?",
          send: "Enviar a Qwen Studio",
          copy: "Copiar prompt",
          copied: "Copiado",
          ready: "Prompt listo",
          chars: "caracteres",
          words: "palabras",
          close: "Cerrar",
          studioTitle: "Studio oficial",
          studioBody:
            "El panel incrusta Qwen Studio. Si el sitio no carga aquí, se abre en una pestaña con el prompt preparado.",
          studioOpen: "Abrir en pestaña",
          embed: "Cargar Studio aquí",
        }
      : {
          name: "Qwen Overlay",
          actions: "Actions",
          studio: "Studio",
          selected: "Selection",
          none: "Nothing selected — the whole page will be used.",
          summarize: "Summarize",
          translate: "Translate",
          explain: "Explain",
          rewrite: "Rewrite",
          keypoints: "Key points",
          code: "Review code",
          ask: "Ask about this page",
          ph: "What’s the thesis? What would you change?",
          send: "Send to Qwen Studio",
          copy: "Copy prompt",
          copied: "Copied",
          ready: "Prompt ready",
          chars: "characters",
          words: "words",
          close: "Close",
          studioTitle: "Official Studio",
          studioBody:
            "The panel embeds Qwen Studio. If it will not load here, it opens in a tab with the prompt ready.",
          studioOpen: "Open in a tab",
          embed: "Load Studio here",
        };

  function clip(text, max = LIMIT) {
    const v = String(text || "")
      .replace(/\s+\n/g, "\n")
      .replace(/\n{3,}/g, "\n\n")
      .trim();
    if (v.length <= max) return v;
    return `${v.slice(0, max).trim()}\n\n[…]`;
  }

  function extract(selectionOverride) {
    const title = document.title || "";
    const url = location.href;
    const selection =
      selectionOverride ||
      (window.getSelection && window.getSelection().toString().trim()) ||
      "";
    const article =
      document.querySelector("article") ||
      document.querySelector("main") ||
      document.querySelector("[role='main']") ||
      document.body;
    const content = clip((article && article.innerText) || "", 9000);
    return { title, url, selection, content, lang };
  }

  function buildPrompt(action, ctx, question) {
    const body = clip(ctx.selection || ctx.content);
    const sel = clip(ctx.selection, 2500);
    const es = ctx.lang === "es";
    const header = es
      ? `Título: ${ctx.title}\nURL: ${ctx.url}`
      : `Title: ${ctx.title}\nURL: ${ctx.url}`;
    switch (action) {
      case "summarize":
        return es
          ? `Resume esta página con claridad. Incluye: idea principal, 4–6 puntos clave y una conclusión breve.\n\n${header}\n\nContenido:\n${clip(ctx.content)}`
          : `Summarize this page clearly. Include: main idea, 4–6 key points, and a short conclusion.\n\n${header}\n\nContent:\n${clip(ctx.content)}`;
      case "translate":
        return es
          ? `Traduce al español el siguiente contenido. Conserva el tono, los nombres propios y el formato.\n\n${header}\n\n${body}`
          : `Translate the following content into English. Keep tone, proper names, and formatting.\n\n${header}\n\n${body}`;
      case "explain":
        return es
          ? `Explica este fragmento de forma sencilla. Si hay jerga, defínela.\n\n${header}\n\nFragmento:\n${sel || body}`
          : `Explain this passage in plain language. Define jargon.\n\n${header}\n\nPassage:\n${sel || body}`;
      case "rewrite":
        return es
          ? `Reescribe este texto para que sea más claro, conciso y profesional, sin cambiar el significado.\n\n${sel || body}`
          : `Rewrite this text so it is clearer, tighter, and more professional, without changing the meaning.\n\n${sel || body}`;
      case "keypoints":
        return es
          ? `Extrae los puntos clave de esta página como una lista priorizada.\n\n${header}\n\n${clip(ctx.content)}`
          : `Extract the key points of this page as a prioritized list.\n\n${header}\n\n${clip(ctx.content)}`;
      case "code":
        return es
          ? `Analiza este código o fragmento técnico. Explica qué hace, señala posibles errores y sugiere una versión mejorada si aplica.\n\n${header}\n\n${sel || body}`
          : `Analyze this code or technical snippet. Explain what it does, flag likely bugs, and suggest an improved version if useful.\n\n${header}\n\n${sel || body}`;
      default:
        return es
          ? `Estoy leyendo «${ctx.title}» (${ctx.url}).\n\nPregunta: ${(question || "").trim() || "¿Cuál es la idea principal?"}\n\nContexto de la página:\n${clip(ctx.selection || ctx.content)}`
          : `I'm reading “${ctx.title}” (${ctx.url}).\n\nQuestion: ${(question || "").trim() || "What is the main idea?"}\n\nPage context:\n${clip(ctx.selection || ctx.content)}`;
    }
  }

  const CSS = `
    :host { all: initial; }
    * { box-sizing: border-box; font-family: "Figtree", "Segoe UI", system-ui, sans-serif; }
    .root { position: fixed; inset: 0; pointer-events: none; z-index: 2147483646; }
    .fab {
      pointer-events: auto;
      position: fixed; right: 20px; bottom: 20px;
      width: 52px; height: 52px; border: 0; border-radius: 999px;
      background: #2f5e56; color: #f3efe6; cursor: pointer;
      display: grid; place-items: center;
      box-shadow: 0 18px 40px -20px rgba(0,0,0,.5);
      transition: transform 150ms ease-out, opacity 150ms ease-out;
    }
    .fab:hover { transform: scale(1.03); }
    .fab:active { transform: scale(0.96); }
    .fab.hidden { opacity: 0; pointer-events: none; }
    .panel {
      pointer-events: auto;
      position: fixed; top: 12px; right: 12px; bottom: 12px;
      width: min(400px, calc(100vw - 24px));
      background: #161513; color: #f3efe6;
      border-radius: 20px;
      box-shadow: 0 0 0 1px rgba(243,239,230,.1), 0 24px 60px -20px rgba(0,0,0,.55);
      display: flex; flex-direction: column;
      transform: translateX(12px); opacity: 0;
      transition: transform 250ms cubic-bezier(.22,1,.36,1), opacity 250ms cubic-bezier(.22,1,.36,1);
    }
    .panel.open { transform: none; opacity: 1; }
    .head { display: flex; align-items: center; gap: 12px; padding: 16px 16px 12px; }
    .meta { min-width: 0; flex: 1; }
    .meta strong { display: block; font-size: 14px; font-weight: 500; }
    .meta span { display: block; font-size: 12px; color: #a39e94; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .x {
      width: 40px; height: 40px; border: 0; background: transparent; color: #a39e94;
      border-radius: 10px; cursor: pointer;
    }
    .x:hover { background: #2a2622; color: #f3efe6; }
    .tabs { margin: 0 16px; display: grid; grid-template-columns: 1fr 1fr; background: #1f1c19; padding: 4px; border-radius: 12px; }
    .tabs button {
      height: 36px; border: 0; background: transparent; color: #a39e94;
      border-radius: 10px; font-size: 13px; font-weight: 500; cursor: pointer;
    }
    .tabs button.on { background: #2a2622; color: #f3efe6; }
    .body { flex: 1; min-height: 0; overflow: auto; padding: 16px; display: flex; flex-direction: column; gap: 16px; }
    .sel { background: #1f1c19; border-radius: 14px; padding: 10px 12px; }
    .sel small { display: block; font-size: 11px; letter-spacing: .08em; text-transform: uppercase; color: #a39e94; }
    .sel p { margin: 6px 0 0; font-size: 13px; line-height: 1.4; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden; }
    .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
    .act {
      height: 44px; border: 0; border-radius: 12px; background: #1f1c19; color: #f3efe6;
      font-size: 13px; font-weight: 500; cursor: pointer; text-align: left; padding: 0 12px;
    }
    .act.on { background: #f3efe6; color: #161513; }
    .act:hover:not(.on) { background: #2a2622; }
    label span { display: block; font-size: 12px; color: #a39e94; margin-bottom: 6px; }
    textarea {
      width: 100%; min-height: 84px; resize: none; border: 0; border-radius: 14px;
      background: #1f1c19; color: #f3efe6; padding: 10px 12px; font: inherit; font-size: 14px; line-height: 1.5;
    }
    textarea:focus { outline: none; background: #2a2622; }
    .send {
      height: 48px; width: 100%; border: 0; border-radius: 14px; background: #f3efe6; color: #161513;
      font-size: 15px; font-weight: 500; cursor: pointer;
    }
    .copy, .ghost {
      height: 40px; width: 100%; border: 0; background: transparent; color: #a39e94;
      font-size: 13px; cursor: pointer;
    }
    .copy:hover, .ghost:hover { color: #f3efe6; }
    .hint { text-align: center; font-size: 11px; color: #a39e94; }
    .status { text-align: center; font-size: 12px; color: #d5e4df; }
    iframe { flex: 1; width: 100%; border: 0; background: #111; border-radius: 12px; }
    .studio { display: flex; flex-direction: column; gap: 12px; height: 100%; }
    .studio h3 { margin: 0; font-size: 22px; font-weight: 500; font-family: Georgia, serif; }
    .studio p { margin: 0; font-size: 13px; line-height: 1.55; color: #a39e94; }
    @media (max-width: 640px) {
      .panel { top: auto; height: min(78vh, 640px); border-radius: 20px 20px 16px 16px; }
    }
    @media (prefers-reduced-motion: reduce) {
      .panel, .fab { transition: none; }
    }
  `;

  const host = document.createElement("div");
  host.id = "qwen-overlay-host";
  const shadow = host.attachShadow({ mode: "open" });
  const wrap = document.createElement("div");
  wrap.className = "root";
  wrap.innerHTML = `
    <style>${CSS}</style>
    <button class="fab" type="button" aria-label="${t.name}">
      <svg width="22" height="22" viewBox="0 0 32 32" aria-hidden="true">
        <rect x="3" y="4" width="14" height="22" rx="2.5" fill="#f3efe6"/>
        <rect x="12" y="7" width="16" height="18" rx="2.5" fill="#161513"/>
        <rect x="15.5" y="11" width="9" height="1.7" rx=".8" fill="#f3efe6"/>
        <rect x="15.5" y="15" width="6.5" height="1.3" rx=".6" fill="#f3efe6" opacity=".45"/>
      </svg>
    </button>
    <aside class="panel" role="dialog" aria-label="${t.name}">
      <div class="head">
        <svg width="32" height="32" viewBox="0 0 32 32" aria-hidden="true">
          <rect width="32" height="32" rx="8" fill="#2f5e56"/>
          <rect x="5.5" y="6" width="14" height="20" rx="2.5" fill="#f3efe6"/>
          <rect x="12" y="8.5" width="14.5" height="17" rx="2.5" fill="#161513"/>
          <rect x="15" y="12" width="8.5" height="1.6" rx=".8" fill="#f3efe6"/>
        </svg>
        <div class="meta">
          <strong>${t.name}</strong>
          <span class="hostline"></span>
        </div>
        <button class="x" type="button" aria-label="${t.close}">✕</button>
      </div>
      <div class="tabs">
        <button type="button" data-tab="actions" class="on">${t.actions}</button>
        <button type="button" data-tab="studio">${t.studio}</button>
      </div>
      <div class="body" data-pane="actions">
        <div class="sel"><small>${t.selected}</small><p class="seltext">${t.none}</p></div>
        <div class="grid">
          <button class="act on" data-act="summarize">${t.summarize}</button>
          <button class="act" data-act="translate">${t.translate}</button>
          <button class="act" data-act="explain">${t.explain}</button>
          <button class="act" data-act="rewrite">${t.rewrite}</button>
          <button class="act" data-act="keypoints">${t.keypoints}</button>
          <button class="act" data-act="code">${t.code}</button>
        </div>
        <label>
          <span>${t.ask}</span>
          <textarea class="q" placeholder="${t.ph}"></textarea>
        </label>
        <div>
          <button class="send" type="button">${t.send}</button>
          <button class="copy" type="button">${t.copy}</button>
          <p class="hint chars"></p>
          <p class="status"></p>
        </div>
      </div>
      <div class="body studio" data-pane="studio" hidden>
        <div>
          <h3>${t.studioTitle}</h3>
          <p>${t.studioBody}</p>
        </div>
        <iframe class="frame" hidden title="Qwen Studio" allow="clipboard-write"></iframe>
        <button class="send embed" type="button">${t.embed}</button>
        <button class="ghost open-tab" type="button">${t.studioOpen}</button>
      </div>
    </aside>
  `;
  shadow.appendChild(wrap);
  document.documentElement.appendChild(host);

  const panel = shadow.querySelector(".panel");
  const fab = shadow.querySelector(".fab");
  const hostline = shadow.querySelector(".hostline");
  const seltext = shadow.querySelector(".seltext");
  const chars = shadow.querySelector(".chars");
  const status = shadow.querySelector(".status");
  const q = shadow.querySelector(".q");
  const frame = shadow.querySelector(".frame");
  let open = false;
  let active = "summarize";
  let forcedSelection = "";

  function pageCtx() {
    return extract(forcedSelection);
  }

  function currentPrompt() {
    const ctx = pageCtx();
    const action = q.value.trim() && active === "ask" ? "ask" : active;
    return buildPrompt(q.value.trim() ? "ask" : action, ctx, q.value);
  }

  function refresh() {
    const ctx = pageCtx();
    let hostName = ctx.url;
    try {
      hostName = new URL(ctx.url).hostname;
    } catch {
      /* keep */
    }
    const words = (ctx.content.trim().match(/\S+/g) || []).length;
    hostline.textContent = `${hostName} · ${words} ${t.words}`;
    seltext.textContent = ctx.selection || t.none;
    const prompt = currentPrompt();
    chars.textContent = `${t.ready} · ${prompt.length} ${t.chars}`;
  }

  function setOpen(next) {
    open = next;
    panel.classList.toggle("open", open);
    fab.classList.toggle("hidden", open);
    if (open) {
      forcedSelection = extract().selection;
      refresh();
    }
  }

  fab.addEventListener("click", () => setOpen(true));
  shadow.querySelector(".x").addEventListener("click", () => setOpen(false));

  shadow.querySelectorAll("[data-tab]").forEach((btn) => {
    btn.addEventListener("click", () => {
      shadow.querySelectorAll("[data-tab]").forEach((b) => b.classList.toggle("on", b === btn));
      shadow.querySelectorAll("[data-pane]").forEach((p) => {
        p.hidden = p.getAttribute("data-pane") !== btn.getAttribute("data-tab");
      });
    });
  });

  shadow.querySelectorAll("[data-act]").forEach((btn) => {
    btn.addEventListener("click", () => {
      active = btn.getAttribute("data-act");
      shadow.querySelectorAll("[data-act]").forEach((b) => b.classList.toggle("on", b === btn));
      status.textContent = "";
      refresh();
    });
  });

  q.addEventListener("input", () => {
    active = "ask";
    shadow.querySelectorAll("[data-act]").forEach((b) => b.classList.remove("on"));
    refresh();
  });

  document.addEventListener("mouseup", () => {
    if (!open) return;
    const sel = window.getSelection()?.toString().trim();
    if (sel) {
      forcedSelection = sel;
      refresh();
    }
  });

  async function sendPrompt() {
    const prompt = currentPrompt();
    status.textContent = "";
    try {
      await navigator.clipboard.writeText(prompt);
    } catch {
      /* ignore */
    }
    chrome.runtime.sendMessage({ type: "QWEN_SEND", prompt }, () => undefined);
    status.textContent = lang === "es" ? "Abriendo Qwen Studio…" : "Opening Qwen Studio…";
  }

  shadow.querySelector(".send").addEventListener("click", () => void sendPrompt());
  shadow.querySelector(".open-tab").addEventListener("click", () => void sendPrompt());
  shadow.querySelector(".copy").addEventListener("click", async () => {
    await navigator.clipboard.writeText(currentPrompt());
    shadow.querySelector(".copy").textContent = t.copied;
    setTimeout(() => {
      shadow.querySelector(".copy").textContent = t.copy;
    }, 1400);
  });
  shadow.querySelector(".embed").addEventListener("click", () => {
    const prompt = currentPrompt();
    const encoded = encodeURIComponent(prompt);
    frame.hidden = false;
    frame.src =
      encoded.length < 1800 ? `https://chat.qwen.ai/?text=${encoded}` : "https://chat.qwen.ai/";
    if (encoded.length >= 1800) {
      chrome.storage.local.set({ pendingPrompt: prompt, pendingAt: Date.now() });
    }
  });

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === "QWEN_TOGGLE") {
      setOpen(msg.forceOpen ? true : !open);
    }
    if (msg?.type === "QWEN_ACTION") {
      forcedSelection = msg.selection || extract().selection;
      active = msg.action || "summarize";
      shadow.querySelectorAll("[data-act]").forEach((b) =>
        b.classList.toggle("on", b.getAttribute("data-act") === active),
      );
      setOpen(true);
      if (msg.action && msg.action !== "ask") void sendPrompt();
    }
  });
})();
