(() => {
  const MAX_TRIES = 24;

  function findInput() {
    const nodes = [
      ...document.querySelectorAll("textarea"),
      ...document.querySelectorAll("[contenteditable='true']"),
    ];
    return (
      nodes.find((el) => {
        const r = el.getBoundingClientRect();
        return r.width > 80 && r.height > 20 && r.bottom > 0;
      }) || null
    );
  }

  function setValue(el, text) {
    if (el instanceof HTMLTextAreaElement || el instanceof HTMLInputElement) {
      const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const desc = Object.getOwnPropertyDescriptor(proto, "value");
      desc?.set?.call(el, text);
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
      return;
    }
    el.focus();
    el.textContent = text;
    el.dispatchEvent(new InputEvent("input", { bubbles: true, data: text }));
  }

  async function fill(prompt) {
    for (let i = 0; i < MAX_TRIES; i += 1) {
      const el = findInput();
      if (el) {
        el.focus();
        setValue(el, prompt);
        return true;
      }
      await new Promise((r) => setTimeout(r, 250));
    }
    return false;
  }

  async function run() {
    if (!chrome?.storage?.local) return;
    const { pendingPrompt, pendingAt } = await chrome.storage.local.get(["pendingPrompt", "pendingAt"]);
    if (!pendingPrompt) return;
    if (pendingAt && Date.now() - pendingAt > 120000) {
      await chrome.storage.local.remove(["pendingPrompt", "pendingAt"]);
      return;
    }
    const ok = await fill(pendingPrompt);
    if (ok) await chrome.storage.local.remove(["pendingPrompt", "pendingAt"]);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => void run());
  } else {
    void run();
  }
})();
