async function currentTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

document.getElementById("overlay").addEventListener("click", async () => {
  const tab = await currentTab();
  if (tab?.id) {
    await chrome.tabs.sendMessage(tab.id, { type: "QWEN_TOGGLE", forceOpen: true }).catch(async () => {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
      await chrome.tabs.sendMessage(tab.id, { type: "QWEN_TOGGLE", forceOpen: true });
    });
  }
  window.close();
});

document.getElementById("studio").addEventListener("click", async () => {
  const tab = await currentTab();
  if (tab?.id) await chrome.sidePanel.open({ tabId: tab.id }).catch(() => undefined);
  await chrome.tabs.create({ url: "https://chat.qwen.ai/" });
  window.close();
});
