from pathlib import Path
PROJECT_ROOT = Path(__file__).resolve().parents[1]
import sys, json
sys.path.insert(0, str(PROJECT_ROOT))
from memoria.persistence import MemoryPersistence

mem = MemoryPersistence()
results = {"tests": []}

# Test 1: Registrar una decisión de match
trace_match = {
    "timestamp": "2026-09-14T02:00:00",
    "stimulus": "quién es Gusteau",
    "final": {"decision": "match", "route": "edge_match", "nodo": "gusteau_principio"}
}
try:
    dec_id = mem.record_decision(trace_match)
    results["tests"].append({"test": "record_decision_match", "status": "ok", "decision_id": dec_id})
except Exception as e:
    results["tests"].append({"test": "record_decision_match", "status": "fail", "error": str(e)})
    dec_id = None

# Test 2: Registrar una decisión de model_new
trace_new = {
    "timestamp": "2026-09-14T02:01:00",
    "stimulus": "escribe una función fibonacci",
    "final": {"decision": "model_new", "route": "model_new", "provider": "nemotron-free"}
}
try:
    dec_id2 = mem.record_decision(trace_new)
    results["tests"].append({"test": "record_decision_model_new", "status": "ok", "decision_id": dec_id2})
except Exception as e:
    results["tests"].append({"test": "record_decision_model_new", "status": "fail", "error": str(e)})

# Test 3: Verificar métricas del nodo activado
try:
    metrics = mem.get_node_metrics("gusteau_principio")
    ok = metrics["activaciones"] >= 1
    results["tests"].append({"test": "node_activation", "status": "ok" if ok else "fail", "metrics": metrics})
except Exception as e:
    results["tests"].append({"test": "node_activation", "status": "fail", "error": str(e)})

# Test 4: Aplicar feedback positivo
if dec_id:
    try:
        mem.apply_feedback(dec_id, "positivo", "gusteau_principio")
        results["tests"].append({"test": "feedback_positivo", "status": "ok"})
    except Exception as e:
        results["tests"].append({"test": "feedback_positivo", "status": "fail", "error": str(e)})

# Test 5: Verificar decisiones recientes
try:
    recent = mem.get_recent_decisions(5)
    ok = len(recent) >= 2
    results["tests"].append({"test": "recent_decisions", "status": "ok" if ok else "fail", "count": len(recent)})
except Exception as e:
    results["tests"].append({"test": "recent_decisions", "status": "fail", "error": str(e)})

# Test 6: Estadísticas
try:
    stats = mem.stats()
    results["tests"].append({"test": "stats", "status": "ok", "stats": stats})
except Exception as e:
    results["tests"].append({"test": "stats", "status": "fail", "error": str(e)})

passed = sum(1 for t in results["tests"] if t["status"] == "ok")
total = len(results["tests"])
results["summary"] = {"passed": passed, "total": total, "verdict": "PERSISTENCIA_OPERATIVA" if passed == total else "PERSISTENCIA_PARCIAL"}

print(json.dumps(results, indent=2, ensure_ascii=False))
