"""Content Resolver — Resuelve contenido de nodos desde DB o archivos externos"""
from pathlib import Path
PROJECT_ROOT = Path(__file__).resolve().parents[1]
import sqlite3
from pathlib import Path

BASE = PROJECT_ROOT
CORE_DB = BASE / "memoria" / "core" / "core.db"

class ContentResolver:
    def __init__(self, db_path=CORE_DB):
        self.db_path = db_path
        self.base = BASE
    
    def resolve(self, nodo_id: str) -> dict:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        row = conn.execute(
            "SELECT id, label, descripcion, content_type, content_source FROM nodos WHERE id=?",
            (nodo_id,)
        ).fetchone()
        conn.close()
        
        if not row:
            return {"nodo_id": nodo_id, "content_type": "missing", "content": "", "source": None}
        
        content_type = row["content_type"] or "inline"
        
        if content_type == "inline":
            return {
                "nodo_id": nodo_id,
                "label": row["label"],
                "content_type": "inline",
                "content": row["descripcion"] or "",
                "source": None
            }
        
        if content_type == "file":
            source = row["content_source"]
            file_path = self.base / source
            if file_path.exists():
                content = file_path.read_text(encoding="utf-8")
                return {
                    "nodo_id": nodo_id,
                    "label": row["label"],
                    "content_type": "file",
                    "content": content,
                    "source": source
                }
            else:
                return {
                    "nodo_id": nodo_id,
                    "label": row["label"],
                    "content_type": "file_missing",
                    "content": row["descripcion"] or "",
                    "source": source
                }
        
        return {"nodo_id": nodo_id, "content_type": "unknown", "content": "", "source": None}
