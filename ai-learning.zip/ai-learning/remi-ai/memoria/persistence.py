"""Remi-AI Memory Persistence — Registra decisiones, activaciones y feedback"""
from pathlib import Path
PROJECT_ROOT = Path(__file__).resolve().parents[1]
import sqlite3, json
from pathlib import Path
from datetime import datetime

CORE_DB = Path(str(PROJECT_ROOT / "memoria/core/core.db"))

class MemoryPersistence:
    def __init__(self, db_path=CORE_DB):
        self.db_path = db_path
    
    def _conn(self):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        return conn
    
    def record_decision(self, trace: dict) -> int:
        """Guarda una decisión del pipeline. Retorna el ID."""
        conn = self._conn()
        try:
            final = trace.get("final", {})
            nodos = json.dumps([final.get("nodo")] if final.get("nodo") else [])
            cur = conn.execute(
                "INSERT INTO decisiones (session_id, descripcion, nodos_involucrados, decision_tomada, resultado) VALUES (?,?,?,?,?)",
                (
                    trace.get("timestamp", datetime.now().isoformat()),
                    trace.get("stimulus", "")[:200],
                    nodos,
                    final.get("decision", "?"),
                    json.dumps({"route": final.get("route"), "provider": final.get("provider")}, ensure_ascii=False)
                )
            )
            decision_id = cur.lastrowid
            conn.commit()
            
            if final.get("nodo"):
                self.record_node_activation(final["nodo"], conn)
                conn.commit()  # Commit de activación
            
            return decision_id
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()
    
    def record_node_activation(self, nodo_id: str, conn=None):
        """Incrementa contador de activación de un nodo."""
        close_conn = False
        if conn is None:
            conn = self._conn()
            close_conn = True
        try:
            conn.execute(
                "INSERT INTO metricas_nodo (nodo_id, activaciones, ultima_activacion) VALUES (?,?,?) "
                "ON CONFLICT(nodo_id) DO UPDATE SET activaciones=activaciones+1, ultima_activacion=?",
                (nodo_id, 1, datetime.now().isoformat(), datetime.now().isoformat())
            )
            if close_conn:
                conn.commit()
        finally:
            if close_conn:
                conn.close()
    
    def get_node_metrics(self, nodo_id: str) -> dict:
        """Lee métricas de un nodo."""
        conn = self._conn()
        try:
            row = conn.execute("SELECT * FROM metricas_nodo WHERE nodo_id=?", (nodo_id,)).fetchone()
            if row:
                return {"nodo_id": row["nodo_id"], "activaciones": row["activaciones"], "ultima": row["ultima_activacion"]}
            return {"nodo_id": nodo_id, "activaciones": 0, "ultima": None}
        finally:
            conn.close()
    
    def get_top_nodes(self, limit=10) -> list:
        """Retorna nodos más activados."""
        conn = self._conn()
        try:
            rows = conn.execute(
                "SELECT m.nodo_id, m.activaciones, n.label FROM metricas_nodo m "
                "LEFT JOIN nodos n ON n.id=m.nodo_id ORDER BY m.activaciones DESC LIMIT ?",
                (limit,)
            ).fetchall()
            return [{"nodo_id": r["nodo_id"], "activaciones": r["activaciones"], "label": r["label"]} for r in rows]
        finally:
            conn.close()
    
    def apply_feedback(self, decision_id: int, feedback: str, nodo_id: str = None):
        """Registra feedback y ajusta densidad del nodo."""
        conn = self._conn()
        try:
            conn.execute("UPDATE decisiones SET feedback=? WHERE id=?", (feedback, decision_id))
            
            if nodo_id:
                delta = {"positivo": 0.1, "negativo": -0.15, "neutral": 0.0}.get(feedback, 0.0)
                if delta != 0.0:
                    conn.execute(
                        "UPDATE nodos SET densidad = MAX(0.1, MIN(2.0, densidad + ?)) WHERE id=?",
                        (delta, nodo_id)
                    )
            conn.commit()
        finally:
            conn.close()
    
    def get_recent_decisions(self, limit=10) -> list:
        """Lee decisiones recientes."""
        conn = self._conn()
        try:
            rows = conn.execute(
                "SELECT id, descripcion, decision_tomada, resultado, feedback, fecha "
                "FROM decisiones ORDER BY fecha DESC LIMIT ?", (limit,)
            ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()
    
    def stats(self) -> dict:
        """Estadísticas de la memoria."""
        conn = self._conn()
        try:
            total_dec = conn.execute("SELECT COUNT(*) FROM decisiones").fetchone()[0]
            total_act = conn.execute("SELECT COUNT(*) FROM metricas_nodo").fetchone()[0]
            con_feedback = conn.execute("SELECT COUNT(*) FROM decisiones WHERE feedback IS NOT NULL").fetchone()[0]
            return {
                "decisiones_registradas": total_dec,
                "nodos_con_activaciones": total_act,
                "decisiones_con_feedback": con_feedback
            }
        finally:
            conn.close()
