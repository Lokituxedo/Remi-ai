#!/usr/bin/env python3
"""Test exhaustivo de nodos ML afiliados"""
import sys, json
sys.path.insert(0, '.')
from pipeline.remi_pipeline import RemiPipeline

pipeline = RemiPipeline(interactive=False)

TESTS = {
    "1_DISPARADORES_DIRECTOS": [
        ("afiliados mercado libre", "MATCH", "ml_afiliados_programa"),
        ("programa afiliados ml", "MATCH", "ml_afiliados_programa"),
        ("creadores mercado libre", "MATCH", "ml_creadores_programa"),
        ("estrategia afiliados", "MATCH", "ml_afiliados_estrategia"),
        ("api afiliados ml", "MATCH", "ml_afiliados_api"),
        ("tracking afiliados", "MATCH", "ml_afiliados_api"),
        ("monetizar con ml", "MATCH", "ml_afiliados_estrategia"),
        ("karukren afiliados", "MATCH", "ml_afiliados_estrategia"),
        ("ganar dinero con mercado libre", "MATCH", "ml_afiliados_estrategia"),
        ("ventas referidas mercado libre", "MATCH", "ml_afiliados_estrategia"),
        ("afiliados y creadores de mercado libre", "MATCH", "ml_afiliados_programa"),
    ],
    "2_PARAFRASIS": [
        ("ganar comisiones en ML", "MATCH", "ml_*"),  # debería matchear cualquiera
        ("como ser afiliado de mercado libre", "MATCH", "ml_afiliados_programa"),
        ("enlaces de afiliado mercado libre", "MATCH", "ml_*"),
        ("plan creadores ML", "MATCH", "ml_creadores_programa"),
        ("monetizar con MercadoLibre", "MATCH", "ml_afiliados_estrategia"),
    ],
    "3_VARIACIONES_LEXICAS": [
        ("afiliados", "NO_MATCH", None),  # 1 palabra, muy corta
        ("ML afiliados", "MATCH", "ml_*"),
        ("mercadolibre afiliados", "MATCH", "ml_*"),  # sin espacio
        ("MercadoLibre sin acento afiliados", "MATCH", "ml_*"),
    ],
    "4_MULTI_INTENT": [
        ("afiliados ML y cómo generar imágenes", "MATCH", "ml_*"),
        ("comisiones ML + código python", "MATCH", "ml_*"),
    ],
    "5_RUIDO_NO_DEBE_MATCHEAR": [
        ("hola", "NO_MATCH", None),
        ("gracias", "NO_MATCH", None),
        ("codigo", "NO_MATCH", None),
        ("python", "NO_MATCH", None),
        ("escribime un codigo en python", "NO_MATCH", None),
    ],
    "6_FUERA_DE_DOMINIO": [
        ("cómo hacer pan casero", "NO_MATCH", None),
        ("receta de pasta", "NO_MATCH", None),
        ("clima hoy en santiago", "NO_MATCH", None),
    ],
}

print("="*72)
print("TEST EXHAUSTIVO: Nodos ML Afiliados")
print("="*72)

total_pass = 0
total_fail = 0

for category, tests in TESTS.items():
    print(f"\n[{category}]")
    for query, expected, expected_node in tests:
        trace = pipeline.process(query)
        final = trace.get("final", {})
        decision = final.get("decision")
        nodo = final.get("nodo")
        route = final.get("route")

        # Evaluar
        if expected == "MATCH":
            if decision == "match":
                if expected_node == "ml_*":
                    ok = nodo and nodo.startswith("ml_")
                else:
                    ok = nodo == expected_node
            else:
                ok = False
        else:  # NO_MATCH
            ok = decision != "match" or (nodo and not nodo.startswith("ml_"))

        status = "✅" if ok else "❌"
        if ok: total_pass += 1
        else: total_fail += 1

        nodo_str = nodo if nodo else "-"
        print(f"  {status} '{query[:45]:<45s}' → {decision:10s} | {nodo_str}")

print("\n" + "="*72)
print(f"RESULTADO: {total_pass} PASSED / {total_fail} FAILED / {total_pass+total_fail} TOTAL")
print("="*72)

# Contenido de los nodos
print("\n[7_CONTENIDO_NODOS]")
import sqlite3
db = sqlite3.connect('memoria/core/core.db')
cursor = db.cursor()
cursor.execute("SELECT id, label, LENGTH(descripcion), content_type FROM nodos WHERE id LIKE 'ml_%'")
for row in cursor.fetchall():
    print(f"  {row[0]:30s} | {row[1][:40]:40s} | {row[2]:4d} chars | {row[3]}")
db.close()
