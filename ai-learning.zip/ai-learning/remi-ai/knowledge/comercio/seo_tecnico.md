# SEO Técnico

## Velocidad
- Comprimir imágenes
- Minificar CSS/JS
- CDN
- Lazy loading

## Core Web Vitals
- LCP < 2.5s
- FID < 100ms
- CLS < 0.1