# Growth Loops

Ciclos donde el uso genera más adquisición.

## Ejemplos
- Dropbox: invitar → espacio extra → más invitados
- Slack: equipo invita → más valor → más equipos

## vs Funnel
El funnel termina; el loop se compone y acelera.