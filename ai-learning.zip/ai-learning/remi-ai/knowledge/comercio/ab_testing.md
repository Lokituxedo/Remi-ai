# A/B Testing

Comparar dos variantes midiendo una métrica.

## Requisitos
- Hipótesis clara
- Una variable a la vez
- Tamaño muestral suficiente
- Duración completa (ciclos semanales)

## Errores
Peeking temprano, múltiples comparaciones, métricas vanidosas.