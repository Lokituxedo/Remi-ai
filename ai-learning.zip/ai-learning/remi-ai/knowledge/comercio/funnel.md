# Funnel de Conversión

## Etapas
1. Awareness
2. Interest
3. Consideration
4. Intent
5. Purchase
6. Loyalty

Optimizar etapa con mayor caída. A/B testing.