# Retención y Churn

Retención: % que sigue usando el producto tras N días.
Churn: % que abandona por período.

## Curva de retención ideal
Cae y se estabiliza (no va a cero).

Retener cuesta 5-25x menos que adquirir.

Cohortes por semana de signup para ver tendencias reales.