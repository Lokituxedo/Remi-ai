# Network Effects

Producto gana valor con cada usuario.

## Tipos
- Directos: WhatsApp
- Indirectos: Uber
- Datos: Google

Ley de Metcalfe: valor ∝ n²

Cold start problem.