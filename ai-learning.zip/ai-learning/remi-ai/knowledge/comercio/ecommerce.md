# E-commerce

Comercio electrónico: venta de productos o servicios por internet. Plataformas: Shopify, WooCommerce, Mercado Libre. Aspectos clave: logística, pasarelas de pago, experiencia de usuario, conversión.
