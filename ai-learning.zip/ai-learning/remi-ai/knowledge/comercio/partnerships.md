# Alianzas Estratégicas

Crecer mediante partners con audiencias complementarias.

## Tipos
- Integraciones técnicas
- Co-marketing
- Resellers / canal

## Regla
El partner debe ganar tanto como tú.
Alianza 1+1=3 o no es alianza.