# Marketing Digital

Estrategias para promover productos en canales digitales: redes sociales, SEO, email, publicidad pagada. Métricas clave: CTR, conversión, CAC, ROI. Base del crecimiento de negocios online.
