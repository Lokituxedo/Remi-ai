# K-factor (coeficiente viral)

K = invitaciones por usuario × tasa de conversión.

K > 1: crecimiento viral exponencial
K < 1: crecimiento se apaga

## Ciclo viral
Tiempo entre invitaciones acelera o frena el loop.

Combinar con retención: viralidad sin retención = balde agujereado.