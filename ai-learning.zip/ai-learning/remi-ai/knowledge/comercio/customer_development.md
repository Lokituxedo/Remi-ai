# Customer Development

Steve Blank: descubrir clientes antes de construir.

## 4 pasos
1. Discovery
2. Validation
3. Creation
4. Building

Get out of the building.

Mom test: preguntar pasado, no opiniones futuras.