# OKRs — Objectives and Key Results

Andy Grove, popularizado por Google.

## Estructura
Objective: qué (cualitativo)
Key Results: cómo medir (cuantitativo, 3-5)

70% cumplimiento = éxito.
Trimestrales. Ambiciosos.