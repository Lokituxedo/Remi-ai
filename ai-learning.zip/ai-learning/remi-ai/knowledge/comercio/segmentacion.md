# Segmentación de Mercado

Dividir el mercado en grupos con necesidades distintas.

## Criterios
- Demográfico, geográfico
- Psicográfico, comportamental
- Jobs-to-be-done (el más accionable)

Regla: un segmento prioritario al inicio.
'Para todos' = para nadie.