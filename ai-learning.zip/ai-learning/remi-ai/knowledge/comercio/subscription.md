# Economía de Suscripción

## Métricas clave
- MRR/ARR: ingreso recurrente
- NRR: retención neta de ingreso (>100% = expansión)
- LTV con churn: LTV = ARPU / churn

## Ventajas
Ingreso predecible, relación continua.

## Riesgos
Churn compuesto mata el negocio silenciosamente.