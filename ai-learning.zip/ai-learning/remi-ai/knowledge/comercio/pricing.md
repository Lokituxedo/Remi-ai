# Estrategias de Pricing

## Modelos
- Cost-plus
- Value-based
- Competitive
- Freemium

## Psicología
- $9.99 vs $10
- Anclaje
- Decoy pricing

El precio comunica valor.