# MVP — Producto Mínimo Viable

Eric Ries (Lean Startup): versión que valida hipótesis con mínimo esfuerzo.

## Tipos
- Concierge: servicio manual
- Wizard of Oz: frontend real, backend humano
- Landing page: validar interés
- Pre-order: validar con dinero

Build-Measure-Learn.