# Unit Economics

## Métricas
CAC: costo adquisición cliente
LTV: lifetime value

## Regla
LTV / CAC > 3

Payback <12 meses.

Escalar unit economics negativas = acelerar quiebra.