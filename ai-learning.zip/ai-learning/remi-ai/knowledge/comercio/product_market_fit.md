# Product-Market Fit

Marc Andreessen: producto satisface mercado fuerte.

## Señales
- Crecimiento orgánico
- Retención alta
- 40%+ muy decepcionado si desaparece (Sean Ellis)

Antes: no escalar.
Después: escalar agresivamente.