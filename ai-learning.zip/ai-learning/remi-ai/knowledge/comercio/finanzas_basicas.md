# Finanzas Básicas

Fundamentos de gestión financiera personal y de negocio: ingresos, gastos, flujo de caja, ahorro, inversión. Conceptos: interés compuesto, presupuesto, rentabilidad. Base de la salud económica.
