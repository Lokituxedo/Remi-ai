# Copywriting

## Fórmulas
AIDA: Atención, Interés, Deseo, Acción
PAS: Problema, Agitación, Solución
FAB: Features, Advantages, Benefits

Hablar de TÚ, beneficios > características, verbos activos.