# Posicionamiento (April Dunford)

Contexto que hace obvio tu valor.

## Componentes
1. Alternativas competitivas
2. Características únicas
3. Valor que entregan
4. Cliente ideal
5. Categoría de mercado

Sin posición clara, el cliente elige la categoría por ti (y te compara mal).