# Ventas Consultivas

Enfoque de ventas centrado en entender la necesidad del cliente antes de ofrecer solución. Escucha activa, preguntas abiertas, propuesta de valor. Construye relaciones a largo plazo en vez de transacciones.
