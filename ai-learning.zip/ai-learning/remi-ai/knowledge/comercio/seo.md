# SEO

Optimización para motores de búsqueda. Técnicas para posicionar contenido en Google: keywords, backlinks, velocidad de carga, contenido de calidad. Diferencia entre SEO on-page y off-page.
