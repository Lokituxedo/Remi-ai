# Active Recall

Método de estudio basado en recuperar información de la memoria sin releer. Usar preguntas, flashcards y autoevaluación. Científicamente superior a la relectura pasiva.
