# Autoexplicación

Explicarse a uno mismo los pasos mientras se resuelve un problema.

Detecta lagunas en tiempo real.

Técnica base del método Feynman.