# Aprender a Aprender

Meta-habilidad de dominar el propio proceso de aprendizaje. Incluye conocer tu estilo cognitivo, gestionar la atención y aplicar técnicas basadas en evidencia. Pilar de la filosofía anyone can learn anything.
