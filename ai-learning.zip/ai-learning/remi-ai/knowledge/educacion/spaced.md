# Repetición Espaciada

Repasar información en intervalos crecientes combate la curva del olvido (Ebbinghaus).

Intervalos típicos: 1 día, 3 días, 7 días, 21 días, 60 días.

Herramientas: Anki, SuperMemo. Base de todo sistema SRS.