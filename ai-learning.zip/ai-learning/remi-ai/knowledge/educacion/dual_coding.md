# Codificación Dual (Paivio)

Combinar representación verbal + visual duplica las rutas de memoria.

Texto + diagrama > solo texto.

Aplicar: mapas conceptuales, sketchnoting, infografías.