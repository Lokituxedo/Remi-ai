# Interrogación Elaborativa

Preguntar '¿por qué es esto cierto?' fuerza conexiones con conocimiento previo.

Transforma dato aislado en red semántica.

Complementa repetición espaciada.