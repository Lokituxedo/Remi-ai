# Técnica Pomodoro

Método de gestión del tiempo: 25 minutos de trabajo enfocado seguidos de 5 minutos de descanso. Tras 4 ciclos, descanso largo de 20-30 minutos. Mejora la concentración y reduce la fatiga mental.
