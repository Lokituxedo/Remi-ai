# Estado de Flow

Csikszentmihalyi: absorción óptima donde se pierde noción del tiempo.

## Condiciones
1. Claridad de objetivos
2. Feedback inmediato
3. Balance desafío/habilidad altos
4. Fusión acción-consciencia

Productividad en flow: 5x más (McKinsey).