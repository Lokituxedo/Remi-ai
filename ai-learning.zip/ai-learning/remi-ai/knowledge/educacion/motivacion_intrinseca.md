# Teoría de la Autodeterminación (Deci y Ryan)

## Tres necesidades básicas
1. Autonomía: elegir
2. Competencia: mejorar
3. Relación: conectar

Cubiertas las tres, la motivación intrínseca emerge sola.

Premios externos pueden erosionarla (efecto de sobrejustificación).