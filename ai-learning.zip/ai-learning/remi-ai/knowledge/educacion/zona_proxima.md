# Zona de Desarrollo Próximo

Concepto de Vygotsky: la distancia entre lo que un estudiante puede hacer solo y lo que puede hacer con guía. Base del andamiaje pedagógico y la enseñanza adaptativa.
