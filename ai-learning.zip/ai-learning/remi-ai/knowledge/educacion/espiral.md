# Currículum en Espiral

Bruner: temas revisitados con creciente profundidad.

Cualquier tema puede enseñarse efectivamente en forma honesta a cualquier niño.

Ventajas: refuerza memoria a largo plazo, construye conexiones ricas.