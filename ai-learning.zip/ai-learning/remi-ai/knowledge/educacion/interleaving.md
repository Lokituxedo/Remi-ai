# Interleaving — Práctica Intercalada

Alternar tipos de problemas durante práctica.

## vs Bloque
Bloque: AAAA BBBB CCCC
Intercalado: ABC ABC ABC

Aprendizaje 25-50% superior aunque se sienta más difícil.