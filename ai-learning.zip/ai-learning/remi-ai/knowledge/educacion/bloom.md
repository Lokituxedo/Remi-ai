# Taxonomía de Bloom

Jerarquía de niveles cognitivos (Bloom, 1956, revisada 2001).

## Niveles
1. Recordar
2. Comprender
3. Aplicar
4. Analizar
5. Evaluar
6. Crear

Un curso que solo exige recordar no desarrolla pensamiento crítico.