# Método Socrático

Indagación mediante preguntas que guían a descubrir la verdad.

## Estructura
1. Ironía — fingir ignorancia
2. Mayéutica — parir ideas
3. Refutación — exponer contradicciones
4. Definición — concepto claro

Pregunta efectiva: revela supuestos ocultos.