# Constructivismo

El conocimiento no se transmite, se construye activamente.

## Pilares
- Piaget: asimilación y acomodación
- Vygotsky: dimensión social (ZDP)
- Ausubel: aprendizaje significativo

El aprendiz no es vaso vacío.