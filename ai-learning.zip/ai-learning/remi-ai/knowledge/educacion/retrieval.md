# Práctica de Recuperación (Testing Effect)

Recordar activamente fortalece más la memoria que releer.

El test no solo mide: modifica la memoria.

Aplicar: autoexámenes, flashcards, escribir sin apuntes.