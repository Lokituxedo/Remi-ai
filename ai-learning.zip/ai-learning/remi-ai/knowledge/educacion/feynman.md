# Técnica Feynman

Método de aprendizaje que consiste en explicar un concepto con palabras simples, como si se lo enseñaras a un niño. Identifica lagunas de comprensión y obliga a simplificar. Filosofía Gusteau: si puedes explicarlo simple, lo entiendes.
