# Práctica Deliberada

Anders Ericsson: práctica estructurada con objetivo de mejora.

## Características
- Enfocada en aspectos específicos
- Feedback inmediato
- Fuera de zona de confort
- Repetición con ajuste

10,000 horas de práctica ingenua no producen expertos. 1,000 de deliberada sí.