# Zona de Desarrollo Próximo (ZDP)

Vygotsky: distancia entre lo que el aprendiz hace solo y lo que hace con ayuda.

## Tres zonas
1. Real — independiente
2. Próxima — con andamiaje
3. Potencial — fuera de alcance

Aprendizaje óptimo ocurre en la ZDP.