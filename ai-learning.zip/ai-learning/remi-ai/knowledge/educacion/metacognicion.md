# Metacognición

Pensar sobre el pensar.

## Componentes
- Conocimiento metacognitivo: saber cómo aprendes
- Regulación metacognitiva: planificar, monitorear, evaluar

Estudiantes con alta metacognición aprenden 2-3x más rápido.