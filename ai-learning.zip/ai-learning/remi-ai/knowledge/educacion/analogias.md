# Pensamiento Analógico

Transferir estructura de un dominio conocido a uno nuevo.

'La electricidad es como agua en tuberías'.

Las analogías correctas aceleran comprensión; las falsas crean errores sistemáticos.