# Growth Mindset

Carol Dweck: capacidades se pueden desarrollar.

## Fixed mindset
Evita desafíos, se rinde, esfuerzo inútil.

## Growth mindset
Abraza desafíos, persiste, esfuerzo como camino.

No existe 'no sirvo para matemáticas'. Solo 'aún no he practicado'.