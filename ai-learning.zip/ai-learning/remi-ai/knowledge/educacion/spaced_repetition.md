# Repetición Espaciada

Técnica de estudio que distribuye el repaso en intervalos crecientes de tiempo. Aprovecha la curva del olvido de Ebbinghaus. Herramientas: Anki, SuperMemo. Más efectivo que el estudio masivo.
