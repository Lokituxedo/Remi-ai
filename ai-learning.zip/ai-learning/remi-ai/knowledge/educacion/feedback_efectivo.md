# Feedback Efectivo

Hattie: el feedback es de las variables con mayor impacto en aprendizaje.

## Niveles
1. Tarea (¿correcto?)
2. Proceso (¿estrategia?)
3. Autorregulación (¿cómo mejoro?)
4. Yo (elogio vacío — el menos útil)

Feedback inmediato y específico > genérico y tardío.