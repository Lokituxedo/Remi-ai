# Tipos de Sociedades

## Estructuras
- EIRL: individual, responsabilidad limitada
- SpA/Ltda: 2+ socios
- S.A.: accionistas

## Consideraciones
- Tributación
- Responsabilidad
- Gobernanza
- Escalabilidad

Errores: no formalizar, mezclar finanzas.