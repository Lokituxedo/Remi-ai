# Licencias de Software

Contratos que definen cómo puede usarse el software. Tipos: MIT, Apache, GPL (copyleft), propietarias. Open source permite ver y modificar el código. La elección de licencia afecta la distribución.
