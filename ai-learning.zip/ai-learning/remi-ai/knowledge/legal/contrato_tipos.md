# Tipos de Contratos

## Por objeto
- Servicios
- Compraventa
- Arrendamiento
- Licencia
- NDA (confidencialidad)

## Elementos
- Partes, objeto, precio, plazo, terminación, jurisdicción

Leer TODO antes de firmar.