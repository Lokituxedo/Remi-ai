# Contratos Freelance

## Cláusulas esenciales
- Alcance y entregables específicos
- Pagos: anticipo + hitos
- Propiedad intelectual: ¿cuándo se transfiere?
- Revisiones incluidas (límite)
- Cancelación y kill fee

Sin contrato escrito: tu palabra vs la del cliente.