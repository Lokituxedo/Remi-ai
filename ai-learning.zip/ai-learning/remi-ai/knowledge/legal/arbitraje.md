# Arbitraje

Alternativa privada a tribunales.

## Ventajas
- Más rápido y especializado
- Confidencial
- Laudo ejecutable (Nueva York 1958, cross-border)

## Desventajas
- Costo de árbitros
- Apelación casi inexistente

## Cláusula compromisoria
Definir: institución, sede, número de árbitros, idioma.