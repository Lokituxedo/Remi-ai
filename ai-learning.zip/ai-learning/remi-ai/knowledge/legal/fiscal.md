# Obligaciones Tributarias

## Impuestos
- IVA 19%
- Renta
- PPM
- Contribuciones

## Regímenes Chile
- 14 A atribuida
- 14 B semi-integrado
- 14 C Pro Pyme
- 14 D transparente

Planificar, no evadir.