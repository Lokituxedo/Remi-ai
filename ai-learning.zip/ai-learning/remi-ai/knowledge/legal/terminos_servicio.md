# Términos de Servicio (ToS)

## Elementos
1. Aceptación
2. Uso permitido
3. Restricciones
4. Propiedad intelectual
5. Limitación responsabilidad
6. Terminación
7. Ley aplicable
8. Disputas

Claro y legible. Revisión legal.