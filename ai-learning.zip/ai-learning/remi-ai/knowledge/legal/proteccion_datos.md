# Protección de Datos

## Regulaciones
- GDPR (Europa)
- CCPA (California)
- LGPD (Brasil)
- Ley 19.628 (Chile)

## Principios
Licitud, finalidad, minimización, exactitud, limitación temporal, integridad

## Derechos ARCO
Acceso, Rectificación, Cancelación, Oposición

Multas hasta 4% facturación (GDPR).