# Cookies y Consentimiento

## Tipos
- Técnicas: no requieren consentimiento
- Analíticas/marketing: requieren consentimiento explícito

## GDPR
Opt-in real: pre-marcado no vale.
Debe ser tan fácil rechazar como aceptar.

## Buen diseño
Banner claro + centro de preferencias persistente.