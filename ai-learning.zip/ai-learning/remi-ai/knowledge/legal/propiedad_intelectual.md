# Propiedad Intelectual

## Tipos
- Derechos de autor: automático, vida + 70
- Patentes: registro, 20 años
- Marcas: registro, renovables 10 años
- Secretos comerciales: NDA

## Open Source
MIT: permisiva
GPL: copyleft
Apache: permisiva + patentes.