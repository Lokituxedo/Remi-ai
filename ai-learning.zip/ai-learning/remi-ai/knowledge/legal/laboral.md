# Derecho Laboral

## Contratos
- Indefinido
- Plazo fijo
- Por obra
- Honorarios (NO laboral)

## Elementos laboral
1. Servicio personal
2. Subordinación
3. Remuneración

Falsa honorariedad = problema legal.