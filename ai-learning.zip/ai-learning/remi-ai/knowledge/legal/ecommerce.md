# E-commerce: obligaciones legales

## Chile
- Ley 21.455: despacho, retracto, información de precio final
- Precio final visible (con IVA y envío)
- Plazo de entrega explícito

## Datos
- Política de privacidad visible
- Consentimiento para marketing

## Medios de pago
- Informar comisiones y cuotas reales.