# Protección al Consumidor (Ley 19.496 Chile)

## Derechos básicos
- Información veraz
- Garantía legal (6 meses)
- Retracto en compras electrónicas (10 días)
- No discriminación arbitraria

## SERNAC
Reclamos y mediación gratuita.

Letrero 'no se admite cambio' no anula garantía legal.