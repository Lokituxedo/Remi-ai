# Contratos Básicos

Acuerdo legal vinculante entre partes. Elementos esenciales: consentimiento, objeto, causa. Tipos comunes: prestación de servicios, compraventa, confidencialidad NDA. Deben ser claros y por escrito.
