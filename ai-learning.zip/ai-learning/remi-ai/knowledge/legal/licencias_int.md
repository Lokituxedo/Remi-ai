# Licencias Internacionales de Software/Contenido

## Decisiones clave
- Territorio de la licencia
- Ley aplicable y foro
- Moneda y forma de pago
- Restricciones de exportación

## Open source internacional
La licencia viaja con el código: MIT/GPL aplican globalmente.

Vender SaaS cross-border: revisar IVA digital del país destino.