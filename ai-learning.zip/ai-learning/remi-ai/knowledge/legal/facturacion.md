# Facturación (Chile)

## DTE principales
- Factura electrónica (venta a empresa)
- Boleta electrónica (venta a consumidor)
- Nota de crédito (anula/corrige)

## Plazos
Declaración F29 mensual.

## Regla
Emitir DTE al momento de la venta, no al cobro.