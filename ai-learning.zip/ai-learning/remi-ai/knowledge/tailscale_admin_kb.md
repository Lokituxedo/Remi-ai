TAILSCALE COMPREHENSIVE ADMIN KNOWLEDGE BASE
Compiled: 2026-08-19 | Status: Current

1. CORE PRODUCTS & FEATURES

VPN & Mesh Networking
- Architecture: Zero Trust mesh VPN using WireGuard protocol
- Key Capability: Automatic NAT traversal—direct peer-to-peer connections
- Default Behavior: Overlay network (only routes between Tailscale devices)

Tailscale SSH
- Features: Identity-based auth (no SSH keys), automatic host key distribution
- Check Mode: Re-authentication for high-risk connections (root access)
- Check Period: 12 hours default (configurable 1 min - 168 hours)
- CLI: sudo tailscale set --ssh

Tailscale Funnel
- Purpose: Expose local services to public internet via encrypted tunnel
- Encryption: End-to-end (relay servers cannot decrypt)
- Supported Ports: 443, 8443, 10000 (HTTPS only)

Subnet Routers
- Purpose: Share physical subnets without installing Tailscale on every device
- Default: SNAT enabled (traffic appears from router)
- CLI: tailscale set --advertise-routes=CIDR1,CIDR2
- Approval: Routes must be approved in admin console

Exit Nodes
- Purpose: Route ALL internet traffic through specific device
- Setup: tailscale set --advertise-exit-node
- Usage: tailscale set --exit-node=<IP|name>
- Auto Selection: --exit-node=auto:any

MagicDNS
- Default: Enabled on all tailnets
- Format: <machine-name>.<tailnet-dns-name>.ts.net
- Service IP: 100.100.100.100 (IPv4), fd7a:115c:a1e0::53 (IPv6)

DERP Servers
- Full Name: Designated Encrypted Relay for Packets
- Purpose: Fallback relay when direct connection impossible
- Bandwidth: ~30-100 Mbps on DERP relayed connections

2. INSTALLATION & SETUP

Linux: curl -fsSL https://tailscale.com/install.sh | sh
macOS: Standalone variant (.pkg installer), macOS Monterey 12.0+
Windows: Windows 10, Server 2016+
Auth Keys: tskey-auth-, Ephemeral/Reusable/Pre-authorized, 1-90 days expiry

3. SECURITY & ACCESS CONTROL

ACLs (Traditional): Deny-by-default, directional src → dst, enforced locally
Grants (Modern): Separate dst and ip fields, application layer control, routing awareness via field
Policy File: HuJSON format (comments allowed)
Tags: Assign service role to devices (tag:production, tag:database)
Device Posture: OS checks, Tailscale client version, MDM/EDR integration

4. ADMIN CONTROL

Roles: Owner, Admin, Network Admin, IT Admin, Billing Admin, Member
Device Management: Authorize, disable, delete, set name, tags
User Management: Invite, role assignment, suspension, removal
Policy File Management: GitOps integration, built-in syntax checking

5. API & INTEGRATION

REST API: https://api.tailscale.com/api/v2/
Auth Methods: API Access Token (tskey-api-), OAuth Client (tskey-client-), Workload Identity
Key Endpoints: Devices, Policy, DNS, Keys, Webhooks
Webhooks: nodeCreated, nodeNeedsApproval, policyUpdate, userCreated (HMAC-SHA256 verification)
Terraform Provider: registry.terraform.io/providers/tailscale/tailscale

CLI Commands:
tailscale up, tailscale down, tailscale status, tailscale ip, tailscale ping <host>
tailscale netcheck, tailscale ssh [user@]<host>, tailscale set --flag=value, tailscale dns

6. LIMITS & QUOTAS

Pricing Plans:
- Personal: 6 users, unlimited devices, 50 tagged resources (free)
- Standard: $8/user/month, 10 ACL groups
- Premium: $18/user/month, 300 ACL groups
- Enterprise: Custom pricing

API Rate Limits: One request per 30 seconds safe; Webhooks or LocalAPI for high-frequency

7. BEST PRACTICES

Security Hardening:
- Least privilege access controls
- Tags by device purpose, not user
- Device Posture enforcement (MDM, antivirus, firewall)
- Policy Tests to prevent regression
- Key rotation and expiry
- Tailnet Lock for unauthorized key changes

Network Design:
- Overlay vs Default Gateway: Most overlay; use exit node if needed
- Subnet Routing: For legacy/IoT (one router per LAN)
- Exit Nodes: Distribute geographically
- Firewall: Open UDP/41641, allow STUN (UDP/3478)

8. TROUBLESHOOTING

Connectivity Issues:
- Shows relay derp-X instead of direct → tailscale netcheck
- Firewall blocking UDP/41641 → Open firewall
- ISP CGNAT/shared IP → Enable UPnP, port forward, or accept DERP

DNS Not Resolving:
- Linux: Install systemd-resolved, avoid /etc/resolv.conf conflicts
- Windows: Use Resolve-DnsName (not nslookup)

SSH Fails:
- Requirements: Tailscale SSH enabled, policy allows, destination initialized
- Check: tailscale ping target first

Exit Node Issues:
- Throughput Low: Expect 30-100 Mbps on DERP
- LAN Inaccessible: Missing --exit-node-allow-lan-access=true

DOCUMENTATION
Main: https://tailscale.com/docs
API: https://tailscale.com/api-docs
KB: https://tailscale.com/kb
Terraform: https://registry.terraform.io/providers/tailscale/tailscale
GitHub: https://github.com/tailscale/tailscale
