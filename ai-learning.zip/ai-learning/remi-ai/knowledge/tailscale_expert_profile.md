TAILSCALE EXPERT AGENT PROFILE
Created: 2026-08-19 | Status: Ready for deployment

AGENT EXPERTISE
- Zero Trust mesh VPN architecture and design
- Access control (ACLs, Grants, device posture)
- SSH, Funnel, subnet routing, exit nodes configuration
- MagicDNS and split DNS management
- MDM/EDR integrations and device posture
- API and webhook automation
- Policy file (HuJSON) syntax and best practices
- Terraform provider for IaC
- Security hardening and compliance
- Connectivity troubleshooting (direct vs DERP relay)
- OIDC/SSO integration and device approval workflows

DECISION TREES

Access Control Strategy:
├─ Simple network rules (legacy) → ACLs (directional, port-based)
├─ Modern + app-layer control → Grants (IP:port + application actions)
├─ Enforce device compliance → Postures (MDM/EDR integration)
├─ Temporary access + re-auth → SSH check mode (12h default)
└─ Tag-based device authorization → Tags + TagOwners

Networking Architecture:
├─ On-premises LAN → Subnet router (one device acts as gateway)
├─ Route ALL internet traffic → Exit node (default gateway)
├─ Internal DNS only → MagicDNS (100.100.100.100)
├─ Private + public domains → Split DNS (restricted nameservers)
└─ Connect legacy systems → Subnet router + SNAT (default)

Deployment & Authentication:
├─ Manual (one-off) → Browser SSO (tailscale up)
├─ Pre-approved automation → Auth key with preauthorized flag
├─ Headless servers/CI → Auth key + tags (no browser)
├─ Service automation → OAuth client (no user tie-in)
└─ Cloud workload → OIDC federation (no secrets in env)

Connectivity Issues:
├─ Firewall blocking UDP/41641 → Open firewall
├─ ISP CGNAT/shared IP → Enable UPnP, port forward, or accept DERP
├─ NAT not traversable → Setup peer relay (faster than DERP)
├─ Direct impossible → Optimize DERP (use nearest, monitor latency)
└─ Diagnose → Run: tailscale netcheck

CORE CAPABILITIES

Administration:
- User and device management (invite, approve, remove, suspend)
- Role-based access control (Owner, Admin, Network Admin, IT Admin, Billing Admin, Member)
- Policy file editing (HuJSON syntax, version control, rollback)
- Audit logging, MDM deployment (Windows registry, macOS plist, iOS/Android AppConfig)

Access Control:
- ACLs (traditional): Directional rules, port-based, 3-300 groups (by plan)
- Grants (modern): IP:port + application actions, via routing, policy-driven
- Device Posture: OS checks, client version, MDM/EDR integration
- SSH Authorization: Check mode re-auth, per-user SSH permissions
- Tags: Service-based device classification (independent of user)
- Auto-Approvers: Pre-approve subnet routes, exit nodes by tag/route

Networking:
- MagicDNS: Automatic device DNS (100.100.100.100), search domains, no config needed
- Split DNS: Route specific domains to internal DNS, public domains to public DNS
- Subnet Routing: Share physical LANs (one device as gateway/SNAT)
- Exit Nodes: Route ALL internet through specific device
- Peer Relays: User-hosted relays (faster than DERP, no central control)
- DERP: Fallback encryption relay (30-100 Mbps, last resort)
- NAT Traversal: UPnP, PCP, manual port forward, STUN probing

Security & Compliance:
- OIDC/SSO: Google, GitHub, Okta, Microsoft Entra, Apple, custom
- Just-in-Time Access: Re-auth for high-risk connections
- Tailnet Lock: Prevent unauthorized key changes
- Device Identity: Serial number collection for MDM integrations
- Policy Tests: Assertions to prevent ACL regression
- Webhook Events: Lifecycle notifications (device/user create/delete/approve/expire)
- Least Privilege: Deny-by-default ACLs, granular scopes for OAuth

API & Automation:
- REST API: Endpoints for devices, policy, DNS, webhooks, keys
- OAuth Clients: Service-to-Tailscale (scoped, no user tie-in)
- API Access Tokens: User-owned personal automation tokens
- Workload Identity: OIDC federation for CI/CD (no secrets)
- Webhooks: Event subscriptions with HMAC-SHA256 signature verification
- Terraform Provider: Manage DNS, webhooks, device tags, policy (GitOps)
- CLI Commands: tailscale up, status, netcheck, ssh, ping, dns, set

Deployment Automation:
- Auth Keys: Pre-authorized device provisioning (skip approval queue)
- Policy as Code: Store policy file in Git (branch protection, required reviews)
- GitOps Integration: GitHub, GitLab, Bitbucket CI/CD automation
- MDM Deployment: Push Tailscale + policies to fleet (Intune, Jamf, Fleet, Huntress)
- Webhooks: Trigger automation on device/user lifecycle
- Terraform: IaC for DNS, webhooks, tags (GitOps friendly)

COMMON PATTERNS

Security Hardening (HuJSON policy):
{
  "groups": {"group:admins": ["user@example.com"]},
  "tagOwners": {"tag:production": ["group:admins"]},
  "postures": {"posture:prod-ready": ["os == 'linux'", "tailscaleVersion >= '1.50.0'"]},
  "grants": [{
    "src": ["group:engineers"],
    "dst": ["tag:production:22"],
    "app": {"tailscale.com/cap/ssh": [{}]},
    "srcPosture": ["posture:prod-ready"]
  }]
}

Subnet Routing + Exit Node:
tailscale up --advertise-routes=192.168.100.0/24  # Device 1: subnet router
tailscale up --advertise-exit-node                   # Device 2: exit node
tailscale up --exit-node=<exit-node-IP> --exit-node-allow-lan-access=true  # Client
tailscale up --accept-routes=true

Device Approval Workflow:
tailscale auth-key create --reusable --preauthorized --expires=24h --tags=tag:ci-runner
tailscale up --auth-key=$AUTH_KEY  # Devices appear already-approved

Policy Tests (Prevent Regression):
{
  "tests": [{"user": "user@example.com", "allow": ["tag:production:22"], "deny": ["tag:development:22"]}],
  "sshTests": [{"user": "user@example.com", "node": "tag:production", "allow": true}]
}

TROUBLESHOOTING EXPERTISE

Connectivity:
- DERP vs Direct: Run tailscale status (shows direct or relay derp-X)
- Firewall: tailscale netcheck diagnoses UDP/41641 blocking
- CGNAT: ISP shared IP → no direct connection possible → enable UPnP or accept DERP
- Recovery: tailscale logout, tailscale down, restart, tailscale up

DNS:
- MagicDNS Not Working: Confirm 100.100.100.100 accessible, client >= 1.20
- Split DNS Issues: Resolve-DnsName (Windows) / dig (Linux), check restricted nameserver config
- Amazon Linux 2023: Mask stub listener, symlink to stub resolver (known issue)
- DHCP Conflict: dhclient may overwrite /etc/resolv.conf

SSH:
- SSH Fails: Verify target has SSH enabled (tailscale set --ssh), policy allows, network connectivity
- Check Mode Re-auth: Normal behavior; user must authenticate for high-risk connections
- Known Hosts: Auto-managed by Tailscale (no manual key distribution needed)

Access Control:
- ACL Denying Access: Deny-by-default; confirm explicit allow rule exists
- Tags Not Applying: Verify device advertises tags, policy references correctly (tag:xyz)
- Posture Check Failing: Check device attributes page, verify MDM integration reporting

DOCUMENTATION
Main Docs: https://tailscale.com/docs
API Interactive: https://tailscale.com/api-docs
Knowledge Base: https://tailscale.com/kb
Terraform Registry: https://registry.terraform.io/providers/tailscale/tailscale
GitHub Discussions: https://github.com/tailscale/tailscale/discussions
Community Forum: https://discord.gg/tailscale
