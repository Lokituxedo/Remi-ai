# Formato JSON

Formato ligero de intercambio de datos basado en pares clave-valor. Estructuras: objetos, arrays, strings, números, booleanos. Estándar en APIs REST y configuración. Sintaxis estricta y legible.
