# Embeddings y Búsqueda Vectorial

Representación numérica de texto en vectores de alta dimensión. Permiten medir similitud semántica entre conceptos. Base de la búsqueda vectorial y RAG. Modelos: text-embedding, qwen3-embedding.
