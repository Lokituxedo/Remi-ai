# Regex

## Básico
. cualquier, \d dígito, \w alfanumérico, \s espacio
^ inicio, $ fin

## Cuantificadores
* 0+, + 1+, ? 0-1, {n,m}

## Ejemplos
Email: ^[\w.-]+@[\w.-]+\.\w+$

Herramienta poderosa, abuso peligroso.