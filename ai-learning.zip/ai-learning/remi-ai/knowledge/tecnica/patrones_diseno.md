# Patrones de Diseño (GoF, 1994)

## Categorías
Creacionales: Singleton, Factory, Builder
Estructurales: Adapter, Decorator, Facade, Proxy
Comportamiento: Observer, Strategy, Command

Principio: Programar hacia interfaz, no implementación.

Anti-patrones: God Object, Spaghetti Code.