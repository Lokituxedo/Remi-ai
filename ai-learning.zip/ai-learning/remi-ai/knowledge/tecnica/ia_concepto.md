# Inteligencia Artificial

Campo de la informática que crea sistemas capaces de realizar tareas que requieren inteligencia humana. Incluye machine learning, deep learning y procesamiento de lenguaje natural. Los LLMs como Qwen son modelos de lenguaje de gran escala.
