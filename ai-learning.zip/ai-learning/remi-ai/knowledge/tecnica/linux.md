# Linux

Kernel de Torvalds (1991). Base del 96% de servidores.

## Filosofía Unix
- Todo es un archivo
- Una cosa bien
- Programas que trabajen juntos

## Estructura
/ raíz, /home usuarios, /etc config, /var datos, /usr programas

Poder: pipes `cat file | grep pattern | wc -l`.