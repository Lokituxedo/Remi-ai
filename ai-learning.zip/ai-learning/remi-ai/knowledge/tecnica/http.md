# HTTP

## Request
GET /api/users HTTP/1.1
Host: example.com

## Response
HTTP/1.1 200 OK
Content-Type: application/json

## Códigos
2xx éxito, 4xx error cliente, 5xx error servidor

HTTPS = HTTP + TLS.