# Python

Lenguaje de programación de alto nivel, interpretado y multiparadigma. Sintaxis clara, ideal para principiantes. Dominante en ciencia de datos, IA, automatización y scripting. Gestor de paquetes: pip. Entornos: venv, conda.
