# Git

Control de versiones distribuido (Torvalds, 2005).

## Conceptos
- Commit: snapshot
- Branch: línea independiente
- Merge: unir branches
- Rebase: reescribir historia

## Comandos
git init, clone, add, commit, push, pull
git branch, checkout, merge, rebase

Filosofía: historia limpia, commits atómicos.