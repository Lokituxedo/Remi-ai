# Colas de Mensajes

Comunicación asíncrona entre componentes.

## Patrones
- Publisher/Subscriber
- Work queues

## Beneficios
- Desacopla productores y consumidores
- Absorbe picos de carga

Herramientas: RabbitMQ, Kafka, SQS.