# WebSockets

Conexión bidireccional persistente cliente-servidor.

## vs HTTP
HTTP: cliente pregunta, servidor responde
WS: ambos pueden enviar cuando quieran

Usos: chat, trading, juegos, notificaciones en vivo.

Costo: conexión abierta por cliente.