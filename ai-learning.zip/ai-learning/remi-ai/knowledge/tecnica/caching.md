# Caching

Guardar resultados costosos para reuso rápido.

## Niveles
- Navegador, CDN, aplicación, base de datos

## Estrategias
- Cache-aside, write-through, TTL

## Problemas clásicos
- Invalidación y nombrar cosas (los 2 problemas difíciles)

Herramientas: Redis, Memcached.