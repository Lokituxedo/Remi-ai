# API REST

Roy Fielding, 2000. Transferencia de estado representacional.

## Principios
1. Cliente-servidor
2. Sin estado
3. Cacheable
4. Sistema en capas
5. Interfaz uniforme

## Verbos HTTP
GET, POST, PUT, PATCH, DELETE

Recursos como sustantivos, verbos HTTP para acciones.