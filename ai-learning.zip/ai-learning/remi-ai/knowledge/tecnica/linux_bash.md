# Linux y Bash

Sistema operativo de código abierto y su shell de comandos. Comandos esenciales: ls, cd, grep, awk, chmod, systemctl. Automatización con scripts bash. Base de servidores y DevOps.
