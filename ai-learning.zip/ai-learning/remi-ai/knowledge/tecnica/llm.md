# Modelos de Lenguaje LLM

Redes neuronales entrenadas con enormes volúmenes de texto para generar y comprender lenguaje. Ejemplos: Qwen, GPT, Claude. Funcionan por predicción de tokens. Parámetros clave: temperatura, top_p, contexto.
