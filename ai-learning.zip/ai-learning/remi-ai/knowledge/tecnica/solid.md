# SOLID

S: Single Responsibility
O: Open/Closed
L: Liskov Substitution
I: Interface Segregation
D: Dependency Inversion

Código que se modifica sin romper el sistema.