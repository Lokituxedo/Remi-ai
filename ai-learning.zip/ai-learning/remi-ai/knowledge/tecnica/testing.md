# Testing de Software

## Pirámide
- Unit 70%: rápidas
- Integration 20%
- E2E 10%: lentas

## TDD
1. Test falla (rojo)
2. Código mínimo pasa (verde)
3. Refactorizar

100% coverage no garantiza 0 bugs. <70% garantiza problemas.