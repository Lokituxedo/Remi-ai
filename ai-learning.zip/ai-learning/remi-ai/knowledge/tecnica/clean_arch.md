# Clean Architecture (Robert Martin)

Círculos concéntricos: entidades → casos de uso → adaptadores → frameworks.

## Regla de dependencia
Apuntar siempre hacia adentro.

El negocio no conoce la base de datos ni el framework.

Resultado: testeable y reemplazable por capas.