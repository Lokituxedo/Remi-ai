# Autenticación

## Sesiones: estado en servidor
## JWT: token firmado, sin estado
## OAuth 2.0: delegar acceso sin dar contraseña

JWT estructura: header.payload.signature

Reglas: HTTPS siempre, expiración corta, refresh tokens rotativos.