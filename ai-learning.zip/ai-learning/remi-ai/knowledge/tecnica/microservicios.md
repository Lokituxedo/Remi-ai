# Microservicios vs Monolito

## Monolito: un deploy, una base de código
+ Simple de iniciar, fácil debug
- Escala todo junto

## Microservicios: servicios independientes
+ Escala por componente, equipos autónomos
- Complejidad operativa alta

Regla: empezar monolito, extraer servicios cuando duela.