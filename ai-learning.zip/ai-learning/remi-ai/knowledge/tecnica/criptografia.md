# Criptografía Aplicada

## Simétrica: misma clave (AES) — rápida
## Asimétrica: par público/privado (RSA, ECC) — intercambio
## Hash: irreversible (SHA-256) — integridad

TLS combina las tres: asimétrica negocia, simétrica cifra, hash verifica.

Contraseñas: hash + salt lento (bcrypt, argon2).