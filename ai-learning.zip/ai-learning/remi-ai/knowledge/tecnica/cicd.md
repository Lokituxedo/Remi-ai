# CI/CD

Integración y Entrega/Despliegue Continuo.

## CI: cada commit se build + test automático
## CD: despliegue automático a producción

Herramientas: GitHub Actions, GitLab CI, Jenkins.

Beneficio: errores detectados en minutos, no semanas.