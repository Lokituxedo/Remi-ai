# Docker

Plataforma de contenedores.

## Conceptos
- Image: plantilla inmutable
- Container: instancia ejecutándose
- Dockerfile: receta
- Registry: repositorio

Ventajas:
- Funciona en mi máquina = funciona en todas
- Aislamiento de dependencias
- Despliegue reproducible.