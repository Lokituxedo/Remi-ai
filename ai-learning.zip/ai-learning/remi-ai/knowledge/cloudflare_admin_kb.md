CLOUDFLARE COMPREHENSIVE ADMIN KNOWLEDGE BASE
Compiled: 2026-08-19 | Status: Current

1. CORE PRODUCTS

Workers (Serverless Compute)
- Docs: https://developers.cloudflare.com/workers/
- Key Bindings: KV, D1, R2, Durable Objects, Hyperdrive, Queues, Workers AI, Vectorize
- Limits: CPU 10ms (free) / 30s-300s (paid), Memory 128MB, Requests 100K/day (free) / Unlimited (paid)
- Subrequests: 50 (free) / 10K (paid), Worker Size 3MB (free) / 10MB (paid)

D1 (SQLite Database)
- APIs: prepare(), exec(), batch()
- Migrations: wrangler d1 migrations create/apply/list
- Auto-retries: reads only

R2 (Object Storage)
- Single Upload: max 5GB, Multipart: max 5TB
- S3 Compatible: AWS SDK, boto3, rclone

KV (Key-Value Store)
- Methods: put(), get(), list(), delete()
- Max Value: 25MB, Consistency: Eventually consistent (60s typical)

Durable Objects
- Storage: In-memory, SQLite, KV
- Alarm API, WebSocket support

Hyperdrive
- Supports: PostgreSQL, MySQL
- Connection Pooling: Global edge pooling
- Query Caching: Read-only queries cached

2. SECURITY & NETWORKING

WAF: Managed Rules, Custom Rules, Rate Limiting, Bot Management
DDoS: L3/L4 automatic; L7 via ruleset
Tunnels: SSH, RDP, HTTP, gRPC; Outbound-only architecture
Zero Trust (Access): SAML, OIDC, GitHub, Google, Okta; Identity/device/location/time-based policies
API Shield: Discovery, Schema Validation, JWT Validation, BOLA Detection

3. DEVELOPER TOOLS

Wrangler Commands: deploy, dev, tail, d1, kv:namespace, r2 bucket, triggers
Config: wrangler.jsonc or wrangler.toml
Secrets: wrangler secret put KEY (encrypted, request-context only)

4. OBSERVABILITY

Workers Logs: observability.enabled = true, 7-day retention
Real-Time: wrangler tail
Tracing: OpenTelemetry export
Logpush: R2, S3, Datadog, Splunk

5. LIMITS & QUOTAS

| Limit | Free | Paid |
| CPU Time (HTTP) | 10ms | 30s-300s |
| Memory | 128MB | 128MB |
| Daily Requests | 100,000 | Unlimited |
| Subrequests | 50 | 10,000-10M |
| Worker Size | 3MB | 10MB |
| Routes/Zone | - | 1,000 |
| Custom Domains | - | 100 |
| Cron Triggers | 5 | 250 |

API Rate Limits: 1,200 req/5min per token; 200/sec per IP

6. REST API

Base: https://api.cloudflare.com/client/v4/
Auth: Bearer token
Endpoints: /workers/scripts, /storage/kv/namespaces, /r2/buckets, /zones/{zone_id}/dns_records

AI Gateway Unified API:
POST /ai/run – Universal inference
POST /ai/v1/chat/completions – OpenAI compatible
POST /ai/v1/messages – Anthropic compatible

7. KNOWN GOTCHAS

- KV: Eventually consistent; 60s typical
- Durable Objects: In-memory state lost → persist to SQLite
- Workers Logs: 7-day retention only
- D1: Auto-retries reads only; writes require app-level retry
- Hyperdrive: SET commands reset on pool return
- Custom Domains: Cannot nest under existing CNAME
- API Deprecation: /workers/namespaces/ → /storage/kv/namespaces/

8. DOCUMENTATION

Main: https://developers.cloudflare.com/
Dashboard: https://dash.cloudflare.com/
API Ref: https://developers.cloudflare.com/api/
LLM Index: https://developers.cloudflare.com/workers/llms.txt
