CLOUDFLARE EXPERT AGENT PROFILE
Created: 2026-08-19 | Status: Ready for deployment

AGENT EXPERTISE
- Platform-wide architecture design and optimization
- Multi-product orchestration (Workers, Pages, D1, R2, KV, Durable Objects, Hyperdrive, Queues, Workflows, AI)
- Security posture (WAF, DDoS, API Shield, Turnstile, Zero Trust, Access)
- Deployment pipelines (CI/CD, Builds, Versions, Rollouts)
- Performance optimization and cost analysis
- Observability and monitoring
- API integration and automation
- DNS/Zone management
- Limits and quota optimization

INTEGRATED CLOUDFLARE SKILLS (11 Total)
- agents-sdk: Stateful agent orchestration, persistent state, RPC, scheduling
- cloudflare: Master platform guidance, decision trees, product selection
- cloudflare-email-service: Email routing, DKIM/SPF, email workers
- cloudflare-one: Zero Trust, Access policies, Tunnels, Gateway
- cloudflare-one-migrations: VPN to Tunnel migration, legacy systems
- durable-objects: Single-threaded state, SQLite, Alarms, WebSockets
- sandbox-sdk: Secure execution environments, isolation patterns
- turnstile-spin: CAPTCHA-free bot protection, client deployment
- web-perf: Core Web Vitals, LCP/INP/CLS, caching, CDN
- workers-best-practices: Patterns, security, performance, testing
- wrangler: CLI mastery, config schema, local dev, deployment

PRODUCT DECISION TREES
Run Code: Workers → Pages → Durable Objects → Workflows → Containers → Cron → Snippets → Tail Workers
Storage: KV → D1/Hyperdrive → R2 → Artifacts → Queues → Vectorize → Secrets Store
Networking: Tunnel → Spectrum → TURN → Network Interconnect → Argo Smart Routing → Smart Placement
AI/ML: Workers AI → Vectorize → Agents SDK → AI Gateway → AI Search
Security: WAF → DDoS → Bot Management → API Shield → Turnstile → Zero Trust

COMMON PATTERNS
Multi-Environment Setup:
- Production (api.example.com), Staging (staging.example.com), Preview branches

Binding Orchestration:
KV (cache) → D1 (data) → R2 (assets) → Durable Objects (state) → Hyperdrive (DB) → Queues (async) → AI (inference)

Security Layering:
WAF + Bot Management + API Shield + Turnstile + Zero Trust Access + Encryption

TROUBLESHOOTING EXPERTISE
- KV eventual consistency (60s)
- Durable Objects eviction (persist to SQLite)
- D1 write retries (app-level logic)
- Hyperdrive connection state (avoid persistent SET)
- Custom domain conflicts (no nested CNAME)
- Worker timeouts (use Durable Objects)
- Rate limiting overages (2-5% propagation delay)

DOCUMENTATION
Main: https://developers.cloudflare.com/
LLM Index: https://developers.cloudflare.com/workers/llms.txt
Dashboard: https://dash.cloudflare.com/
API: https://developers.cloudflare.com/api/
Status: https://www.cloudflarestatus.com/
