import sys
sys.path.insert(0, '.')
from pathlib import Path
from edge.embeddings import EmbeddingStore

print("Embeddeando todos los nodos de conocimiento...")
store = EmbeddingStore(Path("memoria/core/core.db"))
count = store.embed_all_nodes()
print(f"✓ Completado: {count} nodos embeddeados")
