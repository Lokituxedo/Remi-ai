"""Remi-AI Edge Package

Capa de procesamiento: Core → Validate → Match → Propagate → Decide.
Incluye el motor de propagación selectiva que implementa la
auto-corrección topológica en cada nodo.
"""
from .edge_router import EdgeRouter
from .matcher import NodalMatcher
from .propagation import PropagationEngine, PropagationResult
from .validator import validate_core_response
from .vectorizer import build_tfidf, query_vector

__all__ = [
    "EdgeRouter",
    "NodalMatcher",
    "PropagationEngine",
    "PropagationResult",
    "validate_core_response",
    "build_tfidf",
    "query_vector",
]
