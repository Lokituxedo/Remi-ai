"""Embeddings locales — Fase B. Vectorización semántica con Ollama."""
import requests
import numpy as np
from pathlib import Path
import sqlite3

OLLAMA_HOST = "http://localhost:11434"
EMBED_MODEL = "qwen3-embedding:0.6b"
EMBED_DIM = 512  # Balance calidad/RAM

class EmbeddingStore:
    def __init__(self, db_path: Path):
        self.db_path = db_path
        self.conn = sqlite3.connect(db_path)
        self._ensure_table()
    
    def _ensure_table(self):
        """Crea tabla de embeddings si no existe."""
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS embeddings (
                nodo_id TEXT PRIMARY KEY,
                embedding BLOB,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        self.conn.commit()
    
    def embed_text(self, text: str) -> np.ndarray:
        """Genera embedding de texto usando Ollama."""
        r = requests.post(
            f"{OLLAMA_HOST}/api/embeddings",
            json={"model": EMBED_MODEL, "prompt": text},
            timeout=30
        )
        if r.status_code != 200:
            raise Exception(f"Ollama embedding failed: {r.status_code}")
        return np.array(r.json()["embedding"][:EMBED_DIM], dtype=np.float32)
    
    def embed_node(self, nodo_id: str, content: str):
        """Embeddea un nodo y lo guarda en DB."""
        embedding = self.embed_text(content)
        self.conn.execute("""
            INSERT OR REPLACE INTO embeddings (nodo_id, embedding)
            VALUES (?, ?)
        """, (nodo_id, embedding.tobytes()))
        self.conn.commit()
    
    def search(self, query: str, top_k: int = 5, threshold: float = 0.70) -> list:
        """Búsqueda semántica por similitud coseno."""
        query_emb = self.embed_text(query)
        
        # Cargar todos los embeddings
        cursor = self.conn.execute("SELECT nodo_id, embedding FROM embeddings")
        results = []
        
        for nodo_id, emb_blob in cursor:
            node_emb = np.frombuffer(emb_blob, dtype=np.float32)
            # Similitud coseno
            sim = np.dot(query_emb, node_emb) / (np.linalg.norm(query_emb) * np.linalg.norm(node_emb))
            if sim >= threshold:
                results.append((nodo_id, float(sim)))
        
        results.sort(key=lambda x: x[1], reverse=True)
        return results[:top_k]
    
    def embed_all_nodes(self):
        """Embeddea todos los nodos de la base de conocimiento."""
        cursor = self.conn.execute("""
            SELECT id, label, descripcion 
            FROM nodos 
            WHERE activo = 1
        """)
        
        count = 0
        for nodo_id, label, descripcion in cursor:
            content = f"{label}\n\n{descripcion or ''}"
            try:
                self.embed_node(nodo_id, content)
                count += 1
            except Exception as e:
                print(f"Error embedding {nodo_id}: {e}")
        
        print(f"✓ {count} nodos embeddeados")
        return count
