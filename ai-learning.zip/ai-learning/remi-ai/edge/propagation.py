"""Propagation Engine — Activación selectiva por masa y cercanía.

Implementa el mecanismo que la arquitectura nodal ya tenía en diseño:
- En cada nodo, solo se activan aristas por masa (peso × densidad)
- Conexiones irrelevantes se "apagan" por debajo del umbral
- La búsqueda se auto-corrige en cada paso
- Memoria = rutas: devuelve camino completo, no solo nodo destino

Principio Gusteau: si una ruta tiene masa suficiente, el conocimiento
llega por asociación, no por repetición literal.
"""
import sqlite3
from collections import deque
from typing import List, Tuple, Optional, Dict

# ─── Parámetros del sistema ─────────────────────────────────
PROPAGATION_DEPTH = 3        # Máximo de saltos desde origen
MIN_MASS_THRESHOLD = 0.30    # Masa mínima para seguir activando
DECAY_FACTOR = 0.70          # Decaimiento exponencial por profundidad
MAX_RESULTS = 5              # Top-k caminos a retornar


class PropagationResult:
    """Un camino propagado con su masa acumulada."""
    __slots__ = ("node_id", "mass", "path", "depth")

    def __init__(self, node_id: str, mass: float, path: List[Tuple[str, str, float]], depth: int):
        self.node_id = node_id
        self.mass = mass
        self.path = path
        self.depth = depth

    def to_dict(self) -> dict:
        return {
            "node_id": self.node_id,
            "mass": round(self.mass, 4),
            "path": [{"from": f, "to": t, "peso": w} for f, t, w in self.path],
            "depth": self.depth,
        }


class PropagationEngine:
    def __init__(self, db_path: str):
        self.db_path = str(db_path)

    def _conn(self):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _get_edges(self, conn, node_id: str) -> list:
        """Aristas salientes con densidad del nodo destino."""
        rows = conn.execute(
            """SELECT a.nodo_destino AS target, a.peso AS weight,
                      n.densidad AS density
               FROM aristas a
               JOIN nodos n ON n.id = a.nodo_destino
               WHERE a.nodo_origen = ? AND n.activo = 1
               ORDER BY a.peso DESC""",
            (node_id,),
        ).fetchall()
        return rows

    def propagate(
        self,
        start_node_id: str,
        max_depth: int = PROPAGATION_DEPTH,
    ) -> List[PropagationResult]:
        """BFS con decaimiento: propaga activación, descarta lo irrelevante."""
        activation: Dict[str, float] = {start_node_id: 1.0}
        path_map: Dict[str, list] = {start_node_id: []}
        visited = set([start_node_id])
        queue = deque([(start_node_id, 1.0, 0)])

        conn = self._conn()
        try:
            while queue:
                current, mass, depth = queue.popleft()
                if depth >= max_depth:
                    continue

                for edge in self._get_edges(conn, current):
                    target = edge["target"]
                    # Masa = masa_actual × peso_arista × densidad_destino × decaimiento
                    edge_mass = mass * edge["weight"] * edge["density"] * (DECAY_FACTOR ** depth)

                    # ── Auto-corrección: apagar conexiones irrelevantes ──
                    if edge_mass < MIN_MASS_THRESHOLD:
                        continue

                    # Acumular masa (si múltiples caminos llegan, guardar el mejor)
                    if edge_mass > activation.get(target, 0.0):
                        activation[target] = edge_mass
                        path_map[target] = path_map[current] + [(current, target, edge["weight"])]

                    if target not in visited:
                        visited.add(target)
                        queue.append((target, edge_mass, depth + 1))
        finally:
            conn.close()

        # Ordenar por masa desc, profundidad asc; excluir origen
        results = [
            PropagationResult(
                node_id=nid,
                mass=m,
                path=path_map[nid],
                depth=len(path_map[nid]),
            )
            for nid, m in activation.items()
            if nid != start_node_id
        ]
        results.sort(key=lambda r: (-r.mass, r.depth))
        return results[:MAX_RESULTS]

    def get_best_path(
        self, start_node_id: str, target_node_id: str
    ) -> Tuple[Optional[list], float]:
        """¿Existe camino propagado viable hacia target?"""
        for r in self.propagate(start_node_id):
            if r.node_id == target_node_id:
                return r.path, r.mass
        return None, 0.0

    def summarize(self, start_node_id: str) -> str:
        """Reporte legible de la propagación."""
        results = self.propagate(start_node_id)
        if not results:
            return f"PROPAGACIÓN {start_node_id}: sin caminos activos."
        lines = [f"PROPAGACIÓN desde {start_node_id}:"]
        for i, r in enumerate(results, 1):
            chain = " → ".join([start_node_id] + [t for _, t, _ in r.path])
            lines.append(f"  {i}. {chain} | masa={r.mass:.3f} | prof={r.depth}")
        return "\n".join(lines)
