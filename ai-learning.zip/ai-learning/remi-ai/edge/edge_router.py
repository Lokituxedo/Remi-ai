"""Edge Router v3 — Core → Validate → Match → Propagate → Decide.

v2: usaba solo el nodo que disparó.
v3: si la propagación encontró camino con masa suficiente, ese nodo
    es la respuesta real (auto-corrección topológica).
"""
import requests
from pathlib import Path
from edge.validator import validate_core_response
from edge.matcher import NodalMatcher

# Thresholds v3 (ajustados para permitir que la propagación participe)
THRESHOLD_DIRECT     = 0.75   # masa mínima para match directo
THRESHOLD_PROPAGATED = 0.70   # masa mínima para aceptar nodo propagado
THRESHOLD_ASSISTED   = 0.60
CONFIDENCE_FALLBACK  = 0.70


class EdgeRouter:
    def __init__(
        self,
        core_db: Path,
        ollama_host: str = "http://localhost:11434",
        core_model: str = "remi-ai-core",
    ):
        self.ollama_host = ollama_host
        self.core_model = core_model
        self.matcher = NodalMatcher(core_db)

    def call_core(self, stimulus: str) -> dict:
        try:
            r = requests.post(
                f"{self.ollama_host}/api/generate",
                json={
                    "model": self.core_model,
                    "prompt": stimulus,
                    "stream": False,
                    "format": "json",
                    "options": {"temperature": 0, "top_k": 1, "top_p": 1, "seed": 42},
                },
                timeout=30,
            )
            if r.status_code != 200:
                return {"error": f"ollama_status_{r.status_code}", "raw": None}
            return {"error": None, "raw": r.json().get("response", "")}
        except Exception as e:
            return {"error": f"exception: {e}", "raw": None}

    def process(self, stimulus: str) -> dict:
        trace = {
            "stimulus": stimulus,
            "core_call": None,
            "validation": None,
            "match": None,
            "propagation": None,
            "decision": None,
        }
        try:
            # 1. Core
            core_result = self.call_core(stimulus)
            trace["core_call"] = {"error": core_result["error"]}
            if core_result["error"]:
                trace["decision"] = {
                    "decision": "fallback",
                    "reason": f"core_call_failed: {core_result['error']}",
                    "route": "agent_fallback",
                }
                return trace

            # 2. Validate
            validation = validate_core_response(core_result["raw"])
            trace["validation"] = validation
            if not validation["valid"]:
                trace["decision"] = {
                    "decision": "fallback",
                    "reason": f"core_invalid: {validation['error']}",
                    "route": "agent_fallback",
                }
                return trace

            core_parsed = validation["parsed"]

            # 3. Fallback explícito del core
            if (
                core_parsed.get("route") == "agent_fallback"
                or core_parsed.get("confidence", 0) < CONFIDENCE_FALLBACK
            ):
                trace["decision"] = {
                    "decision": "fallback",
                    "reason": "core_requested_fallback",
                    "route": "agent_fallback",
                    "core_intent": core_parsed.get("intent"),
                    "core_confidence": core_parsed.get("confidence"),
                }
                return trace

            # 4. Match + Propagation
            query = core_parsed.get("query") or stimulus
            match_result = self.matcher.match(query)
            trace["match"] = {
                "matched": match_result["matched"],
                "top_nodo": match_result["top_nodo"],
                "score": match_result["score"],
                "method": match_result["method"],
            }
            trace["propagation"] = match_result.get("propagation", [])

            # 5. Decisión con propagación selectiva
            if match_result["matched"]:
                prop_nodo = match_result.get("propagated_nodo")
                prop_mass = match_result.get("propagated_mass", 0.0)

                # Caso A: match fuerte directo → no necesita propagación
                if match_result["score"] >= THRESHOLD_DIRECT:
                    decision = {
                        "decision": "match",
                        "route": "edge_match",
                        "top_nodo": match_result["top_nodo"],
                        "score": match_result["score"],
                        "level": "direct",
                    }
                # Caso B: match asistido + camino propagado con masa suficiente
                elif prop_nodo and prop_mass >= THRESHOLD_PROPAGATED:
                    best_path = next(
                        (p for p in match_result.get("propagation", [])
                         if p["node_id"] == prop_nodo),
                        None,
                    )
                    decision = {
                        "decision": "match",
                        "route": "edge_match",
                        "top_nodo": prop_nodo,
                        "score": prop_mass,
                        "level": "propagated",
                        "path": best_path["path"] if best_path else [],
                        "depth": best_path["depth"] if best_path else 0,
                        "origin_nodo": match_result["top_nodo"],
                        "origin_score": match_result["score"],
                    }
                # Caso C: match asistido sin propagación viable
                elif match_result["score"] >= THRESHOLD_ASSISTED:
                    decision = {
                        "decision": "match",
                        "route": "edge_match",
                        "top_nodo": match_result["top_nodo"],
                        "score": match_result["score"],
                        "level": "assisted",
                        "needs_generation": True,
                    }
                else:
                    decision = self._fallback_to_model_new(core_parsed, query, match_result)
            else:
                decision = self._fallback_to_model_new(core_parsed, query, match_result)

            trace["decision"] = decision
            return trace

        except Exception as e:
            trace["decision"] = {
                "decision": "fallback",
                "reason": f"unexpected_error: {e}",
                "route": "agent_fallback",
            }
            return trace

    def _fallback_to_model_new(self, core_parsed, query, match_result):
        return {
            "decision": "model_new",
            "route": "model_new",
            "intent": core_parsed.get("intent"),
            "domain": core_parsed.get("domain"),
            "query": query,
            "reason": f"no_match_above_threshold (best={match_result['score']})",
        }
