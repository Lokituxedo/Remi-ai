"""Edge Matcher v4 — Matching defensivo + propagación selectiva.

v3 hacía match y devolvía 1 nodo.
v4 hace match y PROPAGA a vecinos por masa: el nodo devuelto es el
que realmente responde, no solo el que disparó.
"""
import re
import sqlite3
import unicodedata
from pathlib import Path
from edge.vectorizer import build_tfidf, query_vector
from edge.propagation import PropagationEngine


def load_nodos(db_path: Path) -> list:
    if not db_path.exists():
        return []
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    rows = conn.execute(
        "SELECT id, tipo, label, descripcion FROM nodos WHERE activo=1"
    ).fetchall()
    conn.close()
    return [
        {
            "id": r["id"],
            "tipo": r["tipo"],
            "label": r["label"],
            "descripcion": r["descripcion"] or " ",
        }
        for r in rows
    ]


def load_disparadores(db_path: Path) -> dict:
    if not db_path.exists():
        return {}
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    rows = conn.execute(
        "SELECT nodo_id, disparador, prioridad FROM contexto_activacion ORDER BY prioridad ASC"
    ).fetchall()
    conn.close()
    disp = {}
    for r in rows:
        d = r["disparador"].lower().strip()
        if d and d not in disp:
            disp[d] = r["nodo_id"]
    return disp


def _match_disparador(query_lower: str, disparador: str) -> bool:
    """Palabra completa si es corto (<=3), substring si es largo."""
    if len(disparador) <= 3:
        pattern = r'\b' + re.escape(disparador) + r'\b'
        return bool(re.search(pattern, query_lower))
    return disparador in query_lower


class NodalMatcher:
    def __init__(self, db_path: Path):
        self.db_path = db_path
        # ⚡ Propagador disponible desde el inicio
        self.propagator = PropagationEngine(db_path)
        self.reload()

    def reload(self):
        nodos = load_nodos(self.db_path)
        self.index = build_tfidf(nodos) if nodos else None
        self.nodo_count = len(nodos)
        self.disparadores = load_disparadores(self.db_path)

    def _normalize_text(self, text: str) -> str:
        text = str(text).lower().strip()
        text = unicodedata.normalize("NFD", text)
        text = "".join(c for c in text if unicodedata.category(c) != "Mn")
        text = re.sub(r"[^\w\s]", " ", text)
        return re.sub(r"\s+", " ", text).strip()

    def _run_propagation(self, nodo_id: str) -> list:
        """Ejecuta propagación y serializa el top-k a dict."""
        try:
            results = self.propagator.propagate(nodo_id)
            return [r.to_dict() for r in results]
        except Exception:
            return []

    def match(self, query: str) -> dict:
        query_lower = self._normalize_text(query).strip()

        # 1. Disparadores exactos (prioridad máxima)
        for disp, nodo_id in self.disparadores.items():
            if _match_disparador(query_lower, disp):
                prop = self._run_propagation(nodo_id)
                # Si la propagación encontró un camino de mayor masa, reportarlo
                best_prop = prop[0] if prop else None
                return {
                    "matched": True,
                    "top_nodo": nodo_id,
                    "score": 1.0,
                    "all_matches": [(nodo_id, 1.0)],
                    "method": "disparador_exacto",
                    "reason": f"disparador '{disp}'",
                    "propagation": prop,
                    "propagated_nodo": best_prop["node_id"] if best_prop else nodo_id,
                    "propagated_mass": best_prop["mass"] if best_prop else 1.0,
                }

        # 2. TF-IDF
        if not self.index or self.nodo_count == 0:
            return {
                "matched": False, "top_nodo": None, "score": 0.0,
                "all_matches": [], "method": "none", "reason": "empty_index",
                "propagation": [], "propagated_nodo": None, "propagated_mass": 0.0,
            }

        scores = query_vector(query, self.index)
        if not scores:
            return {
                "matched": False, "top_nodo": None, "score": 0.0,
                "all_matches": [], "method": "tfidf", "reason": "no_matches",
                "propagation": [], "propagated_nodo": None, "propagated_mass": 0.0,
            }

        top_id, top_score = scores[0]
        matched = top_score >= 0.10
        prop = self._run_propagation(top_id) if matched else []
        best_prop = prop[0] if prop else None

        return {
            "matched": matched,
            "top_nodo": top_id if matched else None,
            "score": round(top_score, 4),
            "all_matches": scores[:5],
            "method": "tfidf",
            "reason": "ok",
            "propagation": prop,
            "propagated_nodo": best_prop["node_id"] if best_prop else (top_id if matched else None),
            "propagated_mass": best_prop["mass"] if best_prop else 0.0,
        }
