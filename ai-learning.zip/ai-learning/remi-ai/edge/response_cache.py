"""Response Cache — Fase C-lite.

Cachea DECISIONES para no re-llamar al Core/Router en queries repetidas.
Respeta 'memoria = rutas':
  - entradas 'match' guardan nodo_id + route; el contenido se RE-RESUELVE al llegar
  - entradas 'model_new' guardan el output (músculo descartable, tiene sentido cachearlo)
Solo cachea decisiones determinísticas; NUNCA cachéa fallos transitorios
(router_failed, timeout, errores de Ollama).
"""
import hashlib
import sqlite3
from datetime import datetime

DEFAULT_THRESHOLD = 0.95
# razones de fallback NO cacheables (transitorias)
TRANSIENT = ("router_failed", "ollama_", "timeout", "error", "refused")


def normalize(text):
    return " ".join(text.lower().strip().split())


def make_hash(text):
    return hashlib.sha256(normalize(text).encode("utf-8")).hexdigest()


class ResponseCache:
    def __init__(self, db_path, embedder=None, threshold=DEFAULT_THRESHOLD):
        self.db_path = str(db_path)
        self.embedder = embedder          # EmbeddingStore de Fase B (opcional)
        self.threshold = threshold
        self._ensure_table()

    def _conn(self):
        return sqlite3.connect(self.db_path)

    def _ensure_table(self):
        conn = self._conn()
        try:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS cache_respuestas (
                    input_hash    TEXT PRIMARY KEY,
                    query_norm    TEXT NOT NULL,
                    embedding     BLOB,
                    decision_type TEXT NOT NULL,
                    route         TEXT,
                    nodo_id       TEXT,
                    output        TEXT,
                    provider      TEXT,
                    latency_ms    INTEGER,
                    hit_count     INTEGER DEFAULT 0,
                    created_at    TEXT DEFAULT CURRENT_TIMESTAMP,
                    last_hit      TEXT
                )""")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_cache_nodo ON cache_respuestas(nodo_id)")
            conn.commit()
        finally:
            conn.close()

    # ── policy ───────────────────────────────────────────────
    def _is_cacheable(self, trace):
        final = trace.get("final", {}) or {}
        d = final.get("decision")
        if d in ("match", "model_new"):
            return True
        if d == "fallback":
            reason = str(final.get("reason", "")).lower()
            return not any(t in reason for t in TRANSIENT)
        return False

    def _final_from_row(self, decision_type, route, nodo_id, output, provider):
        if decision_type == "match":
            # RUTA: devolvemos nodo_id+route; el pipeline re-resuelve el contenido
            return {"decision": "match", "route": route or "cache",
                    "nodo": nodo_id, "score": 1.0, "_cache_hit": True}
        if decision_type == "model_new":
            return {"decision": "model_new", "route": "model_new",
                    "provider": provider, "content": output, "_cache_hit": True}
        return {"decision": "fallback", "reason": output or "cached_fallback",
                "_cache_hit": True}

    # ── lookup ───────────────────────────────────────────────
    def lookup(self, stimulus, use_semantic=True):
        h = make_hash(stimulus)
        conn = self._conn()
        try:
            row = conn.execute(
                "SELECT decision_type, route, nodo_id, output, provider "
                "FROM cache_respuestas WHERE input_hash=?", (h,)).fetchone()
        finally:
            conn.close()
        if row:
            self._hit(h)
            return self._final_from_row(*row), {"type": "exact", "hash": h}

        if use_semantic and self.embedder is not None:
            return self._semantic_lookup(stimulus)
        return None, None

    def _semantic_lookup(self, stimulus):
        try:
            import numpy as np
            qv = self.embedder.embed_text(normalize(stimulus)).astype("float32")
        except Exception:
            return None, None
        conn = self._conn()
        try:
            rows = conn.execute(
                "SELECT input_hash, embedding, decision_type, route, nodo_id, output, provider "
                "FROM cache_respuestas WHERE embedding IS NOT NULL").fetchall()
        finally:
            conn.close()
        best, best_sim = None, 0.0
        for r in rows:
            try:
                ev = np.frombuffer(r[1], dtype=np.float32)
                if ev.shape[0] != qv.shape[0]:
                    continue
                sim = float(np.dot(qv, ev) / (np.linalg.norm(qv) * np.linalg.norm(ev) + 1e-9))
            except Exception:
                continue
            if sim > best_sim:
                best_sim, best = sim, r
        if best is not None and best_sim >= self.threshold:
            self._hit(best[0])
            return self._final_from_row(best[2], best[3], best[4], best[5], best[6]), \
                   {"type": "semantic", "similarity": round(best_sim, 3)}
        return None, None

    def _hit(self, h):
        conn = self._conn()
        try:
            conn.execute("UPDATE cache_respuestas SET hit_count=hit_count+1, last_hit=? WHERE input_hash=?",
                         (datetime.now().isoformat(), h))
            conn.commit()
        finally:
            conn.close()

    # ── store ────────────────────────────────────────────────
    def store(self, stimulus, trace, latency_ms=None):
        if not self._is_cacheable(trace):
            return False
        final = trace.get("final", {}) or {}
        d = final.get("decision")
        h = make_hash(stimulus)
        qn = normalize(stimulus)

        emb = None
        if self.embedder is not None:
            try:
                emb = self.embedder.embed_text(qn).astype("float32").tobytes()
            except Exception:
                emb = None

        if d == "match":
            route, nodo_id, output, provider = final.get("route"), final.get("nodo"), None, None
        elif d == "model_new":
            route, nodo_id, output, provider = "model_new", None, final.get("content"), final.get("provider")
        else:
            route, nodo_id, output, provider = None, None, final.get("reason"), None

        conn = self._conn()
        try:
            conn.execute("""
                INSERT OR REPLACE INTO cache_respuestas
                (input_hash, query_norm, embedding, decision_type, route, nodo_id,
                 output, provider, latency_ms, hit_count)
                VALUES (?,?,?,?,?,?,?,?,?,0)""",
                (h, qn, emb, d, route, nodo_id, output, provider, latency_ms))
            conn.commit()
        finally:
            conn.close()
        return True

    # ── mantenimiento ────────────────────────────────────────
    def invalidate(self, nodo_id=None):
        conn = self._conn()
        try:
            if nodo_id:
                conn.execute("DELETE FROM cache_respuestas WHERE nodo_id=?", (nodo_id,))
            else:
                conn.execute("DELETE FROM cache_respuestas")
            conn.commit()
        finally:
            conn.close()

    def stats(self):
        conn = self._conn()
        try:
            total = conn.execute("SELECT COUNT(*) FROM cache_respuestas").fetchone()[0]
            hits = conn.execute("SELECT COALESCE(SUM(hit_count),0) FROM cache_respuestas").fetchone()[0]
            by_type = dict(conn.execute(
                "SELECT decision_type, COUNT(*) FROM cache_respuestas GROUP BY decision_type").fetchall())
        finally:
            conn.close()
        return {"entries": total, "total_hits": hits, "by_type": by_type}
