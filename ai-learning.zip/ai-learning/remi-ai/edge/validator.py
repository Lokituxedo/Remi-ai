"""Edge Validator — Valida JSON del Core contra schema estricto"""
import json

REQUIRED_KEYS = {"status", "intent", "domain", "route", "query", "confidence"}
VALID_ROUTES = {"edge_match", "model_new", "agent_fallback"}

def validate_core_response(raw_json: str) -> dict:
    """Valida respuesta del Core. Retorna dict con 'valid' y 'parsed' o 'error'."""
    try:
        parsed = json.loads(raw_json)
    except json.JSONDecodeError as e:
        return {"valid": False, "error": f"json_decode: {str(e)}", "parsed": None}
    
    if not isinstance(parsed, dict):
        return {"valid": False, "error": "not_dict", "parsed": None}
    
    missing = REQUIRED_KEYS - set(parsed.keys())
    if missing:
        return {"valid": False, "error": f"missing_keys: {sorted(missing)}", "parsed": None}
    
    if parsed.get("route") not in VALID_ROUTES:
        return {"valid": False, "error": f"invalid_route: {parsed.get('route')}", "parsed": None}
    
    conf = parsed.get("confidence", 0)
    if not isinstance(conf, (int, float)) or conf < 0 or conf > 1:
        return {"valid": False, "error": f"invalid_confidence: {conf}", "parsed": None}
    
    return {"valid": True, "parsed": parsed, "error": None}
