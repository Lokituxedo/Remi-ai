"""Query Rewriter — Fase A. Genera variantes de búsqueda vía core local."""
import re, json, requests

OLLAMA_HOST = "http://localhost:11434"
CORE_MODEL = "remi-ai-core"

def rewrite_query(query: str, n: int = 3, timeout: int = 20) -> list:
    """Genera n variantes de búsqueda para ampliar matching.
    Retorna lista de strings (puede ser vacía si falla)."""
    prompt = (
        f"Genera exactamente {n} variantes cortas de búsqueda para esta consulta, "
        f"en español, conservando la intención. Responde SOLO un array JSON de strings.\n"
        f"Consulta: {query}\nArray JSON:"
    )
    try:
        r = requests.post(
            f"{OLLAMA_HOST}/api/generate",
            json={"model": CORE_MODEL, "prompt": prompt, "stream": False,
                  "options": {"temperature": 0.3, "top_k": 20}},
            timeout=timeout
        )
        if r.status_code != 200:
            return []
        raw = r.json().get("response", "")
        clean = re.compile(r'\x1b\[[0-9;]*[a-zA-Z]|\x1b\].*?\x07').sub('', raw).strip()
        # Extraer primer array JSON
        m = re.search(r'\[.*?\]', clean, re.DOTALL)
        if not m:
            return []
        variants = json.loads(m.group(0))
        return [str(v).strip() for v in variants if str(v).strip()][:n]
    except Exception:
        return []
