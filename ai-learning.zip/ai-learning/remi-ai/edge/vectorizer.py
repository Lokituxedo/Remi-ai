"""Edge Vectorizer — TF-IDF simple para matching de nodos"""
import re
import math
from collections import Counter

def tokenize(text: str) -> list:
    """Tokeniza texto en palabras normalizadas."""
    text = text.lower()
    tokens = re.findall(r"[a-záéíóúñ0-9]+", text)
    return [t for t in tokens if len(t) > 2]

def build_tfidf(nodos: list) -> dict:
    """Construye índice TF-IDF desde lista de nodos [{id, label, descripcion}]."""
    docs = []
    for n in nodos:
        text = f"{n['label']} {n.get('descripcion', '')}"
        docs.append(tokenize(text))
    
    # Calcular IDF
    df = Counter()
    for doc in docs:
        for t in set(doc):
            df[t] += 1
    N = len(docs)
    idf = {t: math.log(N / (1 + df[t])) for t in df}
    
    # Construir vectores
    vectors = []
    for i, doc in enumerate(docs):
        tf = Counter(doc)
        vec = {t: tf[t] * idf.get(t, 0) for t in tf}
        norm = math.sqrt(sum(v**2 for v in vec.values())) or 1
        vectors.append({t: v/norm for t, v in vec.items()})
    
    return {"nodos": nodos, "vectors": vectors, "idf": idf}

def cosine_similarity(v1: dict, v2: dict) -> float:
    """Similaridad coseno entre dos vectores dispersos."""
    keys = set(v1.keys()) & set(v2.keys())
    if not keys:
        return 0.0
    dot = sum(v1[k] * v2[k] for k in keys)
    return dot

def query_vector(query: str, index: dict) -> list:
    """Retorna [(nodo_id, score)] ordenados por similitud."""
    tokens = tokenize(query)
    tf = Counter(tokens)
    qvec = {t: tf[t] * index["idf"].get(t, 0) for t in tf}
    norm = math.sqrt(sum(v**2 for v in qvec.values())) or 1
    qvec = {t: v/norm for t, v in qvec.items()}
    
    scores = []
    for nodo, vec in zip(index["nodos"], index["vectors"]):
        score = cosine_similarity(qvec, vec)
        if score > 0:
            scores.append((nodo["id"], score))
    
    return sorted(scores, key=lambda x: x[1], reverse=True)
