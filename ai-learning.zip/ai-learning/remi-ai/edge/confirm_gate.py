"""Confirmation Gate — Fase A. Valida entendimiento con el usuario."""
import sys

def should_confirm(interactive: bool, confidence: float, threshold: float,
                   force_yes: bool, confirm_always: bool) -> bool:
    """Decide si pedir confirmación. Nunca bloquea en modo no-interactivo."""
    if force_yes:
        return False
    if not interactive:
        return False
    if confirm_always:
        return True
    return confidence < threshold

def ask_confirmation(hypothesis: str) -> bool:
    """Pregunta al usuario. Retorna True si confirma."""
    try:
        print(f"\n  Entiendo que: {hypothesis}")
        resp = input("  ¿Es correcto? [s/N]: ").strip().lower()
        return resp in ('s', 'si', 'sí', 'y', 'yes')
    except (EOFError, KeyboardInterrupt):
        return True  # no bloquear; continuar

def build_hypothesis(core_parsed: dict, stimulus: str) -> str:
    """Construye la frase de entendimiento a partir del parseo del core."""
    intent = core_parsed.get("intent", "consulta")
    domain = core_parsed.get("domain", "")
    q = core_parsed.get("query", stimulus)
    dom = f" sobre {domain}" if domain else ""
    return f"quieres {intent}{dom} — \"{q}\""
