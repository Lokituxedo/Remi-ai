from pathlib import Path
PROJECT_ROOT = Path(__file__).resolve().parents[1]
import httpx
from pathlib import Path
"""Remi-AI Router Client v17 — Modelos con cuota actualizada (2026-09-15)"""
import requests
import json

ROUTER_URL = "http://localhost:20128/v1"
API_KEY = "sk-97dd8fac70570745-1vxr87-bc4ff361"

# ── MODELOS CON CUOTA DISPONIBLE (qwencloud) ──
QWEN_MODELS = {
    # Texto - alta capacidad
    "qwen-max": "oq/qwen3.8-max-0902",      # 996K/1M (99.6%) - reset 2026-12-01
    "qwen-27b": "oq/qwen3.8-27b",           # 1M/1M (100%) - reset 2026-11-18
    
    # Código
    "qwen-coder": "oq/qwen3-coder-plus",    # via openai-qwen
    "kimi-code": "oq/kimi-k2.7-code",       # 600K/1M (60%) - reset 2026-11-06
    
    # Análisis rápido
    "deepseek-flash": "oq/deepseek-v4.1-flash",  # 997K/1M (99.7%) - reset 2026-12-13
    "deepseek-pro": "oq/deepseek-v4-pro",         # 1M/1M (100%) - reset 2026-11-06
    
    # Razonamiento general
    "glm": "oq/glm-5.2",                    # via openai-qwen
}

# ── MODELOS MULTIMODALES ──
MULTIMODAL_MODELS = {
    # Video generation
    "video": "oq/wan3.0-video",             # 30/30 segundos - reset 2026-11-06
    "video-prime": "oq/wan3.0-video-prime", # 30/30 segundos - reset 2026-11-21
    
    # Image generation
    "image": "oq/qwen-image-3.0",           # 10/10 imágenes - reset 2026-11-06
    "image-pro": "oq/qwen-image-3.0-pro",   # 10/10 imágenes - reset 2026-11-06
}

# ── FREE TIER (fallback) ──
FREE_MODELS = {
    "all-free": "all-free-tier",
    "nemotron": "nemotron-full-family",
}

class RemiRouterClient:

    # ═══ MÉTODOS MULTIMODALES (OpenClaw Nativo - Stdlib Only) ═══
    
    def generate_image_qwen(self, prompt, model="wan2.6-t2i", size="1024*1024"):
        """Genera imagen vía OpenClaw nativo (sin dependencias externas)"""
        try:
            out_dir = Path("00-docs/generated_images")
            out_dir.mkdir(parents=True, exist_ok=True)
            import time
            ts = int(time.time())
            safe = "".join(c if c.isalnum() else "_" for c in prompt)[:30]
            out_path = out_dir / f"qwen_img_{ts}_{safe}.png"
            
            request_json = json.dumps({"prompt": prompt, "size": size})
            cmd = [
                "python3",
                ".agents/skills/qwencloud-image-generation/scripts/image.py",
                "--request", request_json,
                "--model", model,
                "--output", str(out_path),
                "--print-response"
            ]
            
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=180)
            
            if result.returncode == 0:
                # Parsear JSON de stdout
                try:
                    data = json.loads(result.stdout)
                    if "image_url" in data or out_path.exists():
                        return {
                            "status": "ok",
                            "filepath": str(out_path),
                            "size_bytes": out_path.stat().st_size if out_path.exists() else 0,
                            "prompt": prompt,
                            "model": model,
                            "source": "openclaw_native",
                            "image_url": data.get("image_url"),
                            "width": data.get("width"),
                            "height": data.get("height")
                        }
                except json.JSONDecodeError:
                    pass
            
            return {
                "status": "error",
                "error": result.stderr or "Unknown error",
                "stdout": result.stdout[:500]
            }
        except subprocess.TimeoutExpired:
            return {"status": "error", "error": "Timeout (180s)"}
        except Exception as e:
            return {"status": "error", "error": str(e)}
    
    def text_to_speech(self, text, voice="Cherry", model="qwen3-tts-flash"):
        """Sintetiza voz vía OpenClaw TTS"""
        try:
            out_dir = Path("00-docs/generated_audio")
            out_dir.mkdir(parents=True, exist_ok=True)
            import time
            ts = int(time.time())
            out_path = out_dir / f"qwen_tts_{ts}.wav"
            
            request_json = json.dumps({"text": text, "voice": voice})
            cmd = [
                "python3",
                ".agents/skills/qwencloud-audio-tts/scripts/tts.py",
                "--request", request_json,
                "--model", model,
                "--output", str(out_path),
                "--print-response"
            ]
            
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
            
            if result.returncode == 0 and out_path.exists():
                return {
                    "status": "ok",
                    "filepath": str(out_path),
                    "size_bytes": out_path.stat().st_size,
                    "source": "openclaw_native"
                }
            
            return {
                "status": "error",
                "error": result.stderr or "TTS failed",
                "stdout": result.stdout[:500]
            }
        except Exception as e:
            return {"status": "error", "error": str(e)}
    
    def analyze_image(self, image_path, prompt="Describe this image in detail"):
        """Analiza imagen con Qwen VL vía OpenClaw"""
        try:
            request_json = json.dumps({"image": str(image_path), "prompt": prompt})
            cmd = [
                "python3",
                ".agents/skills/qwencloud-vision/scripts/analyze.py",
                "--request", request_json,
                "--print-response"
            ]
            
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
            
            if result.returncode == 0:
                try:
                    data = json.loads(result.stdout)
                    return {"status": "ok", "data": data, "source": "openclaw_native"}
                except json.JSONDecodeError:
                    return {"status": "ok", "text": result.stdout}
            
            return {"status": "error", "error": result.stderr}
        except Exception as e:
            return {"status": "error", "error": str(e)}
    
    def ocr(self, image_path):
        """Extrae texto de imagen vía OpenClaw OCR"""
        try:
            cmd = [
                "python3",
                ".agents/skills/qwencloud-vision/scripts/ocr.py",
                "--image", str(image_path),
                "--print-response"
            ]
            
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
            
            if result.returncode == 0:
                try:
                    data = json.loads(result.stdout)
                    return {"status": "ok", "text": data.get("text", ""), "source": "openclaw_native"}
                except json.JSONDecodeError:
                    return {"status": "ok", "text": result.stdout}
            
            return {"status": "error", "error": result.stderr}
        except Exception as e:
            return {"status": "error", "error": str(e)}

    def __init__(self):
        self.url = ROUTER_URL
        self.headers = {"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"}
    
    def _extract_content(self, message: dict) -> str:
        if message.get("content"):
            return message["content"]
        if message.get("reasoning"):
            return message["reasoning"]
        if message.get("reasoning_details"):
            rd = message["reasoning_details"]
            if isinstance(rd, list) and len(rd) > 0 and isinstance(rd[0], dict):
                return rd[0].get("text", "")
        return ""
    
    def resolve_model(self, key: str) -> str:
        if key in QWEN_MODELS: return QWEN_MODELS[key]
        if key in MULTIMODAL_MODELS: return MULTIMODAL_MODELS[key]
        if key in FREE_MODELS: return FREE_MODELS[key]
        return key
    
    def _chat_single(self, model_name: str, prompt: str, max_tokens: int, temperature: float) -> dict:
        try:
            r = requests.post(
                f"{self.url}/chat/completions",
                headers=self.headers,
                json={
                    "model": model_name,
                    "messages": [{"role": "user", "content": prompt}],
                    "max_tokens": max_tokens,
                    "temperature": temperature,
                    "stream": False
                },
                timeout=60
            )
            if r.status_code != 200:
                return {"status": "error", "code": r.status_code, "text": r.text[:300], "model_used": model_name}
            
            data = r.json()
            choice = data.get("choices", [{}])[0]
            message = choice.get("message", {})
            content = self._extract_content(message)
            
            return {
                "status": "ok",
                "model_used": model_name,
                "content": content,
                "usage": data.get("usage", {}),
                "finish_reason": choice.get("finish_reason")
            }
        except Exception as e:
            return {"status": "error", "error": str(e), "model_used": model_name}
    
    def chat(self, prompt: str, model: str = None, combo: str = None, provider: str = None, max_tokens: int = 2000, temperature: float = 0.3):
        model_key = model or combo or provider or "qwen-max"
        model_name = self.resolve_model(model_key)
        
        # Intentar modelo primario
        result = self._chat_single(model_name, prompt, max_tokens, temperature)
        if result["status"] == "ok":
            return result
        
        # Fallback: free tier
        fallback = self._chat_single(self.resolve_model("all-free"), prompt, max_tokens, temperature)
        if fallback["status"] == "ok":
            return fallback
        
        return result

    def generate_image(self, prompt=None, worker_url="https://texto-a-imagen.ryd-servicio.workers.dev/"):
        """Genera imagen via Cloudflare Worker (stable-diffusion-xl-base-1.0)."""
        import requests
        import time
        from pathlib import Path as P

        try:
            params = {"prompt": prompt} if prompt else {}
            r = requests.get(worker_url, params=params, timeout=120)
            if r.status_code == 200 and r.headers.get("content-type", "").startswith("image/"):
                img_dir = P("00-docs/generated_images")
                img_dir.mkdir(parents=True, exist_ok=True)
                ts = int(time.time())
                safe = "".join(c if c.isalnum() else "_" for c in (prompt or "default"))[:30]
                fpath = img_dir / f"img_{ts}_{safe}.png"
                fpath.write_bytes(r.content)
                return {
                    "status": "ok",
                    "filepath": str(fpath),
                    "size_bytes": len(r.content),
                    "prompt": r.headers.get("x-prompt", prompt or "default"),
                    "dimensions": "1024x1024"
                }
            return {"status": "error", "code": r.status_code, "text": r.text[:200]}
        except Exception as e:
            return {"status": "error", "error": str(e)}

    # ── MÉTODOS NATIVOS QWENCLOUD (vía scripts oficiales) ──
    # Usan la API directa de DashScope, sin 9router ni worker CF

    SKILL_PATHS = {
        "image": str(PROJECT_ROOT / ".agents/skills/qwencloud-image-generation/scripts/image.py"),
        "video": str(PROJECT_ROOT / ".agents/skills/qwencloud-video-generation/scripts/video.py"),
        "vision": str(PROJECT_ROOT / ".agents/skills/qwencloud-vision/scripts/analyze.py"),
        "ocr": str(PROJECT_ROOT / ".agents/skills/qwencloud-vision/scripts/ocr.py"),
        "tts": str(PROJECT_ROOT / ".agents/skills/qwencloud-audio-tts/scripts/tts.py"),
    }

    def _run_skill(self, script_path, request_dict, extra_args=None, timeout=300):
        """Ejecuta un script oficial de QwenCloud skills."""
        import subprocess, json, os
        env = os.environ.copy()
        env["DASHSCOPE_API_KEY"] = env.get("DASHSCOPE_API_KEY", "sk-97dd8fac70570745-1vxr87-bc4ff361")
        cmd = ["python3", str(script_path), "--request", json.dumps(request_dict), "--print-response"]
        if extra_args:
            cmd.extend(extra_args)
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, env=env, cwd=str(Path.cwd()))
            if r.returncode != 0:
                return {"status": "error", "stderr": r.stderr[:500], "stdout": r.stdout[:500]}
            try:
                data = json.loads(r.stdout)
                return {"status": "ok", "data": data}
            except:
                return {"status": "ok", "raw": r.stdout}
        except subprocess.TimeoutExpired:
            return {"status": "error", "error": "timeout"}
        except Exception as e:
            return {"status": "error", "error": str(e)}

    def generate_image_qwen(self, prompt, model="wan2.6-t2i", size="1280*1280"):
        from pathlib import Path as P
        """Genera imagen vía QwenCloud nativo (wan2.6-t2i default)."""
        import time
        out_dir = P("00-docs/generated_images")
        out_dir.mkdir(parents=True, exist_ok=True)
        ts = int(time.time())
        safe = "".join(c if c.isalnum() else "_" for c in prompt)[:30]
        out_path = out_dir / f"qwen_img_{ts}_{safe}.png"
        req = {"prompt": prompt, "size": size}
        result = self._run_skill(
            self.SKILL_PATHS["image"], req,
            extra_args=["--model", model, "--output", str(out_path)],
            timeout=180
        )
        if result["status"] == "ok" and out_path.exists():
            return {
                "status": "ok",
                "filepath": str(out_path),
                "size_bytes": out_path.stat().st_size,
                "prompt": prompt,
                "model": model,
                "source": "qwencloud_native"
            }
        return result

    def generate_video(self, prompt, duration=5, model="wan2.6-t2v", size="1280*720"):
        from pathlib import Path as P
        """Genera video vía QwenCloud nativo (wan2.6-t2v default, async)."""
        import time
        out_dir = P("00-docs/generated_videos")
        out_dir.mkdir(parents=True, exist_ok=True)
        req = {"prompt": prompt, "size": size, "duration": duration}
        result = self._run_skill(
            self.SKILL_PATHS["video"], req,
            extra_args=["--model", model, "--output", str(out_dir)],
            timeout=600
        )
        return result

    def analyze_image(self, image_source, prompt="Describe this image in detail"):
        """Analiza imagen/video con Qwen VL (qwen3.6-plus default)."""
        req = {"prompt": prompt, "image": image_source}
        return self._run_skill(self.SKILL_PATHS["vision"], req, timeout=120)

    def ocr(self, image_source):
        """Extrae texto de imagen con qwen-vl-ocr."""
        req = {"image": image_source}
        return self._run_skill(self.SKILL_PATHS["ocr"], req, timeout=120)

    def text_to_speech(self, text, voice="Cherry", model="qwen3-tts-flash"):
        from pathlib import Path as P
        """Sintetiza voz desde texto (qwen3-tts-flash default)."""
        import time
        out_dir = P("00-docs/generated_audio")
        out_dir.mkdir(parents=True, exist_ok=True)
        req = {"text": text[:600], "voice": voice}
        result = self._run_skill(
            self.SKILL_PATHS["tts"], req,
            extra_args=["--model", model, "--output", str(out_dir)],
            timeout=120
        )
        return result

    def check_usage(self):
        """Consulta uso/cuotas vía QwenCloud CLI."""
        import subprocess
        try:
            r = subprocess.run(
                ["qwencloud", "usage", "summary", "--format", "text"],
                capture_output=True, text=True, timeout=30
            )
            if r.returncode == 0:
                return {"status": "ok", "usage": r.stdout}
            return {"status": "error", "error": r.stderr[:500]}
        except Exception as e:
            return {"status": "error", "error": str(e)}
