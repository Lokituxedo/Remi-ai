from pathlib import Path
PROJECT_ROOT = Path(__file__).resolve().parents[1]
import json, sys
from pathlib import Path
sys.path.insert(0, str(PROJECT_ROOT))
from router.nrouter_client import NineRouterClient

client = NineRouterClient()
results = {"tests": []}

# Test 1: Health
h = client.health_check()
results["tests"].append({"test": "health", "status": "ok" if h["status"]=="ok" else "fail", "result": h})
if h["status"] != "ok":
    print(json.dumps(results, indent=2)); exit(0)

# Test 2: Combo qwen_coding (OpenRouter BYOK - activo)
t = client.chat("Responde solo: QWEN_CODING_OK", combo="qwen_coding", max_tokens=30)
results["tests"].append({"test": "combo_qwen_coding", "status": "ok" if t["status"]=="ok" and "QWEN_CODING_OK" in (t.get("content") or "").upper() else "fail", "model": t.get("model_used"), "content": (t.get("content") or "")[:60]})

# Test 3: Combo qwen_advanced
t = client.chat("Responde solo: ADVANCED_OK", combo="qwen_advanced", max_tokens=30)
results["tests"].append({"test": "combo_qwen_advanced", "status": "ok" if t["status"]=="ok" else "fail", "model": t.get("model_used"), "content": (t.get("content") or "")[:60]})

# Test 4: Combo nemotron_free (OpenRouter free tier)
t = client.chat("Responde solo: FREE_OK", combo="nemotron_free", max_tokens=30)
results["tests"].append({"test": "combo_nemotron_free", "status": "ok" if t["status"]=="ok" else "fail", "model": t.get("model_used"), "content": (t.get("content") or "")[:60]})

# Test 5: Modelo directo qwen3.8-max BYOK Alibaba
t = client.chat("Responde solo: BYOK_QWEN_OK", model="qwen3.8-max", max_tokens=30)
results["tests"].append({"test": "direct_qwen38max", "status": "ok" if t["status"]=="ok" and "BYOK_QWEN_OK" in (t.get("content") or "").upper() else "fail", "model": t.get("model_used"), "content": (t.get("content") or "")[:60]})

# Test 6: Modelo directo nemotron-lightning free
t = client.chat("Responde solo: NEMOTRON_OK", model="nemotron-lightning", max_tokens=30)
results["tests"].append({"test": "direct_nemotron_free", "status": "ok" if t["status"]=="ok" else "fail", "model": t.get("model_used"), "content": (t.get("content") or "")[:60]})

# Test 7: Search SearXNG
s = client.search("Remi AI")
results["tests"].append({"test": "search_searxng", "status": "ok" if s["status"]=="ok" else "fail", "details": str(s)[:150]})

passed = sum(1 for t in results["tests"] if t["status"]=="ok")
total = len(results["tests"])
results["summary"] = {"passed": passed, "total": total, "verdict": "ROUTER_OPERATIVO" if passed==total else "ROUTER_PARCIAL"}
print(json.dumps(results, indent=2, ensure_ascii=False))
