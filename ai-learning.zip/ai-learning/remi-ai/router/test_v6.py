from pathlib import Path
PROJECT_ROOT = Path(__file__).resolve().parents[1]
import sys, json
sys.path.insert(0, str(PROJECT_ROOT))
from router.nrouter_client import RemiRouterClient

client = RemiRouterClient()

print("=" * 70)
print("  TEST CLIENTE v6 - Parser defensivo")
print("=" * 70)

# Test 1: Combo all_free (el que fallaba)
print("\n[TEST 1] combo: all_free")
r = client.chat("Di exactamente: FREE_OK", combo="all_free", max_tokens=200)
if r["status"] == "ok":
    print(f"  OK  Modelo: {r['model_used']}")
    print(f"  Content: {r['content'][:80]}")
    print(f"  Tokens: {r['usage'].get('total_tokens', '?')}")
else:
    print(f"  ERR: {r}")

# Test 2: Combo nemotron_free
print("\n[TEST 2] combo: nemotron_free")
r = client.chat("Di exactamente: NEMO_OK", combo="nemotron_free", max_tokens=200)
if r["status"] == "ok":
    print(f"  OK  Modelo: {r['model_used']}")
    print(f"  Content: {r['content'][:80]}")
else:
    print(f"  ERR: {r}")

# Test 3: Combo qwen_coding
print("\n[TEST 3] combo: qwen_coding")
r = client.chat("Escribe solo: def hello(): return 'world'", combo="qwen_coding", max_tokens=300)
if r["status"] == "ok":
    print(f"  OK  Modelo: {r['model_used']}")
    print(f"  Content: {r['content'][:100]}")
else:
    print(f"  ERR: {r}")

print("\n" + "=" * 70)
