from pathlib import Path
PROJECT_ROOT = Path(__file__).resolve().parents[1]
import sys, json
sys.path.insert(0, str(PROJECT_ROOT))
from router.nrouter_client import RemiRouterClient

client = RemiRouterClient()

print("=" * 70)
print("  TEST CLIENTE v7 - Qwen directo + Free tier")
print("=" * 70)

tests = [
    ("qwen3.8-max", "Qwen 3.8 Max", "Di exactamente: QWEN38MAX_OK", None),
    ("qwen3-coder-plus", "Qwen Coder Plus", "Escribe solo: def hello(): return world", None),
    ("glm-5.2", "GLM 5.2", "Di exactamente: GLM_OK", None),
    ("all_free", "Free tier", "Di exactamente: FREE_OK", "all_free"),
]

for key, name, prompt, combo in tests:
    model_arg = None if combo else key
    r = client.chat(prompt, model=model_arg, combo=combo, max_tokens=50 if not combo else 50)
    status_str = "OK" if r["status"] == "ok" else "ERR"
    print(f"\n[TEST] {name} ({key})")
    if r["status"] == "ok":
        print(f"  {status_str} Modelo: {r['model_used']}")
        print(f"  Content: {r['content'][:80]}")
    else:
        err = r.get("text") or r.get("error") or "unknown"
        print(f"  {status_str} Error: {err[:150]}")

print("\n" + "=" * 70)
