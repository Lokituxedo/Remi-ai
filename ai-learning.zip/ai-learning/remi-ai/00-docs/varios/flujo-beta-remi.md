Plain text




┌─────────────────────────────────────────────────────────────────────────┐
│                                                                         │
│  LOCAL                    CLOUDFLARE                         CLOUD      │
│  ─────                    ──────────                         ─────      │
│                                                                         │
│  Agente                   Worker                    QwenCloud           │
│  (Ollama)                 (Vectoriza + D1)          (Modelo final)     │
│     │                        │                          │              │
│     │   Cloudflare Tunnel    │                          │              │
│     ├───────────────────────►│                          │              │
│     │                        │                          │              │
│     │                        ├──► Embedding             │              │
│     │                        │    (vectoriza input)     │              │
│     │                        │                          │              │
│     │                        ├──► D1: ¿Coincide?        │              │
│     │                        │         │                │              │
│     │                        │    ┌────┴────┐           │              │
│     │                        │    │         │           │              │
│     │                        │   SÍ        NO           │              │
│     │                        │    │         │           │              │
│     │                        │    │         ├──────────►│              │
│     │                        │    │         │           │              │
│     │                        │    │         │◄──────────┤              │
│     │                        │    │         │           │              │
│     │                        │    │         ├──► D1:    │              │
│     │                        │    │         │   Almacena│              │
│     │                        │    │         │           │              │
│     │                        │    ▼         ▼           │              │
│     │                        │    └────┬────┘           │              │
│     │                        │         │                │              │
│     │                        │         ├──► D1: Registra│              │
│     │                        │         │   (log query)  │              │
│     │                        │         │                │              │
│     │◄───────────────────────┤         │                │              │
│     │   Devuelve JSON        │         ▼                │              │
│     │                        │      OUTPUT              │              │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
D1 = 3 funciones simultáneas
Función	Qué hace
Cache semántico	Si el vector ya existe (similitud alta) → no llama a QwenCloud
Base de conocimiento	Acumula respuestas, cada vez necesita menos cloud
Registro/auditoría	Cada query queda logueada (qué, cuándo, resultado, fuente)
Schema D1
SQL




-- wrangler.toml → [[d1_databases]]
-- migration 0001

-- Tabla principal: materiales procesados
CREATE TABLE IF NOT EXISTS materials (
    id TEXT PRIMARY KEY,
    vector BLOB NOT NULL,           -- Vector embedding (1024 floats como bytes)
    input_text TEXT NOT NULL,       -- Texto original (prompt chino/español/etc)
    input_lang TEXT DEFAULT 'auto', -- Idioma detectado
    output_json TEXT NOT NULL,      -- Resultado JSON del modelo
    model_used TEXT,                -- Qué modelo generó (qwen-plus, local, etc)
    source TEXT NOT NULL,           -- 'qwencloud' | 'cache_hit' | 'local'
    quality_score INTEGER,          -- Score de calidad
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now')),
    hit_count INTEGER DEFAULT 0    -- Cuántas veces fue reutilizado
);

-- Tabla de registro/auditoría
CREATE TABLE IF NOT EXISTS query_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT DEFAULT (datetime('now')),
    input_hash TEXT NOT NULL,       -- Hash del input
    input_preview TEXT,             -- Primeros 200 chars
    vector_match_id TEXT,           -- ID del material si hubo match
    similarity REAL,                -- Score de similitud (0-1)
    action TEXT NOT NULL,           -- 'cache_hit' | 'cloud_call' | 'error'
    model_called TEXT,              -- Modelo que se usó (si fue cloud)
    latency_ms INTEGER,
    tokens_used INTEGER,
    client_id TEXT,                 -- Identificador del cliente local
    metadata TEXT                   -- JSON extra
);

-- Tabla de estado del sistema
CREATE TABLE IF NOT EXISTS system_state (
    key TEXT PRIMARY KEY,
    value TEXT,
    updated_at TEXT DEFAULT (datetime('now'))
);

-- Índices
CREATE INDEX IF NOT EXISTS idx_materials_lang ON materials(input_lang);
CREATE INDEX IF NOT EXISTS idx_materials_created ON materials(created_at);
CREATE INDEX IF NOT EXISTS idx_query_log_time ON query_log(timestamp);
CREATE INDEX IF NOT EXISTS idx_query_log_action ON query_log(action);
CREATE INDEX IF NOT EXISTS idx_query_log_hash ON query_log(input_hash);
wrangler.toml
TOML




name = "cb-vector-worker"
main = "src/index.ts"
compatibility_date = "2024-06-01"

# D1 Database
[[d1_databases]]
binding = "DB"
database_name = "cb-materials-db"
database_id = "tu-database-id"

# Workers AI (para embedding en edge)
[ai]
binding = "AI"

# KV para cache caliente (opcional, complementa D1)
[[kv_namespaces]]
binding = "HOT_CACHE"
id = "tu-kv-id"

# Secrets (setear con wrangler secret put)
# DASHSCOPE_API_KEY
# TUNNEL_SECRET
Migrar
BASH




# Crear la base
wrangler d1 create cb-materials-db

# Copiar el database_id al wrangler.toml

# Ejecutar migración
wrangler d1 execute cb-materials-db --file=./schema.sql

# Verificar
wrangler d1 execute cb-materials-db --command="SELECT name FROM sqlite_master WHERE type='table';"
Worker completo con D1
src/index.ts
TYPESCRIPT




/**
 * Worker principal: Vectoriza → Busca en D1 → Decide → Devuelve
 * 
 * Flujo:
 * 1. Recibe input (texto, puede ser chino)
 * 2. Vectoriza (Workers AI bge-m3 o DashScope)
 * 3. Busca coincidencia en D1 (similitud coseno)
 * 4. Si coincide (≥ threshold) → devuelve cached + registra
 * 5. Si no coincide → llama a QwenCloud → almacena en D1 → devuelve + registra
 */

export interface Env {
  DB: D1Database;
  AI: Ai;
  HOT_CACHE: KVNamespace;
  DASHSCOPE_API_KEY: string;
  SIMILARITY_THRESHOLD: string;  // "0.92"
}

interface ProcessRequest {
  text: string;
  lang?: string;
  task_type?: "generate" | "translate" | "adapt" | "embed_only";
  target_market?: string;
  platform?: string;
  client_id?: string;
  force_cloud?: boolean;  // Si true, salta cache
}

interface ProcessResponse {
  status: "success" | "error";
  data: any;
  source: "cache_hit" | "cloud_call" | "local_edge";
  similarity?: number;
  model_used?: string;
  latency_ms: number;
  cached_result_id?: string;
}

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    // CORS
    if (request.method === "OPTIONS") {
      return cors();
    }

    const url = new URL(request.url);
    const path = url.pathname;

    // ─── ROUTING DE ENDPOINTS ────────────────────────────────────
    switch (path) {
      case "/process":
        return handleProcess(request, env);
      case "/embed":
        return handleEmbedOnly(request, env);
      case "/stats":
        return handleStats(request, env);
      case "/health":
        return handleHealth(request, env);
      default:
        return json({ error: "not_found", endpoints: ["/process", "/embed", "/stats", "/health"] }, 404);
    }
  },
};

// ═══════════════════════════════════════════════════════════════════
// ENDPOINT PRINCIPAL: /process
// ═══════════════════════════════════════════════════════════════════

async function handleProcess(request: Request, env: Env): Promise<Response> {
  if (request.method !== "POST") {
    return json({ error: "method_not_allowed" }, 405);
  }

  const start = Date.now();

  try {
    const body: ProcessRequest = await request.json();

    // ─── VALIDACIÓN ──────────────────────────────────────────────
    if (!body.text || body.text.trim().length === 0) {
      return json({ error: "missing_text" }, 400);
    }
    if (body.text.length > 32000) {
      return json({ error: "text_too_long", max: 32000 }, 400);
    }

    const threshold = parseFloat(env.SIMILARITY_THRESHOLD || "0.92");
    const inputHash = await sha256(body.text);

    // ─── PASO 1: VERIFICAR CACHE CALIENTE (KV) ──────────────────
    if (!body.force_cloud) {
      const hotResult = await env.HOT_CACHE.get(`proc:${inputHash}`, "json");
      if (hotResult) {
        // Cache hit en KV (más rápido que D1)
        await logQuery(env, {
          input_hash: inputHash,
          input_preview: body.text.substring(0, 200),
          vector_match_id: hotResult.id,
          similarity: 1.0,
          action: "cache_hit",
          latency_ms: Date.now() - start,
          client_id: body.client_id,
        });

        // Incrementar hit count
        await env.DB.prepare(
          "UPDATE materials SET hit_count = hit_count + 1 WHERE id = ?"
        ).bind(hotResult.id).run();

        return json({
          status: "success",
          data: hotResult.output,
          source: "cache_hit",
          similarity: 1.0,
          model_used: hotResult.model,
          latency_ms: Date.now() - start,
          cached_result_id: hotResult.id,
        });
      }
    }

    // ─── PASO 2: VECTORIZAR ──────────────────────────────────────
    let vector: number[];
    let embedModel: string;

    try {
      // Intentar Workers AI (gratis, edge)
      const embedResult = await env.AI.run("@cf/baai/bge-m3", {
        text: body.text,
      });
      vector = embedResult.data[0];
      embedModel = "bge-m3 (cloudflare edge)";
    } catch (e) {
      // Fallback: DashScope
      const dsResult = await embedViaDashScope(body.text, env);
      vector = dsResult;
      embedModel = "text-embedding-v3 (dashscope)";
    }

    // Si solo pide embedding
    if (body.task_type === "embed_only") {
      return json({
        status: "success",
        data: { vector, dims: vector.length, model: embedModel },
        source: "local_edge",
        latency_ms: Date.now() - start,
      });
    }

    // ─── PASO 3: BUSCAR COINCIDENCIA EN D1 ───────────────────────
    if (!body.force_cloud) {
      const match = await findSimilarInD1(env, vector, threshold);

      if (match) {
        // ═══ COINCIDENCIA ENCONTRADA ═══
        // Devolver resultado almacenado + registrar

        // Actualizar hit count
        await env.DB.prepare(
          "UPDATE materials SET hit_count = hit_count + 1, updated_at = datetime('now') WHERE id = ?"
        ).bind(match.id).run();

        // Guardar en cache caliente (KV) para próximas veces
        await env.HOT_CACHE.put(`proc:${inputHash}`, JSON.stringify({
          id: match.id,
          output: JSON.parse(match.output_json),
          model: match.model_used,
        }), { expirationTtl: 3600 });  // 1 hora

        // Registrar
        await logQuery(env, {
          input_hash: inputHash,
          input_preview: body.text.substring(0, 200),
          vector_match_id: match.id,
          similarity: match.similarity,
          action: "cache_hit",
          latency_ms: Date.now() - start,
          client_id: body.client_id,
        });

        return json({
          status: "success",
          data: JSON.parse(match.output_json),
          source: "cache_hit",
          similarity: match.similarity,
          model_used: match.model_used,
          latency_ms: Date.now() - start,
          cached_result_id: match.id,
        });
      }
    }

    // ─── PASO 4: NO HAY COINCIDENCIA → LLAMAR A QWENCLOUD ───────
    const cloudResult = await callQwenCloud(body, env);

    if (!cloudResult.success) {
      // Registrar error
      await logQuery(env, {
        input_hash: inputHash,
        input_preview: body.text.substring(0, 200),
        action: "error",
        latency_ms: Date.now() - start,
        client_id: body.client_id,
        metadata: JSON.stringify({ error: cloudResult.error }),
      });

      return json({
        status: "error",
        error: cloudResult.error,
        latency_ms: Date.now() - start,
      }, 502);
    }

    // ─── PASO 5: ALMACENAR EN D1 ─────────────────────────────────
    const materialId = crypto.randomUUID();
    const vectorBlob = new Uint8Array(new Float32Array(vector).buffer);

    await env.DB.prepare(`
      INSERT INTO materials (id, vector, input_text, input_lang, output_json, model_used, source, quality_score)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      materialId,
      vectorBlob,
      body.text,
      body.lang || "auto",
      JSON.stringify(cloudResult.data),
      cloudResult.model,
      "qwencloud",
      cloudResult.data?.quality_score || null
    ).run();

    // Guardar en cache caliente
    await env.HOT_CACHE.put(`proc:${inputHash}`, JSON.stringify({
      id: materialId,
      output: cloudResult.data,
      model: cloudResult.model,
    }), { expirationTtl: 3600 });

    // ─── PASO 6: REGISTRAR ───────────────────────────────────────
    await logQuery(env, {
      input_hash: inputHash,
      input_preview: body.text.substring(0, 200),
      vector_match_id: materialId,
      similarity: 0,
      action: "cloud_call",
      model_called: cloudResult.model,
      latency_ms: Date.now() - start,
      tokens_used: cloudResult.tokens_used,
      client_id: body.client_id,
    });

    // ─── PASO 7: DEVOLVER ────────────────────────────────────────
    return json({
      status: "success",
      data: cloudResult.data,
      source: "cloud_call",
      model_used: cloudResult.model,
      latency_ms: Date.now() - start,
      cached_result_id: materialId,
    });

  } catch (error) {
    return json({
      status: "error",
      error: String(error),
      latency_ms: Date.now() - start,
    }, 500);
  }
}

// ═══════════════════════════════════════════════════════════════════
// BÚSQUEDA DE SIMILITUD EN D1
// ═══════════════════════════════════════════════════════════════════

async function findSimilarInD1(
  env: Env,
  queryVector: number[],
  threshold: number
): Promise<{ id: string; output_json: string; model_used: string; similarity: number } | null> {
  /**
   * D1 es SQLite, no tiene búsqueda vectorial nativa.
   * Estrategia:
   *   - Si la base es pequeña (<10k registros): cargar vectores y calcular en Worker
   *   - Si es grande: usar Vectorize como índice y D1 como storage
   * 
   * Para tu caso (base intermedia), asumo tamaño manejable.
   * Si crece mucho, migramos a Vectorize + D1.
   */

  try {
    // Obtener todos los materiales (limitado para no exceder memoria del Worker)
    const results = await env.DB.prepare(
      "SELECT id, vector, output_json, model_used FROM materials ORDER BY created_at DESC LIMIT 5000"
    ).all();

    if (!results.results || results.results.length === 0) {
      return null;
    }

    let bestMatch: any = null;
    let bestSimilarity = 0;

    for (const row of results.results) {
      // Convertir BLOB a array de floats
      const storedVector = new Float32Array(row.vector as ArrayBuffer);
      const storedArray = Array.from(storedVector);

      // Calcular similitud coseno
      const sim = cosineSimilarity(queryVector, storedArray);

      if (sim > bestSimilarity) {
        bestSimilarity = sim;
        bestMatch = row;
      }

      // Early exit si encontramos match perfecto
      if (sim >= 0.99) break;
    }

    if (bestSimilarity >= threshold && bestMatch) {
      return {
        id: bestMatch.id as string,
        output_json: bestMatch.output_json as string,
        model_used: bestMatch.model_used as string,
        similarity: bestSimilarity,
      };
    }

    return null;

  } catch (e) {
    // Si falla la búsqueda, no bloquear → ir a cloud
    return null;
  }
}

function cosineSimilarity(a: number[], b: number[]): number {
  if (a.length !== b.length) return 0;

  let dot = 0, normA = 0, normB = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }

  const denom = Math.sqrt(normA) * Math.sqrt(normB);
  if (denom === 0) return 0;
  return dot / denom;
}

// ═══════════════════════════════════════════════════════════════════
// LLAMADA A QWENCLOUD
// ═══════════════════════════════════════════════════════════════════

async function callQwenCloud(
  body: ProcessRequest,
  env: Env
): Promise<{ success: boolean; data?: any; model?: string; tokens_used?: number; error?: string }> {
  try {
    const systemPrompt = buildSystemPrompt(body);
    const userPrompt = body.text;

    const resp = await fetch(
      "https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation",
      {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${env.DASHSCOPE_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "qwen-plus",
          input: {
            messages: [
              { role: "system", content: systemPrompt },
              { role: "user", content: userPrompt },
            ],
          },
          parameters: {
            temperature: 0.0,
            max_tokens: 4096,
            result_format: "message",
            response_format: { type: "json_object" },
          },
        }),
      }
    );

    if (!resp.ok) {
      const errText = await resp.text();
      return { success: false, error: `QwenCloud HTTP ${resp.status}: ${errText}` };
    }

    const data = await resp.json() as any;
    const content = data.output?.choices?.[0]?.message?.content;

    if (!content) {
      return { success: false, error: "Empty response from QwenCloud" };
    }

    // Parsear JSON
    let parsed: any;
    try {
      parsed = JSON.parse(content);
    } catch {
      // Intentar limpiar
      const cleaned = content.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
      try {
        parsed = JSON.parse(cleaned);
      } catch {
        return { success: false, error: "QwenCloud returned invalid JSON" };
      }
    }

    return {
      success: true,
      data: parsed,
      model: "qwen-plus",
      tokens_used: data.usage?.total_tokens || 0,
    };

  } catch (error) {
    return { success: false, error: String(error) };
  }
}

function buildSystemPrompt(body: ProcessRequest): string {
  const base = "只输出有效JSON。不要输出解释、注释或其他文字。";

  if (body.task_type === "translate") {
    return `${base}\n你是专业翻译。将输入翻译为目标语言，保持电商语境。`;
  }
  if (body.task_type === "adapt") {
    return `${base}\n你是跨境电商本地化专家。根据目标市场(${body.target_market || "unknown"})和平台(${body.platform || "unknown"})适配内容。`;
  }

  return `${base}\n你是跨境电商材料生成专家。根据输入生成优化的产品材料。`;
}

// ═══════════════════════════════════════════════════════════════════
// EMBEDDING VIA DASHSCOPE (FALLBACK)
// ═══════════════════════════════════════════════════════════════════

async function embedViaDashScope(text: string, env: Env): Promise<number[]> {
  const resp = await fetch(
    "https://dashscope.aliyuncs.com/api/v1/services/embeddings/text-embedding/text-embedding",
    {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${env.DASHSCOPE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "text-embedding-v3",
        input: { texts: [text] },
        parameters: { dimension: 1024 },
      }),
    }
  );

  if (!resp.ok) throw new Error(`DashScope embedding error: ${resp.status}`);

  const data = await resp.json() as any;
  return data.output.embeddings[0].embedding;
}

// ═══════════════════════════════════════════════════════════════════
// LOGGING
// ═══════════════════════════════════════════════════════════════════

async function logQuery(env: Env, entry: {
  input_hash: string;
  input_preview?: string;
  vector_match_id?: string;
  similarity?: number;
  action: string;
  model_called?: string;
  latency_ms?: number;
  tokens_used?: number;
  client_id?: string;
  metadata?: string;
}): Promise<void> {
  try {
    await env.DB.prepare(`
      INSERT INTO query_log (input_hash, input_preview, vector_match_id, similarity, action, model_called, latency_ms, tokens_used, client_id, metadata)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      entry.input_hash,
      entry.input_preview || null,
      entry.vector_match_id || null,
      entry.similarity || null,
      entry.action,
      entry.model_called || null,
      entry.latency_ms || null,
      entry.tokens_used || null,
      entry.client_id || null,
      entry.metadata || null
    ).run();
  } catch (e) {
    // Logging no debe bloquear el flujo principal
    console.error("Log failed:", e);
  }
}

// ═══════════════════════════════════════════════════════════════════
// ENDPOINTS SECUNDARIOS
// ═══════════════════════════════════════════════════════════════════

async function handleEmbedOnly(request: Request, env: Env): Promise<Response> {
  if (request.method !== "POST") return json({ error: "method_not_allowed" }, 405);

  const body = await request.json() as { text: string };
  if (!body.text) return json({ error: "missing_text" }, 400);

  const start = Date.now();

  try {
    const result = await env.AI.run("@cf/baai/bge-m3", { text: body.text });
    return json({
      vector: result.data[0],
      dims: result.data[0].length,
      model: "bge-m3",
      latency_ms: Date.now() - start,
    });
  } catch {
    const vec = await embedViaDashScope(body.text, env);
    return json({
      vector: vec,
      dims: vec.length,
      model: "text-embedding-v3",
      latency_ms: Date.now() - start,
    });
  }
}

async function handleStats(request: Request, env: Env): Promise<Response> {
  const totalMaterials = await env.DB.prepare("SELECT COUNT(*) as count FROM materials").first();
  const totalQueries = await env.DB.prepare("SELECT COUNT(*) as count FROM query_log").first();
  const cacheHits = await env.DB.prepare("SELECT COUNT(*) as count FROM query_log WHERE action = 'cache_hit'").first();
  const cloudCalls = await env.DB.prepare("SELECT COUNT(*) as count FROM query_log WHERE action = 'cloud_call'").first();
  const avgLatency = await env.DB.prepare("SELECT AVG(latency_ms) as avg FROM query_log WHERE latency_ms IS NOT NULL").first();

  const hitRate = (totalQueries as any)?.count > 0
    ? ((cacheHits as any)?.count / (totalQueries as any)?.count * 100).toFixed(1)
    : "0";

  return json({
    materials_stored: (totalMaterials as any)?.count || 0,
    total_queries: (totalQueries as any)?.count || 0,
    cache_hits: (cacheHits as any)?.count || 0,
    cloud_calls: (cloudCalls as any)?.count || 0,
    cache_hit_rate: `${hitRate}%`,
    avg_latency_ms: Math.round((avgLatency as any)?.avg || 0),
  });
}

async function handleHealth(request: Request, env: Env): Promise<Response> {
  try {
    await env.DB.prepare("SELECT 1").first();
    return json({ status: "healthy", d1: "connected", timestamp: new Date().toISOString() });
  } catch (e) {
    return json({ status: "unhealthy", d1: "error", error: String(e) }, 500);
  }
}

// ═══════════════════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════════════════

async function sha256(text: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(text);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, "0")).join("");
}

function json(data: any, status: number = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-ID",
    },
  });
}

function cors(): Response {
  return new Response(null, {
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-ID",
    },
  });
}
Cloudflare Tunnel (Local → Worker)
config.yml del túnel
YAML




# ~/.cloudflared/config.yml

tunnel: cb-material-tunnel
credentials-file: /home/tu-usuario/.cloudflared/cb-material-tunnel.json

ingress:
  # Tu agente local accede al worker via túnel
  - hostname: cb-agent.tu-dominio.com
    service: https://cb-vector-worker.tu-subdominio.workers.dev
  - service: http_status:404
Setup del túnel
BASH




# Instalar cloudflared
curl -L https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -o /usr/local/bin/cloudflared
chmod +x /usr/local/bin/cloudflared

# Login
cloudflared tunnel login

# Crear túnel
cloudflared tunnel create cb-material-tunnel

# Configurar DNS
cloudflared tunnel route dns cb-material-tunnel cb-agent.tu-dominio.com

# Ejecutar
cloudflared tunnel run cb-material-tunnel
Alternativa: Sin túnel (acceso directo al Worker)
PYTHON




# Si tu agente local puede salir a internet directamente,
# no necesitas túnel. Solo llamas al Worker por su URL pública.

WORKER_URL = "https://cb-vector-worker.tu-subdominio.workers.dev"
Cliente Python local actualizado
PYTHON




"""
Cliente local que se comunica con el Worker de Cloudflare.
El Worker maneja: vectorización → D1 → QwenCloud.
El agente local solo envía y recibe.
"""

import requests
import json
import hashlib
from typing import Optional, Dict, Any


class CloudflareWorkerClient:
    """
    Cliente para el Worker de Cloudflare con D1.
    
    El agente local NO vectoriza ni llama a QwenCloud directamente.
    Todo lo delega al Worker via túnel o URL pública.
    """

    def __init__(
        self,
        worker_url: str = "https://cb-vector-worker.tu-subdominio.workers.dev",
        # O via túnel:
        # worker_url: str = "https://cb-agent.tu-dominio.com",
        client_id: str = "local-agent-01",
        timeout: int = 30,
    ):
        self.worker_url = worker_url.rstrip("/")
        self.client_id = client_id
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({
            "Content-Type": "application/json",
            "X-Client-ID": client_id,
        })

    def process(
        self,
        text: str,
        lang: str = "auto",
        task_type: str = "generate",
        target_market: str = None,
        platform: str = None,
        force_cloud: bool = False,
    ) -> Dict[str, Any]:
        """
        Envía texto al Worker.
        
        El Worker:
        1. Vectoriza
        2. Busca en D1
        3. Si coincide → devuelve cached
        4. Si no → llama a QwenCloud → almacena → devuelve
        
        Returns:
        {
          "status": "success",
          "data": {...},
          "source": "cache_hit" | "cloud_call",
          "similarity": 0.95,
          "model_used": "qwen-plus",
          "latency_ms": 450
        }
        """
        try:
            resp = self.session.post(
                f"{self.worker_url}/process",
                json={
                    "text": text,
                    "lang": lang,
                    "task_type": task_type,
                    "target_market": target_market,
                    "platform": platform,
                    "client_id": self.client_id,
                    "force_cloud": force_cloud,
                },
                timeout=self.timeout,
            )

            if resp.status_code == 200:
                return resp.json()
            else:
                return {
                    "status": "error",
                    "error": f"HTTP {resp.status_code}: {resp.text}",
                    "source": "none",
                }

        except requests.exceptions.Timeout:
            return {"status": "error", "error": "timeout", "source": "none"}
        except Exception as e:
            return {"status": "error", "error": str(e), "source": "none"}

    def embed_only(self, text: str) -> Optional[list]:
        """Solo vectoriza (sin procesar contra D1)."""
        try:
            resp = self.session.post(
                f"{self.worker_url}/embed",
                json={"text": text},
                timeout=10,
            )
            if resp.status_code == 200:
                return resp.json().get("vector")
            return None
        except Exception:
            return None

    def get_stats(self) -> dict:
        """Estadísticas de D1."""
        try:
            resp = self.session.get(f"{self.worker_url}/stats", timeout=5)
            if resp.status_code == 200:
                return resp.json()
            return {}
        except Exception:
            return {}

    def health_check(self) -> bool:
        """Verifica que el Worker responde."""
        try:
            resp = self.session.get(f"{self.worker_url}/health", timeout=5)
            return resp.status_code == 200
        except Exception:
            return False
Integración con el agente local
PYTHON




"""
Agente local actualizado.
Ya NO llama directamente a QwenCloud.
Todo pasa por el Worker de Cloudflare (que usa D1 como intermediario).
"""

from core.cloudflare_client import CloudflareWorkerClient


class LocalAgent:
    """
    Agente local simplificado.
    
    Responsabilidades:
    - Decidir QUÉ procesar (lógica de negocio)
    - Validar inputs y outputs (gates inquisitivos)
    - Gestionar memoria kernel (contexto inmediato)
    - Manejar fallback si el Worker no responde
    
    NO hace:
    - Vectorización (la hace el Worker)
    - Llamadas a QwenCloud (la hace el Worker)
    - Búsqueda de similitud (la hace el Worker contra D1)
    """

    def __init__(self):
        self.cf_client = CloudflareWorkerClient(
            worker_url="https://cb-vector-worker.tu-subdominio.workers.dev",
            client_id="local-agent-01",
        )
        self._kernel_memory = []  # Contexto inmediato

    def process_product(self, product: dict) -> dict:
        """Procesa un producto completo."""

        # 1. Construir texto de input
        input_text = self._build_input_text(product)

        # 2. Enviar al Worker (él decide cache vs cloud)
        result = self.cf_client.process(
            text=input_text,
            lang=product.get("source_language", "auto"),
            task_type="adapt",
            target_market=product.get("target_market"),
            platform=product.get("target_platform"),
        )

        # 3. Validar resultado
        if result["status"] != "success":
            # Fallback: intentar local
            return self._fallback_local(product)

        # 4. Gates de seguridad
        if not self._security_check(result["data"]):
            return {"status": "blocked", "reason": "security_violation"}

        # 5. Almacenar en kernel
        self._kernel_memory.append({
            "product_id": product.get("product_id"),
            "result": result,
        })

        return result

    def _build_input_text(self, product: dict) -> str:
        """Construye el texto que se envía al Worker."""
        parts = [
            f"产品: {product.get('product_name', '')}",
            f"描述: {product.get('description', '')}",
            f"目标市场: {product.get('target_market', '')}",
            f"平台: {product.get('target_platform', '')}",
        ]
        if product.get("price"):
            parts.append(f"价格: {product['price']} {product.get('currency', '')}")
        return "\n".join(parts)

    def _fallback_local(self, product: dict) -> dict:
        """Fallback si el Worker no responde."""
        # Aquí usarías Ollama local (Qwen2.5-Coder:3b)
        # con capacidades reducidas
        return {
            "status": "degraded",
            "data": {"title": product.get("product_name", ""), "description": ""},
            "source": "local_fallback",
            "flags": ["worker_unavailable", "degraded_quality"],
        }

    def _security_check(self, data: dict) -> bool:
        """Gates de seguridad locales."""
        text = str(data).lower()
        blocked = ["cures", "fda approved", "clinically proven", "100% guaranteed"]
        return not any(term in text for term in blocked)

    def get_stats(self) -> dict:
        """Estadísticas del sistema."""
        return self.cf_client.get_stats()
Flujo final resumido
Plain text




┌─────────────────────────────────────────────────────────────────────────┐
│                                                                         │
│  LOCAL (Tu máquina)                                                     │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │  Agente (Qwen2.5-Coder:3b via Ollama)                          │   │
│  │  • Decide qué procesar                                          │   │
│  │  • Valida inputs/outputs                                        │   │
│  │  • Kernel memory (contexto inmediato)                           │   │
│  │  • Fallback si Worker cae                                       │   │
│  └──────────────────────────────┬──────────────────────────────────┘   │
│                                 │                                       │
│                    Cloudflare Tunnel / HTTPS                            │
│                                 │                                       │
├─────────────────────────────────┼───────────────────────────────────────┤
│                                 ▼                                       │
│  CLOUDFLARE WORKER                                                      │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                                                                 │   │
│  │  1. Recibe texto                                                │   │
│  │  2. Vectoriza (bge-m3 edge o DashScope)                        │   │
│  │  3. Busca en D1 (similitud coseno)                             │   │
│  │         │                                                       │   │
│  │    ┌────┴────┐                                                  │   │
│  │    │         │                                                  │   │
│  │   ≥0.92    <0.92                                                │   │
│  │    │         │                                                  │   │
│  │    │         └──► QwenCloud (qwen-plus)                        │   │
│  │    │                    │                                       │   │
│  │    │                    ▼                                       │   │
│  │    │              Almacena en D1                                │   │
│  │    │                    │                                       │   │
│  │    ▼                    ▼                                       │   │
│  │  Devuelve          Devuelve                                     │   │
│  │  + registra        + registra                                   │   │
│  │  (cache_hit)       (cloud_call)                                 │   │
│  │                                                                 │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
│  D1 (SQLite en Cloudflare)                                              │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │  materials: vectores + outputs JSON + metadata                   │   │
│  │  query_log: cada consulta registrada                            │   │
│  │  system_state: configuración                                    │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
Comandos de deploy
BASH




# 1. Crear D1
wrangler d1 create cb-materials-db

# 2. Migrar schema
wrangler d1 execute cb-materials-db --file=./schema.sql

# 3. Crear KV
wrangler kv:namespace create HOT_CACHE

# 4. Secrets
wrangler secret put DASHSCOPE_API_KEY

# 5. Deploy
wrangler deploy

# 6. Test
curl -X POST https://cb-vector-worker.tu-subdominio.workers.dev/process \
  -H "Content-Type: application/json" \
  -d '{"text": "蓝牙耳机无线降噪", "lang": "zh", "task_type": "adapt", "target_market": "JP"}'

# 7. Ver stats
curl https://cb-vector-worker.tu-subdominio.workers.dev/stats
