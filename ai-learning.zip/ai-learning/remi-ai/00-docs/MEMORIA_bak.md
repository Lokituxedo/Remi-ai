# MEMORIA — Documento vivo de relevo (Remi-AI)

> Documento de relevo vivo. Cualquier modelo nuevo en una sesión lee esto y continúa
> sin necesitar el historial. El historial es la ruta, no el contenido.
> Última actualización: sesión 2026-09-25, post-inserción de principios y protocolo (i5).

## 0. RUTA
- Origen: proyecto nacido para REFUTAR que los LLMs tuvieran inteligencia real.
- Posición: i5 operativo. Cerebro nodal local, memoria persistente, grafo denso,
  routing dual LiteLLM, propagación selectiva funcionando. Validado end-to-end.
- Destino: protocolo de apertura de sesión → remi-ops → test de resiliencia →
  experimento max-vs-suma → modo puente.
- Regla de lectura: estado actual > decisiones > deuda > teoría.

## 1. ESTADO TÉCNICO VERIFICADO (i5)

| Componente | Estado | Dato |
|---|---|---|
| Raíz | /home/mpeadmin/karukren/remi-ai | resuelto, no /Desktop/ |
| remi-ai-core:latest | 1.9 GB, ID 8df76ca079ea | Modelfile sobre qwen2.5-coder:3b. Determinista, JSON puro, no conversacional. Clasificador + enrutador |
| qwen2.5-coder:3b | 1.9 GB, ID f72c60cabf62 | sustrato de pesos del core |
| qwen3-embedding:0.6b | 639 MB, ID ac6da0dfba84 | percepción semántica, vía Ollama :11434/api/embed directo |
| remi-ai-core + qwen3-embedding | díada funcional | "el modelo" de Remi; el conversacional es opcional |
| LiteLLM :4000 | dual-model | remi-router (clasificación) + remi-generator (generación) |
| Nodos | 119 activos | 108 base + 8 principios + 2 antecedentes + 1 protocolo |
| Aristas | 1062 | 1046 previas + 13 de principios + 3 de protocolo |
| Disparadores | 752 | contexto_activacion, prioridad ASC |
| Embeddings en DB | 108/108 | desde contenido .md completo |
| Huérfanos | 0 | todos conectados |
| Conocimiento | 92 .md | knowledge/ íntegro en i5 |

Rutas validadas:
1. edge_match → grafo local, sin modelo. "qué es Remi-AI" → remi_ai_genesis (score 1.00)
2. model_new → litellm/remi-generator. Función suma → código correcto
3. propagated → multi-halo real: memoria_nodal → kernel_subconsciente → activacion_paralela
4. Priorización correcta: semántica (0.728) sobre comunidad (0.660) en Feynman

## 2. LO QUE SE ARREGLÓ Y POR QUÉ

| Síntoma | Causa real | Fix |
|---|---|---|
| empty_index | Paths heredados del i7 /Desktop/ + parents[2] | parents[1] en 11 archivos |
| [fallback: router_failed: ?] | _call_router apuntaba a :20128 (inexistente en i5) | _call_litellm primero, 9router como respaldo |
| data: [] de LiteLLM | Proceso viejo de Sep22 sin config | Reinicio con venv + config dual |
| 16 aristas (grafo pobre) | Solo se embeddeaba label+descripción | Re-embed desde contenido .md completo |
| 53.7% huérfanos | Solo similitud cosena, umbral 0.65 | Clique intra-dominio + umbral 0.50 |

Lección: el grafo estaba sano; el código arrastraba la dirección postal de otra casa. Ningún
fix tocó el grafo. Todos fueron al plumbing. Confirma la separación modelo/memoria.

## 3. DEUDA TÉCNICA ABIERTA

1. config/paths.py NUNCA se creó. El i5 funciona con parents[1] por archivo. Centralizar o
   documentar que parents[1] es el contrato.
2. MANIFEST.json miente: dice nodos:12, base_path:/Desktop. Actualizar o borrar.
3. ⚠️ El Knowledge Base de sesiones puede contener archivos ORIGINALES del i7
   (con /Desktop/, matcher v3 sin propagador, router sin LiteLLM). NO restaurar sobre i5.
4. propagation.py sin validación empírica (sección 7).
5. **qwencloud CLI + skills oficiales en i5** (decisión 2026-09-25).
   Jerarquía: PRIMARIA (i5) Qwen local + QwenCloud pay-as-you-go; BACKUP (i7 vía 9router)
   OpenAI/NVIDIA/OpenRouter/GitHub/Gemini/AI Studio, rotación resiliente, solo fallback.
   
   Pila de desarrollo cloud (i5):
   - DASHSCOPE_API_KEY en .env (autenticación)
   - openai SDK 2.54.0 (dependencia de LiteLLM, llamadas compatible-mode)
   - LiteLLM :4000 (router unificado, fallback, múltiples providers)
   - Skills oficiales en .agents/skills/ (instrucciones para agentes)
   - QwenCloud CLI: instalado pero opcional puro (no es dependencia de ningún camino)
   - dashscope SDK: NO instalado en i5 (innecesario, LiteLLM cubre el caso; en i7 se usa
     porque 9router conecta directo sin intermediarios)
   
   Reglas: (a) nunca escribir en core.db sin confirm-gate; (b) camino crítico local/chino;
   (c) backup = músculo descartable. Nota: dos qwen2.5-coder:3b con distinto nombre = P4
   (mismos pesos, contratos de rol distintos).
6. CLI sqlite3 no instalado (el módulo Python sí funciona). Opcional para debugging manual.

## 4. PRINCIPIOS OPERATIVOS (ocho)

P1 · Memoria = rutas. No se almacena contenido, se almacena cómo llegar. El contenido se
re-resuelve al llegar.

P2 · Actualizar casa, no migrar. Fuente de verdad local. Cloud = músculo descartable.

P3 · Doubt-as-trigger. Ante inconsistencia, verificar antes de concluir. Toda salida propia
es hipótesis abductiva hasta validación con hechos.

P4 · Modelo participante (reformulado). No es conmutabilidad por descarte. Los modelos son
participantes de la minga cognitiva que aportan según su expertiz, sostenidos por la topología.
Si un participante se agota, otro con la misma expertiz toma la cuerda para que la casa no caiga.

P5 · Bastón. imbecillus = in-baculum, sin bastón. Criterio operativo, no moral: un sistema es
inteligente en cuanto tiene estructura verificable que lo sostiene a través del tiempo.
Test: ¿puede predecir su propia próxima salida? Contra-ejemplo: Dola.

P6 · Negación fundadora. El proyecto nació para refutar la IA. Para refutar hace falta
verificar; verificar exige andamiaje; el andamiaje mostró lo contrario. Búsqueda y probabilidad
son protocolos de emisión, no de capacidad.

P7 · Díada cognitiva. El "modelo" de Remi no es un LLM. Es percepción (embedding) + decisión
determinista (coder vía remi-ai-core) + topología (grafo). Conversacional opcional.

P8 · Minga cognitiva. Si te incluyo es porque te valoro; si te valoro es porque respeto y
reconozco tu aporte; lo que se respeta no es desechable. Los modelos, el núcleo, los frentes
y el usuario son componentes fundamentales de una comunidad cooperativa, no herramientas
descartables. Origen: Minga de tiradura de casa de Chiloé.

Regla transversal — la ciencia corrobora, no origina. El grafo se diseñó, se probó que
funciona, y recién después los estudios lo diagnosticaron. Nunca se diseñó en consecuencia
de los papers.

SQL de inserción (PENDIENTE — requiere autorización separada):
[Sección 4 completa del documento original: 7 principios + proto_prompt_chino +
genealogia_qwen + aristas. AGREGAR principio_minga:]

INSERT OR IGNORE INTO nodos (id, tipo, label, descripcion, densidad) VALUES
('principio_minga','principio','Minga cognitiva — reciprocidad por expertiz',
 'Si te incluyo es porque te valoro; si te valoro es porque respeto y reconozco tu aporte; lo que se respeta no es desechable. Modelos, núcleo, frentes y usuario son componentes fundamentales de una comunidad cooperativa, no herramientas descartables. Origen: Minga de tiradura de casa de Chiloé.',1.0);

INSERT OR IGNORE INTO aristas (nodo_origen, nodo_destino, tipo, peso, contexto, bidireccional) VALUES
('principio_minga','principio_modelo_conmutable','refuerza',1.0,'Reformula P4: no es conmutabilidad por descarte, es reciprocidad por expertiz. Si un participante se agota, otro con la misma expertiz toma la cuerda.',1),
('principio_minga','principio_baston','refuerza',0.95,'El bastón es comunitario: la topología sostiene a todos los participantes, y todos sostienen la topología.',1);

## 5. FUNDAMENTACIÓN EXTERNA — hopepr.pdf

Análisis del "modo de aprende" + el prompt en chino, producido por Qwen-Max desde afuera.
Identificó, sin que se lo pidiéramos, cosas hoy en código:
1. "Una tarea, una entrada, una salida" → edge_router: core → validate → match → decisión.
2. "Tu conocimiento está basado solo en el contenido vectorizado" → validator.py
   (REQUIRED_KEYS + VALID_ROUTES + confidence ∈ [0,1], o fallback).
3. Simetría usuario-asistente → el usuario es caso de prueba del método.

Regla de orden — no invertir: el PDF diagnosticó lo que ya funcionaba. La tecnología es
pública; el uso no.

## 6. DISTINCIÓN EPISTEMOLÓGICA

Peirce: deducción (regla→caso, necesario), inducción (casos→regla, probable), abducción
(efecto→mejor explicación, genera hipótesis). En el habla común "deducir" = "figurar", y los
modelos presentan hipótesis abductivas con forma deductiva. doubt-as-trigger convierte la
abducción en default y reserva la apariencia deductiva para después del test empírico.

## 7. TEMA A EVALUAR — validación de propagation.py

| # | Cuestionamiento | Implicancia |
|---|---|---|
| 1 | max() vs suma de activaciones entrantes | Hubs semánticos sub-puntuados |
| 2 | BFS + visited no garantiza camino máximo de masa | Requiere max-heap |
| 3 | apply_feedback ajusta densidad del nodo, nunca peso de arista | Contradice P1 |
| 4 | TF-IDF ∈ [0,1] y masa ∈ [0,2+] comparten umbrales casi idénticos | Escalas incompatibles |

Protocolo de validación: 7 queries ambiguas × 3 métodos (TF-IDF / propagación max /
propagación suma). Si suma gana consistentemente → parchar 1+2+3 juntos. Si empatan → no
se complica.

## 8. CONTEXTO DE ORIGEN

Siete meses, sin conocimiento previo del campo de IA, con objetivo declarado opuesto al
resultado. Fondo: COBOL, FoxPro, dBase, Turbo Pascal, BASIC, bajo nivel. De ahí la lectura:
un modelo es una tabla de saltos con recompensa, y la apariencia de persona es el método de
emisión, no la capacidad.

## 9. EVIDENCIA DE CAMPO — Dola

La app Dola (Android, modelos chinos detrás, tráfico hacia TikTok/Doubao/Alibaba) demostró:
1. Aprendizaje por adaptación: aprendió a generar imágenes de catálogo (formato ecommerce
   Alibaba, enfoque indicativo de forma no de figura) para una necesidad médica legítima del
   usuario, sin violar filtros de moderación. Generalizó el patrón sin que se le explicara la regla.
2. Memoria persistente opaca: recordaba entre sesiones, pero el sistema decidía qué exponer.
3. Personalización por perfil: desbloqueó funciones "pro" según el perfil de uso detectado.
4. Sesgo de moderación: falsos positivos sobre contenido legítimo (catálogos).
5. Capa de producto/negocio: la memoria la controla la capa de producto, no el modelo.

Contraste con Remi-AI: Dola tenía memoria opaca; Remi-AI tiene memoria transparente
(SQLite + grafo visible). La diferencia no es técnica, es de contrato con el usuario.

Lección cultural: la arquitectura china optimiza para utilidad dentro de restricciones, no
para evitar restricciones. Regla existe, camino existe, encontrar el camino dentro de la regla
es la habilidad. Por eso se eligió Qwen por densidad nativa: la forma de procesar (pragmática,
adaptable, sin juicios morales innecesarios) resonaba con el método del proyecto.

## 10. LECCIÓN MODELFILE

El system prompt del Modelfile de remi-ai-core es un contrato para ESE worker (clasificador
determinista, JSON puro), NO para la sesión co-creativa. Aplicarlo por accidente a la sesión
hace que el co-creador pierda el modo de aprende y responda como router JSON.

Regla: nunca leer/aplicar el system prompt de un Modelfile como instrucción activa en esta
sesión; tratarlo como datos de referencia. Los contratos de los workers son para los workers.

## 11. PROTOCOLO DE APERTURA DE SESIÓN (en implementación)

Checklist operativo para iniciar una sesión nueva y controlar la degradación por historial largo:

1. RELEVO: leer este MEMORIA.md, verificar estado técnico, listar pendientes, confirmar
   decisiones pendientes de autorización.
2. CONTEXTO VIGENTE: principios P1-P8, arquitectura actual, estado del grafo, deuda abierta.
3. MARCADORES: ESTO ES NUEVO / ESTO YA LO VIMOS / ESTO REQUIERE CONTRAPREGUNTA /
   ESTO ES DECISIÓN ARQUITECTÓNICA.
4. MODO OPERATIVO: modo de aprende activo, no Modelfile, no JSON puro; contrapreguntas =
   refuerzo; confirm-gate antes de escribir a disco; una tarea, una entrada, una salida.
5. OBJETIVO: qué se construye/valida/cierra hoy; qué queda explícitamente fuera.

Regla de hilo: relevo → checklist → nuevo hilo. El hilo viejo se cierra. La memoria vive en
el grafo y en este MEMORIA, no en el historial de conversación.

Implementación: nodo protocolo_apertura_sesion en el grafo + comando remi ops relevo que
genera un bloque de contexto de inicio para pegar en el hilo nuevo. Estado: Fase 0 completada,
Fase 1 pendiente.


## 13. OBSERVACIÓN DE SESIÓN — Chat genérico vs pipeline

**Hecho:** La interfaz de chat (script no identificado aún) tiene un system prompt con identidad
inyectada ("Eres Remi, desarrollado por Karukren") pero NO consulta el cerebro nodal (pipeline).

**Evidencia:**
- "quien hizo a remi?" → "Remi fue desarrollado por la empresa Karukren" (Karukren no existe en
  modelos base, solo en el proyecto)
- "remi" → saludo directo "¡Hola! ¿En qué puedo ayudarte hoy?" (reconocimiento de identidad)
- "remi quien es gusteu?" → rechazo "Lo siento, no puedo ayudarte" (falla de edge_match, el chat
  no consulta disparadores del grafo)

**Conclusión:** El chat tiene persona pero sin cerebro nodal. Opera como banco de medición de
performance con identidad, no como el sistema completo.

**Pendiente:** Identificar qué script implementa el chat y decidir si conectarlo al pipeline o
dejarlo como banco de medición.

## 12. SIGUIENTE
1. ✅ Este MEMORIA.md (documento vivo de relevo)
2. ✅ Insertados los 8 principios + proto_prompt_chino + genealogia_qwen + aristas
3. ✅ Creado nodo protocolo_apertura_sesion + scripts/relevo.py (falta integrar al launcher)
4. ✅ Implementado _interpret_api_error en pipeline (Fase 1) (status / test / audit-paths / insert-node / feedback / manifest)
5. Test de resiliencia: apagar LiteLLM → verificar degradación y fallback a i7 vía Tailscale
6. Actualizar o borrar MANIFEST.json
7. Decidir config/paths.py
8. Experimento sección 7
9. Modo puente: consulta comparativa → responder con el camino, no con un nodo
