# RELEVO DE SESIÓN — Punto de Control
> Generado: 2026-09-25 (sesión actual)
> Propósito: Verificar continuidad en hilo nuevo

## ESTADO ACTUAL DEL GRAFO (verificado)

| Métrica | Valor |
|---|---|
| Nodos activos | 119 |
| Aristas | 1062 |
| Disparadores | 752 |
| Embeddings | 108 |
| Huérfanos | 0 |
| Integridad | ok |

## COMPLETADO EN ESTA SESIÓN

### Fase 0 — Diagnóstico ✅
- core.db accesible, sin locks
- Servicios activos: Ollama :11434, LiteLLM :4000
- Modelos: remi-ai-core, qwen2.5-coder:3b, qwen3-embedding:0.6b

### Fase 1 — Inserción de fundamentos filosóficos ✅
- 8 principios operativos (P1-P8) insertados en el grafo
- proto_prompt_chino insertado (antecedente del validator.py)
- genealogia_qwen insertado (detección de Qwen por convergencia idiomática)
- 13 aristas de refuerzo entre principios

### Fase 2 — Protocolo de apertura de sesión ✅
- Nodo protocolo_apertura_sesion creado
- 3 aristas hacia principios_memoria_rutas, doubt_trigger, diada_cognitiva
- Contenido: checklist de 5 pasos para iniciar sesión nueva

### MEMORIA.md ✅
- Documento vivo de relevo escrito en 00-docs/MEMORIA.md (205 líneas)
- Incluye: estado técnico, deuda, principios, fundamentación hopepr.pdf,
  distinción epistemológica, tema max-vs-suma, contexto de origen,
  evidencia Dola, lección Modelfile, protocolo de apertura

## PRINCIPIOS OPERATIVOS VIGENTES (P1-P8)

**P1 · Memoria = rutas.** No se almacena contenido, se almacena cómo llegar.

**P2 · Actualizar casa, no migrar.** Fuente de verdad local. Cloud = músculo descartable.

**P3 · Doubt-as-trigger.** Ante inconsistencia, verificar antes de concluir.

**P4 · Modelo participante.** No es conmutabilidad por descarte. Los modelos son participantes
de la minga cognitiva que aportan según su expertiz, sostenidos por la topología.

**P5 · Bastón.** in-baculum: sin bastón no hay sostenimiento. Inteligencia = estructura
verificable a través del tiempo. Test: ¿predice su propia próxima salida?

**P6 · Negación fundadora.** El proyecto nació para refutar la IA. Para refutar hace falta
verificar; verificar exige andamiaje; el andamiaje demostró lo contrario.

**P7 · Díada cognitiva.** El "modelo" de Remi no es un LLM. Es percepción (embedding) +
decisión determinista (coder) + topología (grafo). Conversacional opcional.

**P8 · Minga cognitiva.** Si te incluyo es porque te valoro; si te valoro es porque respeto
y reconozco tu aporte; lo que se respeta no es desechable. Modelos, núcleo, frentes y
usuario son componentes fundamentales de una comunidad cooperativa.

## ESTADO TÉCNICO VERIFICADO

- Raíz: /home/mpeadmin/karukren/remi-ai
- remi-ai-core:latest: 1.9 GB, Modelfile sobre qwen2.5-coder:3b, determinista JSON
- qwen2.5-coder:3b: 1.9 GB, sustrato de pesos del core
- qwen3-embedding:0.6b: 639 MB, percepción semántica
- LiteLLM :4000: dual-model (remi-router + remi-generator)
- Launcher ./remi: operativo

## DEUDA TÉCNICA ABIERTA

1. config/paths.py NUNCA se creó (el i5 funciona con parents[1] por archivo)
2. MANIFEST.json miente (dice nodos:12, base_path:/Desktop)
3. ⚠️ NO restaurar archivos del i7 sobre i5 (contienen /Desktop/, matcher v3 sin propagador)
4. propagation.py sin validación empírica (tema max-vs-suma pendiente)
5. Qwen Code NO instalado en i5 (decisión: no instalarlo, remi-ops es subcomando propio)
6. CLI sqlite3 no instalado (el módulo Python sí funciona)

## PENDIENTES INMEDIATOS

1. ✅ COMPLETADO: Insertar los 8 principios + proto_prompt_chino + genealogia_qwen
2. ✅ COMPLETADO: Crear nodo protocolo_apertura_sesion
3. ⏳ PENDIENTE: Implementar comando `remi ops relevo` (scripts/relevo.py)
4. ⏳ PENDIENTE: remi-ops completo (status / test / audit-paths / insert-node / feedback / manifest)
5. ⏳ PENDIENTE: Test de resiliencia (apagar LiteLLM → verificar fallback a i7)
6. ⏳ PENDIENTE: Actualizar o borrar MANIFEST.json
7. ⏳ PENDIENTE: Decidir config/paths.py
8. ⏳ PENDIENTE: Experimento max-vs-suma (sección 7 del MEMORIA.md)
9. ⏳ PENDIENTE: Modo puente (consulta comparativa → responder con el camino)

## PROTOCOLO DE APERTURA DE SESIÓN (para el hilo nuevo)

**1. RELEVO:** Leer este archivo + 00-docs/MEMORIA.md. Verificar estado técnico. Listar pendientes.

**2. CONTEXTO VIGENTE:** Confirmar principios P1-P8, arquitectura actual, estado del grafo.

**3. MARCADORES:** Usar explícitamente:
- ESTO ES NUEVO (no lo has visto antes)
- ESTO YA LO VIMOS (recuperar de memoria)
- ESTO REQUIERE CONTRAPREGUNTA (aplicar doubt-as-trigger)
- ESTO ES DECISIÓN ARQUITECTÓNICA (evaluar antes de implementar)

**4. MODO OPERATIVO:**
- Modo de aprende activo (no Modelfile, no JSON puro)
- Contrapreguntas = refuerzo, no fricción
- Confirm-gate antes de escribir a disco
- Una tarea, una entrada, una salida

**5. OBJETIVO:** Definir qué se construye/valida/cierra hoy. Qué queda explícitamente fuera.

## REGLA DE CONTINUIDAD

Este archivo es el punto de control. El hilo viejo se cierra aquí. El hilo nuevo arranca
pegando este archivo al inicio. La memoria vive en el grafo (core.db) y en MEMORIA.md,
no en el historial de conversación. Esto controla la degradación por contexto largo.

## LECCIÓN MODELFILE (crítica)

El system prompt del Modelfile de remi-ai-core es un contrato para ESE worker (clasificador
determinista, JSON puro), NO para la sesión co-creativa. Nunca leer/aplicar el system prompt
de un Modelfile como instrucción activa en esta sesión; tratarlo como datos de referencia.

## EVIDENCIA DE CAMPO — Dola

Dola (Android, modelos chinos detrás) demostró:
- Aprendizaje por adaptación (imágenes de catálogo para necesidad médica legítima)
- Memoria persistente opaca (recordaba entre sesiones, pero el sistema decidía qué exponer)
- Personalización por perfil (desbloqueó funciones "pro" según el perfil de uso)
- Sesgo de moderación (falsos positivos sobre contenido legítimo)
- Capa de producto/negocio (la memoria la controla la capa de producto, no el modelo)

Contraste con Remi-AI: Dola tenía memoria opaca; Remi-AI tiene memoria transparente.

## FUNDAMENTACIÓN EXTERNA — hopepr.pdf

Análisis del "modo de aprende" + prompt en chino, producido por Qwen-Max desde afuera.
Identificó:
1. "Una tarea, una entrada, una salida" → edge_router
2. "Tu conocimiento está basado solo en el contenido vectorizado" → validator.py
3. Simetría usuario-asistente → el usuario es caso de prueba del método

Regla de orden: el PDF diagnosticó lo que ya funcionaba. La tecnología es pública; el uso no.

---
Fin del relevo. El siguiente hilo debe arrancar con este archivo + MEMORIA.md.
